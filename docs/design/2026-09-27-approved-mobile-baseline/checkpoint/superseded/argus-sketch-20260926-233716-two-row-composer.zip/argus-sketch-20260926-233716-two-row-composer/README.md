# Argus UI sketch checkpoint

Saved at: 2026-09-26T23:37:16.124781-05:00

This is a frozen copy of the disposable design preview, separate from production and the active editable preview. All 16 original source/design files are preserved under `app/`. `app/INHERITANCE.md` records adaptations, inherited details, and remaining boundaries. `screenshots/chat-composer.png` shows the latest composer view.

## Resume or restore

Make a working copy of the `app` folder, then from that copy run:

```sh
python3 -m http.server 8026 --bind 127.0.0.1
```

Open http://127.0.0.1:8026/ . Port 8026 avoids interfering with the active sketch on 8025. No build or package installation is required. Google Fonts requires network access; system fallbacks are used otherwise. Keep this checkpoint unchanged and continue editing the original preview or a new working copy.

## Experience preserved

- Home, Accounts, Chat, Plan and Search navigation; bell for Updates and profile entry.
- Glass navigation and scrolling behavior, shared edge blur, settings/profile refinements, and watermark/version footer.
- Chat Recents and New chat; active-chat sharing/menu placeholders and hidden phone conversation titles.
- Header targets 48px, pair gaps 8px, side padding 16px.
- Two-row composer with “Type a message”, Plus, dictation, and future voice-conversation control; Send replaces the waveform for composed content.
- Fictional attachments, context and asset chips, sample recording review/edit/confirm/correct flows.

## Scope

This snapshot saves source and design progress, not browser-memory conversations or edits. Reload resets temporary demo state. Voice, ingestion, sharing and financial changes are explicitly simulated. No production implementation or deployment is implied.

SHA256SUMS.json records every payload file in this checkpoint. The adjacent ZIP contains the same checkpoint for easy copying.
