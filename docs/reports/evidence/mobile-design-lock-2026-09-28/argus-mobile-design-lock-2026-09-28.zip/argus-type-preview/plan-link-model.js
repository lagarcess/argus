// Derived links in the disposable sketch. Plans own intentions; activity owns what happened.
(function(root){
  const money=typeof module!=='undefined'?require('./money-input.js'):root.ArgusMoney;
  const units=(n,c)=>BigInt(money.parse(String(n),{currency:c,required:true}).minorUnits);
  function movements({goals,debts,accounts,ids,currency}){
    const selected=new Set(ids),items=[],excluded=[];
    for(const [kind,plans] of [['goal',goals],['debt',debts]])for(const plan of plans){
      if(!plan.monthly)continue;
      const m=plan.movement,from=accounts.find(a=>a.id===m?.from),to=accounts.find(a=>a.id===(kind==='debt'?plan.accountId:m?.to));
      const name=kind==='goal'?plan.name:to?.name||'Debt payment',c=kind==='goal'?plan.currency:to?.currency;
      if(c!==currency)continue;
      const date=kind==='debt'?to?.paymentDue:m?.date;
      let reason=!m||!from||!to||!date?'Choose accounts and a date':from.archived||to.archived?'Review archived account':from.currency!==c||to.currency!==c?'Accounts must use the same currency':!selected.has(from.id)?'Funding account is not included':null;
      if(reason){excluded.push({id:plan.id,name,kind,reason});continue;}
      const internal=kind==='goal'&&selected.has(to.id);
      items.push({id:'plan-'+plan.id,planId:plan.id,name,kind,type:internal?'transfer':'expense',entryType:kind==='goal'?'transfer':'payment',from:from.id,to:to.id,amount:Number(units(plan.monthly,c)),date,repeat:'monthly',internal});
    }
    return {items,excluded};
  }
  function matches(item,entry,currency,exactAmount=true){
    if(!entry||entry.removed||(exactAmount&&units(entry.amount,currency)!==BigInt(item.amount)))return false;
    if(!item.entryType)return entry.type===item.type;
    return entry.type===item.entryType&&(entry.type==='payment'?entry.accountId===item.to&&entry.otherId===item.from:entry.accountId===item.from&&entry.otherId===item.to);
  }
  function contributions(entries,id,currency){return entries.filter(e=>!e.removed&&e.type==='transfer'&&e.goalId===id&&(!e.goalDestinationId||e.goalDestinationId===e.otherId)).reduce((n,e)=>n+units(e.amount,currency),0n);}
  function progress(goal,entries){const last=goal.history.at(-1);return Number(units(last?.amount||0,goal.currency)+contributions(entries,goal.id,goal.currency)-BigInt(last?.linkedUnits||0))/10**money.config(goal.currency).digits;}
  root.PlanLinks={movements,matches,contributions,progress};if(typeof module!=='undefined')module.exports=root.PlanLinks;
})(globalThis);
