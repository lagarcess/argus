// One optional note control for financial activity and goal progress in this sketch.
(function(root){
  const limit=200;
  const validate=value=>{if(String(value||'').length>limit)throw Error('Keep your note to '+limit+' characters.');return String(value||'');};
  const field=(id,value='')=>`<details class="entry-note-editor" ${value?'open':''}><summary>${value?'Note':'Add note'} <span class="optional">Optional</span></summary><label class="sr" for="${id}">Note</label><textarea aria-label="Note" data-entry-note id="${id}" maxlength="${limit}" rows="3" placeholder="Anything you want to remember" aria-describedby="${id}-count">${escape(value)}</textarea><small id="${id}-count">${value.length}/${limit}</small></details>`;
  if(typeof document!=='undefined')document.addEventListener('input',e=>{if(e.target.matches('[data-entry-note]'))document.getElementById(e.target.id+'-count').textContent=e.target.value.length+'/'+limit;});
  root.EntryNotes={limit,validate,field};if(typeof module!=='undefined')module.exports=root.EntryNotes;
})(globalThis);
