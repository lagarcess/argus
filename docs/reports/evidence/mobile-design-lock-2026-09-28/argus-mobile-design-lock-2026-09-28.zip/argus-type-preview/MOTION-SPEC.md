# Shared motion · locked mobile baseline

Part of the September 28, 2026 mobile design lock. Existing composer, edge blur, glass navigation and chat greeting behavior stay intact.

| Interaction | Treatment | Why |
| --- | --- | --- |
| Primary/secondary controls | 120ms color/opacity; pressed scale .98 | Immediate acknowledgment without moving surrounding layout |
| Header icon press | Scale .94; fixed header geometry | Feedback without the old flicker/position changes |
| Surface replacement | 180ms opacity .75→1 and translateY 4px→0 | Quiet orientation; no long page slide |
| Dialog | 200ms enter, 140ms opacity exit; 10px translation and .99 scale | Layer appears near its action; no bouncing sheet |
| Progress | 240ms width easing | Show the resulting value; do not invent task progress |
| Plan tabs | 120ms background/color | Selection is immediate; content uses the surface rule |
| Search/typing/streaming | No per-result or per-token entry animation | Protect responsiveness and reading position |
| Keyboard navigation | Suppress button/dialog transition; cancel surface animation | Focus and action stay immediate |
| Reduced motion | No animation/transition/smooth scroll, including existing decoration | Respect OS preference; `?motion=reduce` supplies a review-only override |

Easing is `cubic-bezier(.22,1,.36,1)`. Repeated navigation cancels the prior animation. Transforms and opacity handle view motion; progress width is limited to a small bar. Fine-pointer hover is gated. No haptics are simulated.

`motion.css` owns shared tokens and CSS. `motion.js` observes only whole screen child replacement, not nested search updates or streamed text. Native implementations should use native focus, transition, reduced-motion and keyboard primitives. No real authentication, network loading, monitoring state or save success may be inferred from decorative motion.

Validation: reduced preview computed button transitions are 0s; keyboard interaction used through the full browser checks. Native frame timing and software-keyboard choreography remain unverified. CSS discrete dialog exit support varies; unsupported browsers may close immediately.

Attachment tray and starter suggestions exchange height over the same 200ms easing, without remounting the greeting. Hidden suggestions are inert. Temporary chat has no suggestion area. Header/temporary landing changes use a 150ms fade with fixed icon positions. Reduced motion disables both transitions.
