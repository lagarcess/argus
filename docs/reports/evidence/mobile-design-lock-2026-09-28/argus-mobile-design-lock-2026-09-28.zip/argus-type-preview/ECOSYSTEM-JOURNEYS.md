# Connected ecosystem journeys — candidate, September 27, 2026

> Historical iteration/evidence record. The final accepted template is [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md); use its current reports and acceptance boundary when implementing. Earlier gaps and recommendations below describe their dated checkpoint.

Status: disposable experience proposal requested by the founder. Extends the visual baseline without changing production code or claiming final financial/permission contracts. Open `ecosystem-review.html` or `?demo=accounts&journey=hub`.

| Before | After | Decision / tradeoff |
| --- | --- | --- |
| Authored single-entry capture, isolated from account totals | Four-row statement review; existing-match decision; editable uncertain row; batch confirmation into the existing account ledger | Synthetic source, not OCR or bank-format accuracy. Review progress survives surface navigation, not reload. |
| Household intention only | Invitation preview, pending/accept/decline, private/view/edit choices, Personal/Household context, restricted account/search views and revoke confirmation | Same account identity in both views; no actual access service. Shared editing and document-sharing flows remain unimplemented. |
| Separate budgets, goals and debt plans | Monthly DOP planning view, chosen cash accounts, covered bills counted once, savings intentions, existing debt plans and recorded payment effects | An unassigned estimate, not safe-to-spend advice or an allocation ledger. No FX or future income assumed. |

## Explore

1. Statement: inspect Lunch; choose Same transaction. Edit COMERCIO 094, give it a category, then confirm the two new entries. Open the account or entry; correct/remove using the existing journey. Source row provenance is retained. Search and Home read the same records.
2. Household: use Copy invite link, preview an email invitation, or choose fictional Sam from the selected-contact preview; all individual accounts default private. Nothing shares while pending. Preview acceptance or decline; shared links additionally preview inviter approval. Acceptance creates no account and shares none. Choose view or edit per account after joining. Household Home/Accounts read selected account IDs; Search excludes private records and cross-account transfers pending a redacted-detail design. Personal chats, memories and original documents are not reused in shared context. Remove Sam using inherited destructive confirmation; own records survive.
3. Commitments: DOP 12,000 rent sits inside a DOP 15,000 Housing budget, counted once. Select money to include. Set an Emergency fund monthly intention and add a payment plan using existing Plan. Record rent paid; cash and unpaid commitments fall together. Inspect/correct/remove the original expense in Accounts. Goal progress remains separate from a saving intention.

The household contribution example contains DOP 6,000 planned and zero received. It never adds a planned amount to account totals. This illustrates contribution privacy, not a completed contribution-recording backend.

## Shared owners

- AccountActivity owns imported and manual entries. Batch additions validate the complete batch before mutation; stable source-row keys prevent duplicate retries, including after removal. Existing source keys survive corrections through the entry draft. This is an in-session fixture contract, not the ingestion architecture.
- PlanPreview owns budgets, debt plans and monthly saving intentions. The new view reads those objects. The authored rent obligation is owned once in this module and links to its recorded expense ID.
- The sharing map owns the candidate visibility choices; household views derive their allowed IDs from it. This is UI filtering only, not security enforcement. Production must enforce permissions server-side.
- Money input, semantic colors, typography, destructive confirmations, navigation, reduced motion, blur and form controls retain existing sketch owners.

## Verification

230 deterministic checks passed: prior 224 plus six batch/commitment checks. Additional JavaScript syntax checks passed.

Browser journeys verified:
- Initial import confirmation disabled while two rows require review. Matching Lunch plus category correction produces two additions. Account becomes DOP 71,279.25; activity includes both new entries. No duplicate Lunch/Supermarket.
- Shared Everyday spending appears in household search; changing it to private removes those results. Other private accounts stay excluded.
- Pending, declined and accepted invitations and partner removal are visibly distinct. That historical checkpoint created a synthetic joint wallet; the current invitation revision removes that fixture. Current acceptance leaves the household empty until explicit sharing. Private updates badge and personal conversation controls are hidden in household context.
- DOP 3,000 saving intention reduces planning room without changing account balances. Recording rent reduces cash by DOP 12,000 while unassigned money stays DOP 54,729.25. Adding a DOP 2,000 debt plan reduces that to DOP 52,729.25.
- Browser console inspection returned no errors/warnings in checked states. Screenshots in `journey-audit/ecosystem/`; figures reflect synthetic examples, not live data. Narrow-device and native interaction acceptance is still required.

## Decisions to resolve before implementation

- Imports older than balance snapshots, balance reconciliation order, changed source documents, repeated imports, partial failures, duplicate policy and institution coverage. Current example is explicitly after its opening balance.
- Household delivery implementation (copy link through do-blitz and email through Resend are now selected), revocation/retention, edit authority, private transfer redaction, source-document visibility, contribution records and shared planning. The preview does not simulate Sam editing or permission enforcement.
- Budget periods, funding scope, bill recurrence/partial payments, goal contribution matching and debt payment allocation. The current-month demonstration is not a committed financial schema. Linked actual savings are still absent; they must not be inferred from goal progress.
- Guest onboarding remains parked. No new conversational runtime, paid provider, camera, upload, invitation, push, storage or authentication integration is included.

This is enough to discuss behavior. Do not use the candidate choices as production authorization or continue visual polishing without a concrete journey question.

## September 27 invitation and forecast revision

See [Look ahead and invitation study](LOOK-AHEAD-STUDY.md) for current behavior, contacts research, 238 passing checks, and updated evidence. Earlier household screenshots show superseded fixture setup and are retained only as history; the review page links the current invitation preview.


## Connected-loop checkpoint — September 28, 2026

The founder requested closure of the four audited handoffs. See [LOOP-CLOSURE.md](LOOP-CLOSURE.md) for implementation, before/after decisions, verification and limits. Earlier notes saying linked actual savings are absent or describing a separate monthly-room calculation are superseded by this checkpoint. The same account ledger now supports sample capture, plan-linked activity, received household contributions, and correction/recovery. This is a local template checkpoint for review, not production implementation or deployment approval.
