# Money entry: inheritance and strengthening

September 27, 2026. Disposable sketch only; production runtime untouched.

## Production reference

Read `web/components/chat/ConfirmationDirectEdit.tsx` in local integration and
GitHub `main`. Main file SHA-256:
`b3929ef64a64a84154873dfd000836e695d1a94c708bfdd9013213a9404c4d1a`.
This is repository evidence, not a deployed-browser verification.

Preserved: text inputs with decimal keyboard; 16px+ mobile text; currency
marker; inline errors; values remain editable. Production's capital parser
uses `Number(capitalDraft.replace(/[\s,$]/g, ""))`, and its seed parser has the
same stripping behavior. `12,50` therefore becomes 1250; exponent strings can
also pass Number. No shared locale-aware money-input component was found in
the inspected current web component paths. The prototype does not copy those
parsing weaknesses.

## One owner in this sketch

`money-input.js` owns parsing, precision, formatting, complete-input validation,
accessible errors and submit validation. Account balance, estimated asset
value, credit limit, Plan target, legacy account form and capture correction
all use it. Consumers read its normalized value; they do not independently
strip separators or parse the display string. The script loads before the
surface listeners so an invalid input cannot reach their save handlers.

Current English sketch uses en-US separators. Pure parser tests also cover
es-419 and es-ES; this is not a full localized UI implementation. Fractions
follow Intl currency metadata, including zero- and three-decimal currencies.
Pastes with the selected code/symbol are accepted. Foreign currency labels,
ambiguous grouping and comma decimals under an English UI get an explanation
rather than a guessed magnitude. Input is left intact while editing, with a
formatted readback; blur applies grouping and currency decimal places. Currency
selection revalidates without conversion or rounding. Blank remains unknown.

The parser derives integer minor units from digit strings for validation, but
existing disposable account totals still use JavaScript numbers. This is not
a production ledger/arithmetic contract, nor a household rounding policy.
Percent/rate inputs are separate controls with percent labels, not money fields.

## Verification

- `node --test money-input.test.cjs`: 194 passed. Includes all 154 catalog
  currencies, cents, zero/blank, negative restrictions, malformed separators,
  foreign currency markers, exponent rejection, limits and precision changes.
- Browser: DOP `12,50` could not save and remained editable; `RD$ 1,234.50`
  formatted and saved as DOP 1,234.50.
- Plan accepted `$5,000.25` and rendered $5,000.25, retaining cents.
- Sample capture correction accepted `RD$ 1,234.75` and updated its proposal.
- Changing DOP 12.50 to JPY retained the text and blocked saving instead of
  rounding; changing the amount to 12 saved JPY 12.
- Browser error/warning log empty for the verified flows. JavaScript syntax
  and repository whitespace checks passed. Native keyboard behavior on a real
  phone remains separate validation; this used the browser phone layout.

For production handoff, promote the intended behavior through a shared client
control and cross-client examples after settling money contracts; do not copy
this disposable DOM adapter or claim the main-branch parsing weakness is fixed.

## Account journey follow-up

The activity forms reuse this control. Browser testing found that changing the
displayed value on focus disrupted select-all and replacement. Focus now leaves
the value untouched; blur/save still normalize it. Replacing an existing transfer
amount was verified in the browser after the fix. The combined money and activity
model suite has 206 passing checks. Activity effects use integer minor units;
existing surface totals still consume number-valued balances.
