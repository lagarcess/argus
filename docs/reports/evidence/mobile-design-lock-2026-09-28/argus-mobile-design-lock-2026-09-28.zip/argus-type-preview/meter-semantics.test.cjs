const {test}=require('node:test'),assert=require('node:assert/strict'),m=require('./meter-semantics.js');
for(const [percent,tone] of [[0,'teal'],[70,'teal'],[71,'warning'],[89,'warning'],[90,'danger'],[100,'danger'],[110,'danger']])test(`capacity meter ${percent} percent is ${tone}`,()=>assert.equal(m.tone(percent,'capacity'),tone));
for(const [percent,tone] of [[0,'teal'],[90,'teal'],[100,'success'],[120,'success']])test(`goal meter ${percent} percent stays positive`,()=>assert.equal(m.tone(percent),tone));
