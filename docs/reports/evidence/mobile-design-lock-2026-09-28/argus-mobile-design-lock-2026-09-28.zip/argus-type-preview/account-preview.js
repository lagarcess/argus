// Disposable account-entry study. No API, durable storage, or bank connection.
(() => {
  const types = ['Cash','Checking','Savings','Investment','Credit card','Other debt'];
  let nextRecordId=0;
  const previewId=()=>`preview-${Date.now()}-${++nextRecordId}`;
  const assetTypes = ['Property','Vehicle','Other asset'];
  const allTypes = [...types,...assetTypes];
  const isAsset=k=>assetTypes.includes(k);
  const ownedValue=a=>a.balance==null?null:a.balance*(isAsset(a.kind)?(a.ownershipShare??100)/100:1);
  const paths = [
    '<rect x="3" y="6" width="18" height="12" rx="3"/><circle cx="12" cy="12" r="3"/>',
    '<path d="m3 9 9-6 9 6H3Zm0 12h18M6 10v7m6-7v7m6-7v7"/>',
    '<path d="M4 10h16v8a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3zM3 6h18v4H3zM12 6V2m-3 1 3 3 3-3"/>',
    '<path d="M4 19h16M5 15l5-5 4 3 6-8m-5 0h5v5"/>',
    '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18m-14 5h4"/>',
    '<path d="M7 3h10l3 3v15H4V3h3Zm1 7h8m-8 4h8m-8 4h4"/>',
    '<path d="m3 11 9-8 9 8M5 10v11h14V10M9 21v-8h6v8"/>',
    '<path d="m5 10 2-6h10l2 6M3 11a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v7H3zM5 18v3m14-3v3M6 14h2m8 0h2"/>',
    '<path d="m12 3 9 5v9l-9 5-9-5V8zM3 8l9 5 9-5m-9 5v9"/>'
  ];
  const svg=i=>`<svg viewBox="0 0 24 24" aria-hidden="true">${paths[i]}</svg>`;
  const isDebt=k=>['Credit card','Other debt','Loan'].includes(k);
  const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
  const currencyNames=new Intl.DisplayNames(['en'],{type:'currency'});
  const fmt=(amount,currency)=>new Intl.NumberFormat('en',{style:'currency',currency,currencyDisplay:'code'}).format(amount);
  let chosenCurrency='DOP', chosenType='', returnCurrencyFocus=null;
  const oldShow=show;
  const updatedLabel=value=>value===today()?'Updated today':`Updated ${new Intl.DateTimeFormat('en',{month:'short',day:'numeric',...(value.slice(0,4)!==today().slice(0,4)?{year:'numeric'}:{})}).format(new Date(value+'T12:00:00'))}`;
  const list=(preview=false)=>accounts.filter(a=>!a.archived).slice(0,preview?3:accounts.length).map((a,i)=>`<button class="choice account-record" data-edit="${accounts.indexOf(a)}" ${!preview&&i>=5?'hidden data-account-overflow':''}><span class="account-mini">${svg(Math.max(0,allTypes.indexOf(a.kind)))}</span><span class="account-record-name"><strong>${escape(a.name)}</strong><small>${escape(a.institution||a.kind)}${a.balance==null?` · ${a.currency||'USD'}`:''}</small></span><span class="account-amount">${a.balance==null?'Not added':fmt(Math.abs(ownedValue(a)),a.currency||'USD')}<small>${a.balance==null?'Add when ready':isDebt(a.kind)?(a.balance>0?'credit':'owed'):isAsset(a.kind)?`Estimate · ${a.ownershipShare??100}% yours`:a.balance<0?'overdrawn':a.asOf?updatedLabel(a.asOf):'Sample balance'}</small></span></button>`).join('');
  function renderManual(){
    chosenType=draft?(draft.kind==='Loan'?'Other debt':draft.kind):'';
    chosenCurrency=draft?.currency||'DOP';
    screen.innerHTML=`<div class="account-quick"><div class="account-heading"><h1>${editIndex==null?'Add to your picture':'Edit details'}</h1><button class="account-close" data-tab="accounts" aria-label="Cancel account entry">×</button></div><p class="muted account-intro">Start with what you know.</p><form id="quick-account-form"><fieldset class="account-types"><legend>What would you like to add?</legend><button type="button" id="account-type-summary" class="account-type-summary" hidden></button><div id="account-type-picker"><div class="account-type-grid">${types.map((t,i)=>`<button type="button" data-account-type="${t}" aria-pressed="${chosenType===t}">${svg(i)}<span>${t}</span></button>`).join('')}</div><details class="asset-types" ${isAsset(chosenType)?'open':''}><summary>Property, vehicle or another asset</summary><div class="account-type-grid">${assetTypes.map((t,i)=>`<button type="button" data-account-type="${t}" aria-pressed="${chosenType===t}">${svg(i+types.length)}<span>${t}</span></button>`).join('')}</div></details></div></fieldset><label for="account-nickname">Nickname <span class="optional">Optional</span></label><input id="account-nickname" maxlength="60" placeholder="e.g. Everyday spending" value="${escape(draft?.nickname??draft?.name??'')}" autocomplete="off"><div class="account-balance-label"><label for="account-amount" id="account-amount-label">${isDebt(chosenType)?'Amount owed':isAsset(chosenType)?'Estimated total value':'Current balance'} <span class="optional">Optional</span></label><button type="button" id="account-currency" aria-label="Choose account currency, ${chosenCurrency}" aria-haspopup="dialog">${chosenCurrency} <span aria-hidden="true">⌄</span></button></div><input id="account-amount" type="text" data-money-currency="${chosenCurrency}" inputmode="decimal" placeholder="Add later" value="${draft?.balance==null?'':isDebt(chosenType)?Math.abs(draft.balance):draft.balance}"><p class="account-help">Leave blank if you don’t know. Blank never means zero.</p><div id="account-ownership" hidden><button type="button" id="ownership-toggle" aria-expanded="false" aria-controls="ownership-options"></button><div id="ownership-options" hidden><p class="account-help">How much of it belongs to you?</p><div class="ownership-choices"><button type="button" data-share="100">All of it</button><button type="button" data-share="50">Half</button><button type="button" data-share="custom">Another share</button></div><div id="ownership-custom" hidden><label for="account-share">Your share (%)</label><input id="account-share" type="number" step="any" inputmode="decimal" value="${draft?.ownershipShare??100}"></div><p class="account-help">Enter the whole asset’s value above. Argus counts your part.</p></div></div><details class="account-details" ${editIndex==null?'hidden':''}><summary>More details <span id="account-details-hint"></span></summary><div data-fields="bank"><label for="account-bank">Bank or institution <span class="optional">Optional</span></label><input id="account-bank" maxlength="80" placeholder="e.g. Banco Popular" value="${escape(draft?.institution||'')}"></div><label for="account-date" id="account-date-label">Balance as of</label><input id="account-date" type="date" value="${draft?.asOf||today()}" max="${today()}" required><div data-fields="card"><label for="account-limit">Credit limit <span class="optional">Optional · same currency</span></label><input id="account-limit" type="text" data-money-currency="${chosenCurrency}" data-money-min="0" inputmode="decimal" value="${draft?.creditLimit??''}"></div><div data-fields="debt"><label for="account-rate">Annual interest rate <span class="optional">Optional · %</span></label><input id="account-rate" type="number" min="0" step="any" inputmode="decimal" value="${draft?.annualRate??''}"><label for="account-due">Next payment due <span class="optional">Optional</span></label><input id="account-due" type="date" value="${draft?.paymentDue||''}"></div><div data-fields="asset"><label for="account-source">Estimate based on <span class="optional">Optional</span></label><input id="account-source" maxlength="120" placeholder="e.g. My estimate, an appraisal" value="${escape(draft?.valuationNote||'')}"><label for="account-linked-debt">Related loan <span class="optional">Optional</span></label><select id="account-linked-debt"><option value="">No loan linked</option>${accounts.filter(a=>isDebt(a.kind)).map(a=>{a.id??=previewId();return `<option value="${a.id}" ${draft?.linkedDebtId===a.id?'selected':''}>${escape(a.name)} · ${a.currency||'USD'}</option>`}).join('')}</select><p class="account-help">${accounts.some(a=>isDebt(a.kind))?'Link an existing debt. It is counted once.':'You can add a loan separately and link it later.'}</p></div></details><p class="account-private">${headerGlyph('user')} ${window.FinancialSpaces&&FinancialSpaces.current()!=='personal'?'Private to you · '+escape(FinancialSpaces.name()):'Private to you. Sharing is a separate choice.'}</p><p id="account-error" role="alert" class="account-error"></p><button type="submit" class="primary" id="account-save" ${!chosenType?'disabled':''}>${editIndex==null?'Add to my picture':'Save changes'}</button><p class="account-demo">Local sketch · Use fictional information</p></form></div>`;
    screen.querySelectorAll('[data-account-type]').forEach(b=>b.onclick=()=>{
      chosenType=b.dataset.accountType;
      screen.querySelectorAll('[data-account-type]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));
      adaptFields();
      collapseTypes();
      document.getElementById('account-type-summary').focus({preventScroll:true});
      document.getElementById('account-save').disabled=false;
    });
    document.getElementById('account-type-summary').onclick=()=>{
      document.getElementById('account-type-picker').hidden=false;
      document.getElementById('account-type-summary').hidden=true;
    };
    document.getElementById('ownership-toggle').onclick=()=>{
      const options=document.getElementById('ownership-options');
      options.hidden=!options.hidden;
      document.getElementById('ownership-toggle').setAttribute('aria-expanded',String(!options.hidden));
    };
    screen.querySelectorAll('[data-share]').forEach(b=>b.onclick=()=>{
      const custom=b.dataset.share==='custom';
      document.getElementById('ownership-custom').hidden=!custom;
      if(custom){document.getElementById('account-share').focus();return}
      document.getElementById('account-share').value=b.dataset.share;
      updateOwnership();
      document.getElementById('ownership-options').hidden=true;
      document.getElementById('ownership-toggle').setAttribute('aria-expanded','false');
      document.getElementById('ownership-toggle').focus({preventScroll:true});
    });
    document.getElementById('account-share').oninput=updateOwnership;
    adaptFields();
    if(chosenType)collapseTypes();
    updateOwnership();
    document.getElementById('account-currency').onclick=openCurrencies;
  }
  function collapseTypes(){
    document.getElementById('account-type-picker').hidden=true;
    const summary=document.getElementById('account-type-summary');
    summary.hidden=false;
    summary.innerHTML=`${svg(allTypes.indexOf(chosenType))}<strong>${chosenType}</strong><span>Change</span>`;
  }
  function updateOwnership(){
    const share=Number(document.getElementById('account-share').value);
    const label=share===100?'You own all of it':share===50?'You own half':share>0&&share<=100?`You own ${share}%`:'Set your share';
    document.getElementById('ownership-toggle').innerHTML=`<span>${label}</span><span>Change</span>`;
    screen.querySelectorAll('[data-share]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.share==='custom'?![50,100].includes(share):Number(b.dataset.share)===share)));
  }
  function adaptFields(){
    const asset=isAsset(chosenType),debt=isDebt(chosenType);
    const amountInput=document.getElementById('account-amount');
    if(['Checking','Savings'].includes(chosenType))delete amountInput.dataset.moneyMin;
    else amountInput.dataset.moneyMin='0';
    ArgusMoney.refresh(amountInput);
    ArgusMoney.refresh(document.getElementById('account-limit'));
    document.getElementById('account-ownership').hidden=!asset;
    document.getElementById('account-share').disabled=!asset;
    document.getElementById('account-amount-label').innerHTML=`${debt?'Amount owed':asset?'Estimated total value':'Current balance'} <span class="optional">Optional</span>`;
    document.getElementById('account-date-label').textContent=asset?'Estimate as of':'Balance as of';
    document.getElementById('account-details-hint').textContent=asset?'Estimate & loan':debt?'Dates & interest':chosenType==='Cash'?'Balance date':'Bank & balance date';
    document.querySelectorAll('[data-fields]').forEach(block=>{
      const visible={bank:!asset&&chosenType!=='Cash',card:chosenType==='Credit card',debt,asset}[block.dataset.fields];
      block.hidden=!visible;
      block.querySelectorAll('input,select').forEach(input=>input.disabled=!visible);
    });
  }
  const currencyDialog=document.createElement('dialog');
  currencyDialog.className='account-currency-dialog';
  currencyDialog.innerHTML='<div class="account-heading"><h2>Currency</h2><button class="account-close" aria-label="Close currencies">×</button></div><label class="sr" for="account-currency-search">Search currencies</label><input id="account-currency-search" type="search" placeholder="Search name or code" autocomplete="off"><div class="currency-results"></div>';
  document.body.appendChild(currencyDialog);
  currencyDialog.querySelector('button').onclick=()=>currencyDialog.close();
  currencyDialog.addEventListener('close',()=>returnCurrencyFocus?.focus({preventScroll:true}));
  currencyDialog.addEventListener('click',e=>{if(e.target===currencyDialog)currencyDialog.close()});
  function renderCurrencies(query=''){
    const q=query.toLowerCase().trim();
    const codes=window.accountPreviewCurrencies;
    const featured=[chosenCurrency,'DOP','USD','EUR'];
    const ordered=[...new Set([...featured,...codes])].filter(c=>codes.includes(c));
    const matches=ordered.filter(c=>`${c} ${currencyNames.of(c)}`.toLowerCase().includes(q));
    const results=currencyDialog.querySelector('.currency-results');
    results.innerHTML=matches.map(c=>`<button type="button" data-currency="${c}" aria-pressed="${c===chosenCurrency}"><span><strong>${c}</strong><small>${escape(currencyNames.of(c))}</small></span><span>${c===chosenCurrency?'✓':''}</span></button>`).join('')||'<p class="muted">No currencies found.</p>';
    results.querySelectorAll('button').forEach(b=>b.onclick=()=>{
      chosenCurrency=b.dataset.currency;
      ['account-amount','account-limit'].forEach(id=>ArgusMoney.setCurrency(document.getElementById(id),chosenCurrency));
      returnCurrencyFocus.innerHTML=`${chosenCurrency} <span aria-hidden="true">⌄</span>`;
      returnCurrencyFocus.setAttribute('aria-label',`Choose account currency, ${chosenCurrency}`);
      currencyDialog.close();
    });
  }
  function openCurrencies(){returnCurrencyFocus=document.getElementById('account-currency');const input=currencyDialog.querySelector('input');input.value='';renderCurrencies();currencyDialog.showModal();input.focus()}
  currencyDialog.querySelector('input').oninput=e=>renderCurrencies(e.target.value);
  document.addEventListener('submit',e=>{
    if(e.target.id!=='quick-account-form')return;
    e.preventDefault();e.stopImmediatePropagation();
    const balance=ArgusMoney.read(document.getElementById('account-amount')).value;
    const error=document.getElementById('account-error');
    if(!chosenType||!window.accountPreviewCurrencies.includes(chosenCurrency)){error.textContent='Choose an account type and currency.';return}
    const share=Number(document.getElementById('account-share').value);
    if(isAsset(chosenType)&&(!Number.isFinite(share)||share<=0||share>100)){
      error.textContent='Enter your share between 0 and 100%, above zero.';
      document.getElementById('ownership-options').hidden=false;
      document.getElementById('ownership-custom').hidden=false;
      document.getElementById('ownership-toggle').setAttribute('aria-expanded','true');
      document.getElementById('account-share').focus();return;
    }
    const nickname=document.getElementById('account-nickname').value.trim();
    const institution=isAsset(chosenType)||chosenType==='Cash'?'':document.getElementById('account-bank').value.trim();
    const optionalNumber=id=>document.getElementById(id).value===''?null:Number(document.getElementById(id).value);
    const record={...draft,id:draft?.id||previewId(),name:nickname||institution||chosenType,nickname,institution,kind:chosenType,currency:chosenCurrency,balance:balance===null?null:isDebt(chosenType)?-balance:balance,asOf:balance===null?null:document.getElementById('account-date').value,source:'Manual entry',ownershipShare:isAsset(chosenType)?Number(document.getElementById('account-share').value):null,valuationNote:isAsset(chosenType)?document.getElementById('account-source').value.trim():'',linkedDebtId:isAsset(chosenType)?document.getElementById('account-linked-debt').value:null,creditLimit:chosenType==='Credit card'?ArgusMoney.read(document.getElementById('account-limit')).value:null,annualRate:isDebt(chosenType)?optionalNumber('account-rate'):null,paymentDue:isDebt(chosenType)?document.getElementById('account-due').value:null};
    if(window.AccountJourney){
      try{AccountJourney.saveAccount(record,editIndex);draft=null;editIndex=null;}catch(err){error.textContent=err.message;}
      return;
    }
    if(editIndex!==null)accounts[editIndex]=record;else accounts.push(record);
    draft=null;editIndex=null;show('accounts');
    PreviewToast.show('Account saved');
  },true);
  show=function(p){
    oldShow(p);
    phone.classList.toggle('account-entry-mode',p==='manual');
    if(p==='manual')renderManual();
    const existingActivity=p==='accounts'?screen.querySelector('.section'):null;
    if(p==='accounts'){
      screen.innerHTML=`<h1 class="sr">Accounts</h1><div class="surface-list-heading"><h2>${accounts.some(a=>!a.archived)?`${accounts.filter(a=>!a.archived).length} ${accounts.filter(a=>!a.archived).length===1?'account':'accounts'}`:'Accounts'}</h2></div><div id="account-list">${list()||'<p class="muted">Add cash, a bank account or something you owe.</p>'}</div>${accounts.filter(a=>!a.archived).length>5?'<button class="list-disclosure" data-account-expand aria-expanded="false" aria-controls="account-list">Show more accounts</button>':''}${button('Add an account','manual')}<p class="account-demo">Fictional preview · Changes reset on reload</p>`;
      const expand=screen.querySelector('[data-account-expand]');
      if(expand)expand.onclick=()=>{const open=expand.getAttribute('aria-expanded')!=='true';screen.querySelectorAll('[data-account-overflow]').forEach(row=>row.hidden=!open);expand.setAttribute('aria-expanded',String(open));expand.textContent=open?'Show fewer accounts':'Show more accounts';};
      if(existingActivity)screen.appendChild(existingActivity);
    }
    if(p==='home'&&!accounts.length&&window.FinancialSpaces&&FinancialSpaces.current()!=='personal')screen.innerHTML=`<div class="home-overview"><h1>${FinancialSpaces.get(FinancialSpaces.current()).kind==='business'?'Your business, in one place':'Your space, ready to begin'}</h1><p class="muted">Add your first account. A balance can come later.</p>${button('Add an account','manual')}</div>`;
    if(p==='home'&&accounts.length&&accounts.some(a=>a.currency||a.balance==null)){
      const currencies=[...new Set(accounts.map(a=>a.currency||'USD'))];
      screen.innerHTML=`<div class="home-overview">${currencies.map((c,index)=>{
        const group=accounts.filter(a=>(a.currency||'USD')===c),known=group.filter(a=>a.balance!=null),missing=group.length-known.length,hasEstimates=group.some(a=>isAsset(a.kind));
        const categories=[['Cash & bank accounts',a=>['Cash','Checking','Savings'].includes(a.kind)],['Investments',a=>a.kind==='Investment'],['Estimated assets · your share',a=>isAsset(a.kind)],['You owe',a=>isDebt(a.kind)]];
        const total=known.reduce((sum,a)=>sum+ownedValue(a),0);
        const display=new Intl.NumberFormat('en',{style:'currency',currency:c,currencyDisplay:'symbol'}).format(total).replace(/^DOP\s*/, 'RD$');
        return `<section class="home-summary"><h${index?2:1} class="home-summary-label">Recorded net worth <span>· ${c}</span>${PreviewUI.info('networth')}</h${index?2:1}><div class="home-summary-total">${known.length?display:'Balance not added'}</div><p class="home-source">Based on your recorded balances${accounts.some(a=>a.archived)?' · includes archived accounts':''}${hasEstimates?' and estimates':''}.</p>${missing?`<p class="home-incomplete">${missing} ${missing===1?'balance missing':'balances missing'} · Incomplete total</p>`:''}<div class="account-breakdown">${categories.map(([label,predicate])=>{
          const matching=group.filter(predicate);if(!matching.length)return '';
          const valued=matching.filter(a=>a.balance!=null),value=valued.reduce((sum,a)=>sum+ownedValue(a),0),isOwed=label==='You owe';
          return `<div><span>${isOwed&&value>0?'Credit balance':label}</span><strong>${valued.length?fmt(isOwed?Math.abs(value):value,c):'Not added'}${valued.length&&valued.length<matching.length?' + unknown':''}</strong></div>`;
        }).join('')}</div>${hasEstimates?'<p class="home-source">Asset estimates aren’t money available to spend.</p>':''}</section>`;
      }).join('')}<section class="home-account-preview"><div class="sectionhead"><h2>Accounts</h2>${button('View all','accounts','home-view-all')}</div>${list(true)}</section></div>`;

    }
    refineHeader();
  };
})();
