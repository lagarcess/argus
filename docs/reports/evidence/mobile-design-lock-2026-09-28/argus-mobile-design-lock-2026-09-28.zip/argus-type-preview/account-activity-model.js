// Disposable tracker state. Production financial records and permissions remain separate contracts.
(function(root){
  const money=typeof module!=='undefined'?require('./money-input.js'):root.ArgusMoney;
  let ledgerSequence=0;
  class AccountActivity {
    constructor(getAccounts){this.getAccounts=getAccounts;this.namespace=++ledgerSequence;this.openings=new Map();this.entries=[];this.sequence=0;}
    account(id){const a=this.getAccounts().find(a=>a.id===id);if(!a)throw Error('That account is no longer available.');return a;}
    units(value,currency){const p=money.parse(String(value),{currency,required:true});if(!p.ok)throw Error(p.error);return BigInt(p.minorUnits);}
    amount(units,currency){return units===null?null:Number(units)/10**money.config(currency).digits;}
    attach(){for(const a of this.getAccounts()){
      a.id??=`account-${this.namespace}-${++this.sequence}`;a.currency??='USD';
      if(!this.openings.has(a.id))this.openings.set(a.id,{units:a.balance==null?null:this.units(a.balance,a.currency),date:a.asOf||null,source:a.source||'Recorded balance'});
    }}
    effects(e){
      const a=this.account(e.accountId),v=this.units(e.amount,a.currency);
      if(e.type==='balance')return [{id:a.id,set:v}];
      if(v<=0n)throw Error('Enter an amount above zero.');
      if(['expense','income','borrow','refund'].includes(e.type))return [{id:a.id,delta:['income','refund'].includes(e.type)?v:-v}];
      const other=this.account(e.otherId);if(other.id===a.id)throw Error('Choose a different account.');
      if(e.type==='payment'){
        if(other.currency!==a.currency)throw Error('Choose a payment account in the same currency.');
        const fees=this.units(e.fees||'0',a.currency);if(fees<0n||fees>v)throw Error('Interest and fees cannot exceed the payment.');
        return [{id:other.id,delta:-v},{id:a.id,delta:v-fees}];
      }
      if(e.type!=='transfer')throw Error('Choose a supported entry type.');
      const received=a.currency===other.currency?v:this.units(e.received,other.currency);
      if(received<=0n)throw Error('Enter the amount received.');
      return [{id:a.id,delta:-v},{id:other.id,delta:received}];
    }
    checkQuestions(entry,replacing){
      if(entry.type==='balance')return [];
      const index=replacing?this.entries.findIndex(e=>e.id===replacing):this.entries.length;
      return this.effects(entry).flatMap(leg=>{const check=this.entries.slice(0,index).filter(e=>!e.removed&&e.type==='balance'&&e.accountId===leg.id).at(-1);return check&&entry.date<=check.date?[{accountId:leg.id,checkId:check.id,date:check.date,name:this.account(leg.id).name}]:[];});
    }
    validateRefunds(entries){
      const live=entries.filter(e=>!e.removed),totals=new Map();
      for(const e of live.filter(e=>e.type==='refund')){
        const a=this.account(e.accountId);
        if(a.kind&&!['Cash','Checking','Savings','Credit card'].includes(a.kind))throw Error('Use a balance check for this account adjustment.');
        if(!e.originalId)continue;
        const original=live.find(x=>x.id===e.originalId&&x.type==='expense');
        if(!original)throw Error('Restore the original purchase first, or unlink its refund.');
        if(this.account(original.accountId).currency!==a.currency)throw Error('A linked refund must use the purchase currency. Record an unlinked refund with the actual received currency instead.');
        if(e.date<original.date)throw Error('A refund cannot come before its purchase.');
        const total=(totals.get(original.id)||0n)+this.units(e.amount,a.currency);
        if(total>this.units(original.amount,a.currency))throw Error('Linked refunds exceed the purchase. Check the amount or correct the linked refund first.');
        if(e.category!==original.category)throw Error('Keep the refund in the purchase category, or unlink it before changing the category.');
        totals.set(original.id,total);
      }
    }
    calculate(entries=this.entries){
      this.validateRefunds(entries);
      this.attach();const result=new Map([...this.openings].map(([id,x])=>[id,{...x}]));const checked=new Map();
      for(const e of entries){if(e.removed)continue;for(const leg of this.effects(e)){
        const r=result.get(leg.id),check=checked.get(leg.id);
        if(leg.set===undefined&&check&&e.date<=check.date){
          const choice=e.checkResolution?.[leg.id];
          if(!choice||choice.checkId!==check.id)throw Error('Review whether this activity was already included in the checked balance for '+this.account(leg.id).name+'. Record it through Accounts.');
          if(choice.included)continue;
        }
        if(leg.set!==undefined)checked.set(leg.id,e);
        r.units=leg.set!==undefined?leg.set:r.units===null?null:r.units+leg.delta;
        // Dates describe the latest recorded snapshot, not a claimed live connection.
        r.date=e.recordedOn||e.date;r.source=e.type==='balance'?'Updated by you':e.sourceDocument?'Reviewed statement':'Manual activity';
        if(r.units!==null&&(r.units>9007199254740991n||r.units< -9007199254740991n))throw Error('That total is too large for this preview.');
      }}return result;
    }
    sync(){const result=this.calculate();for(const a of this.getAccounts()){const r=result.get(a.id);a.balance=this.amount(r.units,a.currency);a.asOf=r.date;a.source=r.source;}}
    preview(entry,replacing){const next=replacing?this.entries.map(e=>e.id===replacing?{...entry,id:e.id}:e):[...this.entries,entry];return this.calculate(next);}
    save(entry,id){
      this.effects(entry);this.preview(entry,id);
      if(id){const index=this.entries.findIndex(e=>e.id===id);if(index<0)throw Error('That entry is no longer available.');const prior=this.entries[index];this.entries[index]={...entry,id,history:[...(prior.history||[]),{...prior,history:undefined}],removed:false};}
      else {id=`entry-${this.namespace}-${++this.sequence}`;this.entries.push({...entry,id,history:[],removed:false});}
      this.sync();return id;
    }
    saveBatch(batch){
      this.attach();
      const keys=new Set(this.entries.map(e=>e.sourceKey).filter(Boolean));
      const fresh=batch.filter(e=>{if(!e.sourceKey)throw Error('Missing source identity.');if(keys.has(e.sourceKey))return false;keys.add(e.sourceKey);return true;});
      this.calculate([...this.entries,...fresh]);
      const ids=fresh.map(e=>{const id=`entry-${this.namespace}-${++this.sequence}`;this.entries.push({...e,id,history:[],removed:false});return id;});
      this.sync();return ids;
    }
    remove(id){const entry=this.entries.find(e=>e.id===id);if(!entry)throw Error('That entry is no longer available.');this.calculate(this.entries.map(e=>e.id===id?{...e,removed:true}:e));entry.removed=true;this.sync();}
    restore(id){const entry=this.entries.find(e=>e.id===id);if(!entry)return;if(!entry.removed)return;this.preview({...entry,removed:false},id);entry.removed=false;this.sync();}
    moveLinks(id){
      const own=this.entries.filter(e=>e.accountId===id),ownIds=new Set(own.map(e=>e.id));
      return {
        paired:this.entries.some(e=>(e.accountId===id&&e.otherId)||(e.otherId===id)),
        refunds:this.entries.some(e=>e.originalId&&((e.accountId===id&&!ownIds.has(e.originalId))||(e.accountId!==id&&ownIds.has(e.originalId))))
      };
    }
    moveTo(id,target){
      if(target===this)throw Error('Choose a different space.');
      this.attach();target.attach();const account=this.account(id),links=this.moveLinks(id);
      if(links.paired||links.refunds)throw Error('Linked activity needs to stay together.');
      const entries=this.entries.filter(e=>e.accountId===id);
      if(target.getAccounts().some(a=>a.id===id)||entries.some(e=>target.entries.some(x=>x.id===e.id)))throw Error('This account cannot be moved into that space in this preview.');
      // Validate both current ledgers before touching either. The account has no external legs.
      this.calculate();target.calculate();
      this.getAccounts().splice(this.getAccounts().findIndex(a=>a.id===id),1);target.getAccounts().push(account);
      target.openings.set(id,this.openings.get(id));this.openings.delete(id);
      this.entries=this.entries.filter(e=>e.accountId!==id);target.entries.push(...entries);
      this.sync();target.sync();return account;
    }
    activity(id){return this.entries.filter(e=>!e.removed&&this.effects(e).some(leg=>leg.id===id));}
  }
  root.AccountActivity=AccountActivity;if(typeof module!=='undefined')module.exports=AccountActivity;
})(globalThis);
