# Settings, meter semantics and recovery — September 27, 2026

> Historical iteration/evidence record. The final accepted template is [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md); use its current reports and acceptance boundary when implementing. Earlier gaps and recommendations below describe their dated checkpoint.

Status: disposable candidate following founder nitpicks. This does not enable production memory, providers, storage, native sensors or response steering. The earlier approved surface baseline remains checkpointed separately.

## Decisions

| Area | Before | After | Tradeoff / boundary |
| --- | --- | --- | --- |
| Meters | Every Plan meter was teal, including over-budget | Capacity meters inherit teal through 70%, amber above 70%, rose at 90% used; goals remain teal and become success at target | Palette follows meaning. A nearly reached goal is not a warning. Numbers/status remain visible; color is not the only signal. No debt payoff meter without a defensible baseline |
| Personal details | Language repeated Preferences | Avatar, display name, preferred name, account email | Leave Language in Preferences. Do not collect occupation, date of birth, income or household facts simply to fill a profile; ask in the relevant journey when useful |
| Personalization | Same label as memory | Length: Default/Short/Long. Format: Default/Lists/Paragraphs. Tone: Default/Formal/Tutor. Optional custom instructions | Do not add Concise/Comprehensive as competing personalities: they duplicate length. Presentation preferences cannot override facts or critical caveats |
| Memory | Empty placeholder under Personalization | Named Memory; use-confirmed-memory toggle, source, inspect/edit/forget, export and reset | Mirrors existing controls conceptually. Balances, activity and goals belong to records, not memory. Disabling use does not delete saved context |
| Watchlist | No control | Notifications → Watchlist; search, follow/unfollow, opt into scheduled briefs | Separate interest from holdings. Three illustrative assets only. Production discovery must derive provider-backed IDs/catalogs; no static catalog promotion |
| Voice | Two composer icons with loosely related settings | Dictation → editable text; waveform → spoken conversation. Dictation language, voice and speed; read typed replies aloud defaults off | Voice names are examples, not a provider selection. No audio/microphone call. Permission is requested on actual use, not by toggling a sketch preference |
| Files | No inventory | Files & storage with sample size/type/detail and individual/all deletion confirmation | Deleting an original does not silently remove confirmed entries, chats or memories. Real retention/backups/deletion guarantees are pending contracts |
| Advanced | No preferences | Typeahead, reply suggestions, shake to report; all default on in candidate | No inference/runtime changes. Shake would open the existing bug form for review; never send a transcript or diagnostics automatically |
| Authentication | Eye label toggled but artwork stayed the same | Open/closed eye artwork, pressed state, short motion; Terms / Privacy Policy preserved | Existing production auth owns actual validation, captcha, error states, sessions and guest continuity. Sketch does not reimplement authentication |
| Recovery | Immediate Undo only | Data & privacy → Removed financial entries; inspect effects, restore original entry, refresh underlying view | Transfers/payments restore together and cannot duplicate. Later confirmed balances remain. Production recovery window and household permissions remain undecided |

## What the existing code actually does

Inspected the current local checkout; these are code findings, not a live deployed-production verification.

- `web/lib/usage-allowance.ts:105` computes the most constrained hour/day remaining capacity: <=10% danger, <30% warning, otherwise teal. `web/components/settings/UsageModal.tsx:38` maps these to shared `--rui-color-*` tokens. `web/app/globals.css:46` owns teal #5ba897, warning #c2a44d, danger #d66d75. This sketch uses one `meter-semantics.js` owner for the capacity mapping; it is not another production authority.
- `web/components/sidebar/ProfileMenu.tsx:1034` calls the memory entry Personalization. `web/components/settings/MemoryControlsModal.tsx:427` titles the destination Memory. It already supports reviewing why a confirmed memory exists, editing, deleting, disabling use, export and reset. The sketch separates response preferences from that concept.
- `docs/API_CONTRACT.md:6300` records memory as confirmed, registered and role-gated behind default-off availability. It may inform post-interpretation explanations/recall, not simulation truth or routing. The sketch does not relax those gates or sensitivity restrictions. Expanding pivot memory needs its own contract.
- `web/components/auth/AuthForm.tsx:295` swaps Lucide Eye/EyeClosed. It is an icon swap with control styling, not evidence of a custom morph animation. The candidate supplies short visual feedback and respects reduced motion. The original form also has eight-character signup validation, pending-submit protection, localized typed errors and focused email-confirmation state. Preserve those behaviors during implementation.
- `web/components/auth/AuthForm.tsx:372` contains the agreement footer with `/terms` and `/privacy`. Those production pages remain the legal source; preview controls show explanatory notices and do not ask for new agreement.
- `web/components/settings/DeletedItemsView.tsx:63` says listed items can currently be restored. It does not justify inventing a 30-day financial recovery policy. Archived chats, deleted chats and removed financial entries are different lists.

## Ownership and behavior

- Response preferences are explicit settings, not inferred memory. Future conflict precedence between custom instructions and structured preferences must be specified; this sketch stores choices only and never sends them to the model.
- Memory remains off by default in the example. The visible learning-interest record is fictional confirmed context. Account facts, amounts, ownership and permissions do not enter it.
- Dictation defaults on as a feature preference; read-aloud defaults off. Voice conversation speaks by its nature, independent of the typed-chat read-aloud switch. Settings do not grant microphone permissions.
- Watchlist are one set read by the briefing settings. Selecting a result preserves the search query. Following does not add an investment account or promise monitoring/price alerts.
- File inventory is synthetic metadata. Deleting these items deletes no actual files. No invented storage allowance, retention period or immediate backend-erasure guarantee is displayed.
- Removed financial entries read the existing AccountActivity owner. Restore first computes effects without mutation; confirmation restores the original ID and then recomputes balances. A repeated restoration is idempotent. The underlying account/Plan/Search is refreshed when settings closes.
- No permanent financial purge control is offered before recovery, permission and accounting contracts are defined. Recoverability is session-only in this sketch; reload resets examples.
- No occupation field added. If future income planning needs work situation, ask optional employment type or income cadence within that journey, with a stated purpose. Do not treat a job title as a proxy for income or financial literacy.

## Browser steps and findings

1. Budget overview: over-limit teal was a real semantic mismatch. Now rose with visible over amount and accessible status. Goal progress does not turn warning near completion. Captures 01/02.
2. Personalization: Short selection persists across the local settings journey. Separate format/tone/custom instructions avoids contradictory preset bundles. Capture 03.
3. Memory: inspect source and edit fictional context; changed text appears in the list. Turning use off retains records. Capture 04. Production sensitivity checks are not simulated.
4. Files: inventory then Delete all → explicit destructive confirmation → empty state. Other records remain. Capture 05 is the populated view.
5. Personal details: Language absent here and present in Preferences. Existing avatar/display/preferred-name flow retained. Capture 06.
6. Voice: dictation/read-aloud defaults are visibly different; modes and illustrative voices explained. Capture 07. Real audio and OS permission behavior untested.
7. Removed entries: remove Lunch (320), account becomes 73,049.25; reopen through Data & privacy, preview 72,729.25, restore and return. Original Lunch row and spending 2,770.75 reappear without stale balance. Capture 08.
8. Watchlist: Apple search → follow → query retained → include in brief → Notifications reads two followed assets. Capture 09. No live provider request.
9. Auth: Show password changes field to text, label to Hide password and artwork to closed eye; hiding reverses it. Footer has Terms and Privacy Policy. Capture 10. Fictional credentials only.
10. Advanced: all three candidate switches default on. Capture 11. Device shake and actual suggestion behavior remain implementation work.

224 deterministic checks pass across money input, account lifecycle, Plan arithmetic, restoration idempotence and meter boundaries. Output: `journey-audit/settings-pass/deterministic-checks.txt`. Browser console inspection returned no errors/warnings in the checked state. Screenshots are in the same folder; they are not native-device or full accessibility certification.

## Hand off, without silently implementing

Production owners must decide preference storage/localization, custom-instruction precedence, permitted memory categories, provider voice catalog/audio retention, document/derived-record lifecycle, file retention/erasure, and financial recovery permissions/concurrency/retention. Carry the current authentication contract forward rather than replacing it with these local forms. All new copy needs English/Spanish localization before product implementation.


## Final consistency pass — September 27, 2026

- Choice descriptions now sit below their label, with spacing also present in accessible names. This fixes the visibly concatenated response-length choices.
- New settings rows derive muted text and dividers from the existing settings theme. Dark appearance retains the same semantic destructive colors.
- Settings text inputs, feedback fields, time fields and search use 16px text. Labels remain compact; entered content remains legible.
- Settings Back has a 48 × 48 CSS-pixel target. Long option/forms dialogs have viewport-bounded height and internal scrolling.
- Password visibility declares its initial unpressed state before the first interaction.
- Browser verified Memory → Back returns to Personalization when entered there; disabling Dictation yields an explanatory composer notice, without recording.
- Narrow-viewport DOM check reported no horizontal overflow (355 CSS pixels as reported by this browser), a contained custom-instructions dialog and 16px textarea. Reduced-motion transitions resolved to zero. Viewport override was reset.
- All 224 deterministic checks passed again; JavaScript syntax and local HTML asset references passed. Checked browser console contained no errors or warnings.

Evidence: `journey-audit/settings-pass/13-polished-options.png`, `14-dark-voice.png`, `15-login-polish.png`. Candidate experience remains a disposable sketch. Native keyboard, OS permission, audio, storage, authentication and production accessibility acceptance remain separate work; this pass does not claim those are implemented.


## Watchlist and voice scope refinement

Watchlist replaces Followed assets in the screen and notification entry. An outlined star means Save; a filled star means Saved. Scope copy names US stocks, ETFs, crypto and currency pairs, grounded in the existing market-data asset catalog and API contract. A watchlist can mix categories; this does not authorize cross-asset simulations or add holdings. Four examples remain synthetic, not live search.

Speaking speed was removed from settings, preview state and the voice-conversation description. It is deferred until the chosen voice service and native playback behavior are validated. Remaining voice names are explicitly illustrative. Browser verified Save → Saved with count update and the Voice screen without a speed control; refreshed review images. JavaScript syntax passed. Financial calculations were unchanged, so their already-passing suite was not repeated.

Watchlist control placement: Include in briefs now sits directly below the heading, before search and the growing asset list. It stays in normal document flow, without a sticky banner. Browser verified order and toggle operation; JavaScript syntax passed.
