// Home and Updates return to the existing records and review, with no separate status store.
(() => {
  const row=(title,sub,action)=>`<button class="eco-row" data-return="${action}"><span><strong>${escape(title)}</strong><small>${escape(sub)}</small></span><span aria-hidden="true">›</span></button>`;
  const previous=show;
  show=function(p){previous(p);if(!['home','updates'].includes(p)||EcosystemPreview.scope()==='household')return;
    let content='';const scope=EcosystemPreview.scope(),review=EcosystemPreview.importStatus(),attention=ForecastPreview.attention();
    if(p==='home')content+=row('Record activity','Add something that happened','record');
    if(scope==='personal'&&review.started)content+=row(review.done?'Statement reviewed':'Finish reviewing your statement',review.done?review.count+' entries in your records':'Your decisions are saved in this session','import');
    if(p==='updates'){
      if(attention.pending)content+=row(attention.pending.name,'Planned · '+AccountJourney.formatDate(attention.pending.date)+' · Review or record what happened','expected:'+attention.pending.key);
      if(attention.recorded){const entry=AccountJourney.entries().find(e=>e.id===attention.recorded);if(entry)content+=row(entry.description+' · recorded','Linked to your plan · no longer counted as expected','entry:'+entry.id);}
    }
    if(p==='home'){const recent=AccountJourney.entries().filter(e=>e.type!=='balance').at(-1);if(recent)content+=row(recent.description||recent.category,'Latest recorded activity · '+AccountJourney.formatDate(recent.date),'entry:'+recent.id);}
    if(content){const section=document.createElement('section');section.className='loop-return';section.innerHTML=content;const target=p==='updates'?screen.querySelector('.updates-feed'):screen.querySelector('.home-upcoming');if(target)target.before(section);else screen.append(section);}
  };
  document.addEventListener('click',e=>{const b=e.target.closest('[data-return]');if(!b)return;e.preventDefault();const [op,...tail]=b.dataset.return.split(':'),id=tail.join(':'),back=page;
    if(op==='import')EcosystemPreview.importView();
    if(op==='expected')ForecastPreview.openEvent(id);
    if(op==='entry')AccountJourney.openEntry(id,()=>show(back));
    if(op==='record'){
      const eligible=accounts.filter(a=>!a.archived&&!['Property','Vehicle','Other asset'].includes(a.kind));
      const d=document.createElement('dialog');d.className='eco-dialog';d.setAttribute('aria-label','Record activity');d.innerHTML='<h2>Record activity</h2><p class="eco-note">Choose the account.</p>'+eligible.map(a=>row(a.name,a.currency,'account:'+a.id)).join('')+(!eligible.length?'<button class="primary" data-return="add-account">Add an account</button>':'')+'<button class="secondary" data-return="close-picker">Cancel</button>';document.body.append(d);d.showModal();d.addEventListener('close',()=>d.remove());d.addEventListener('click',event=>{const target=event.target.closest('[data-return]');if(!target)return;event.stopPropagation();const action=target.dataset.return;if(action.startsWith('account:')){d.close();AccountJourney.startRecord(action.slice(8),()=>show(back));}if(action==='add-account'){d.close();draft=null;editIndex=null;show('manual');}if(action==='close-picker')d.close();});
    }
  });
})();
