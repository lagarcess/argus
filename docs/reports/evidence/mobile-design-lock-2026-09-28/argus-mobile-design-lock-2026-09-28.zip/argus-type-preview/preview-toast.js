// Sketch adapter for web/components/chat/ChatToast.tsx and useChatToast.ts.
// One transient presenter. Production neutral/error palettes, teal Undo.
window.PreviewToast=(()=>{
  let host,timer;
  function hide(){clearTimeout(timer);host?.remove();host=null;}
  function show(message,variant='neutral',options={}){
    hide();host=document.createElement('div');host.className='preview-toast-host';
    const bubble=document.createElement('div');bubble.className='preview-toast'+(variant==='error'?' is-error':'');bubble.setAttribute('role',variant==='error'?'alert':'status');bubble.setAttribute('aria-live',variant==='error'?'assertive':'polite');
    if(variant==='error'){const icon=document.createElement('span');icon.setAttribute('aria-hidden','true');icon.innerHTML='<svg viewBox="0 0 24 24"><path d="M7 17H4V4h16v13h-7l-4 4v-4M12 7v4m0 2v1"/></svg>';bubble.append(icon);}
    const text=document.createElement('span');text.textContent=message;bubble.append(text);
    if(options.action){const action=document.createElement('button');action.type='button';action.textContent=options.action.label;action.onclick=()=>{hide();options.action.onPress();};bubble.append(action);}
    host.append(bubble);phone.append(host);
    const expire=()=>{clearTimeout(timer);timer=setTimeout(hide,options.durationMs??(options.action?8000:3000));};
    host.addEventListener('pointerenter',()=>clearTimeout(timer));host.addEventListener('pointerleave',expire);host.addEventListener('focusin',()=>clearTimeout(timer));host.addEventListener('focusout',expire);expire();
  }
  return {show,hide};
})();
