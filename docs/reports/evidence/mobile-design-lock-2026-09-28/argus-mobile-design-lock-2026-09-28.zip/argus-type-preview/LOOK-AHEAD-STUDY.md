# Look ahead, activity and invitations — September 27, 2026

> Historical iteration/evidence record. The final accepted template is [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md); use its current reports and acceptance boundary when implementing. Earlier gaps and recommendations below describe their dated checkpoint.

Disposable candidate UI, using the existing sketch records. No production runtime changes.
Open `look-ahead-review.html`. Everything remains in session and resets on reload.

## Explicit locks

Copy invite link; paste into WhatsApp or another channel; do-blitz selected as
short-link integration direction; Resend for email delivery. No rewards or
incentives. Canonical product decision lives in MVEE section 12 and its decision
log pointer. No deployed shortener or email integration is claimed by this UI.

## What changed

- Plan opens on Overview beside Goals, Budgets and Debts. The separate gray
  Look ahead banner is removed. Choose an end date and recorded cash/bank
  balances in one currency. The moving example remains opt-in.
- Repeat supports Never, daily, weekly, every two weeks, monthly, yearly and
  Custom. Custom uses daily/weekly/monthly/yearly frequency, an integer interval
  from 1 to 999, selected weekdays, or a month/day. Missing dates use the last
  day of the month; Last day is also explicit. Web uses number/select controls;
  the native wheel interaction is not implemented or device-verified.
- TradingView Lightweight Charts 5.2.0 now renders the daily closing balance,
  using the installed Argus web dependency, with its license and attribution.
  The old SVG is removed. The regular line connects daily samples without curve smoothing; grid and
  price-axis clutter are hidden, with visible text attribution below. Empty
  expectations show guidance instead of a flat chart. Crosshair and a keyboard day control expose
  dated values. Lowest balance additionally checks intraday expense-first
  ordering, disclosed in What’s included. Ending
  balance, period income/expenses, surplus/shortfall and lowest balance/date
  all derive from one integer-minor-unit projection. Expense-first ordering on
  the same day is a disclosed conservative assumption. Actual balances never
  change when editing assumptions. No historical curve is invented.
- Six upcoming occurrences initially, then Show more. Each opens the expectation
  or lets a person link an already-recorded entry. Matching is explicit, amount
  and type checked, and restricted to selected accounts; each actual entry can
  satisfy one occurrence. Removal or correction invalidates a stale match.
  Linked activity can be unlinked without changing the original record.
- An account’s View all opens activity with that account selected; global Search includes an Activity category using the same filter controls. Filters: account, type, category,
  start/end dates plus text query. They compose, retain on return from the
  original record, clear together, and disclose ten rows then Show more.
  Currency stays on each amount; no misleading mixed-currency total.
- Invitations now start with Copy invite link, Invite by email, optional Choose
  a contact. Selected contact fills email, then user confirms the preview.
  No automatic invite, contact sync, or membership lookup.
- Link acceptance previews recipient sign-in/request and inviter approval;
  email acceptance states verified-recipient binding. A seven-day expiry is a
  candidate, not a locked duration or working backend timer. Cancel remains.
- Acceptance no longer creates a joint wallet or shares existing accounts.
  Received contribution fixture is now zero, consistently with no joint wallet.

## Boundaries and tradeoffs

Forecasts are explicit expectations on the chosen money pool. They are not
imported predictions. The present monthly envelope remains distinct: budgets,
goals, debts and bills are NOT automatically added to Look ahead, avoiding a
false assertion that the unresolved date/matching contracts are complete.
Production integration must link one commitment identity to its dated cash
movement and actual record, count category budgets only to the extent not
already covered by dated obligations, and handle savings transfers by reporting
scope. These links, variable income/ranges, actual history and partial payments
remain technical/product follow-up. Editing a recurring expectation edits its
series in this sketch. The chosen period is today through up to one year.

Household scope reads only shared account IDs and a separate forecast draft.
Private-to-shared transfers remain omitted until redacted-detail design exists.
UI filtering is not server authorization. The incoming sample link opens a
fictional recipient view; it never grants real access. Local localhost links
are for this computer, not public invitations. do-blitz integration needs expiry,
revocation, unguessable invitation IDs, safe redirects and minimal logging;
it must not independently decide membership. No repo/service readiness audit
was performed in this UI pass.

Changing forecast currency replaces this sketch's draft after confirmation;
production should retain independent currency plans. No conversion is assumed.
Contacts and invitations are simulations; neither Resend nor WhatsApp nor the
shortener nor device contacts are called. Native picker/keyboard/permission
behavior still requires device verification. This iteration is English only,
like the existing disposable study; production requires en/es-419.

## Contacts research and recommendation

Cash App uses opt-in contact books and suggestions to shorten finding/inviting
people: https://ai.cash.app/invite-friends . Venmo documents contact sync and
friend/discoverability controls: https://help.venmo.com/cs/articles/manage-your-venmo-privacy-settings-vhel351 .
Apple supports selecting limited contacts rather than requiring the entire book:
https://developer.apple.com/videos/play/wwdc2024/10121/ .

Adopt the low-friction recipient selection. Defer uploading the address book,
network membership discovery, auto-friending and a public activity feed. A generic
acquisition invite must never grant household access. This study focuses on
purposeful partner invitations; it does not add a separate referral campaign.
Provider choices and contacts selection do not imply approval for contact uploads.

## Verification

243 deterministic checks pass (13 forecast checks plus existing 230).
Checks cover cash-flow versus ending balance, timing shortfalls, recurring month
ends, one matched occurrence, past occurrences, invalid ranges, empty forecasts,
and exact repeated minor units. Latest source: `journey-audit/refinement-checks.txt`. Additional checks cover daily/yearly recurrence, multiple weekdays, interval limits, leap years and last-day rules.

Browser checks: moving example gives DOP 165,229.25 ending balance from recorded
DOP 72,729.25, with DOP 196,000 inflows and DOP 103,500 outflows; adding expected
Lunch 320 changes forecast only, and linking recorded Lunch removes that duplicate
outflow. Accounts retains its original balance. Expense filter returns two
existing entries. Selected contact pre-fills the unsent email preview; acceptance
opens an empty household. The earlier standalone Look ahead navigation has since been replaced by Plan Overview.

Phone-width override checked: renderer reported 416 CSS px despite requested
375; no horizontal overflow, monetary/date fields 16px. Native/simulator sizing
is not claimed. Final screenshots use the original phone-frame viewport.
Evidence: `journey-audit/look-ahead.png`, `journey-audit/invite-methods.png` and
`journey-audit/filtered-activity.png`. These are local design evidence, not
release acceptance or a production-ready assertion.

## Refinement: account organization and hierarchy

Candidate experience, pending founder review; no production data policy is locked.

- Accounts → ellipsis → Manage accounts lists Active and Archived. Archive
  removes the account from default account rows, retains all balances in net
  worth and existing projections, and keeps searchable activity. Undo/Restore
  reverses it. It does not mean closing a real bank account or freezing edits.
- Only an unused account with zero/unknown balance, no entry history (including
  removed entries), no linked account/debt plan and no household sharing may be
  removed. Inherited destructive confirmation is used; Restore retains its ID.
- Populated accounts expose Archive rather than a destructive cascade. Full
  account deletion, linked transfers, retention and household permissions remain
  unresolved. Entry removal remains in Activity and affects the recorded balance.
- Repeated This month’s room and Connected journey study rows are removed from
  app surfaces. Review pages remain outside the app. The legacy commitments
  study is still inspectable there; it is not a second competing Plan overview.
- The web library choice does not settle native Swift/Compose chart rendering.

Browser evidence: Plan tabs switch, the example projection renders in the real
chart, a custom Friday/every-two-weeks expectation saves and affects the forecast.
Pocket money archives/restores; Home retains DOP 127,729.25 net worth and states
that archived balances are included. An unused Empty demo account removes via
confirmation, appears under Removed empty accounts, and restores. Populated
accounts offer no removal action. Console errors/warnings were empty.

Repeat weekday keyboard selection passed. Browser automation pointer actions
mis-targeted Monday while targeting Friday even after explicit labels and
separate measured target bounds; direct touch on an actual phone still needs
verification. Do not claim native picker/touch acceptance from this mock.

Current screenshots: `journey-audit/plan-overview-refined.png`,
`journey-audit/custom-repeat.png`, `journey-audit/account-archive.png`.

## Quiet filters, consistent scope, simpler chart (latest refinement)

Design references: Linear’s filter-menu/applied-criteria pattern
(https://linear.app/docs/filters), Notion’s view-level filter controls
(https://www.notion.com/help/views-filters-and-sorts), and Robinhood’s basic
line-chart documentation (https://robinhood.com/us/en/support/articles/using-charts/).
These inform our treatment; this is not a clone or a claim about their internal
chart libraries. Robinhood describes sampled closing prices and portfolio
returns; our screen projects cash balances including expected flows.

- Activity: a 48px sliders control sits beside search. No permanent Filters
  pill or idle Clear link. Active criteria appear as individually removable
  chips; a count marks the filter control. Reset filters is inside the sheet
  and appears only when applicable. It preserves the text search.
- Personal/Household uses the same small context switch at the top of Home, Accounts and Plan. Global Search defaults to everything the viewer can access and offers optional scope in its filter sheet. The former Personal / Household footer row and Household-only pills
  are removed. The selector explains private versus explicitly shared records.
  Switching returns to the same primary surface. Setup and invitations remain
  separate. An old screenshot with a fictional DOP 18,000 household wallet is
  historical and is not current acceptance behavior.
- The line chart now uses Simple interpolation between daily closing samples,
  not WithSteps or smoothed splines. Flat periods still mean no expected change.
  It is a cash projection, not investment performance. No data is fabricated
  to make the curve attractive. Exact values remain inspectable. TradingView
  license attribution is visible as text, following its documented requirement:
  https://tradingview.github.io/lightweight-charts/docs#license-and-attribution

Browser checks: expense filtering gives 2 entries; query Lunch plus reset filters
retains Lunch and 1 entry. Idle state has no reset control. The household setup
path remains reachable; accepting the fictional invite shares no accounts.
Both scopes show the same context control. No real email or provider calls.
Evidence: journey-audit/activity-quiet.png, activity-filtered-quiet.png,
household-scope-current.png, plan-overview-refined.png.


## Navigation, global Search and term help (2026-09-27 refinement)

Candidate disposable UI behavior, not a shipped search or permissions contract.

- Plan uses one shared header: financial view first, Overview / Goals / Budgets /
  Debts second. Overview retains its small currency/projection label in the view
  row. The scope switch and tabs no longer change vertical position by subview.
- Search defaults to everything the current viewer can access, independently of
  the Personal/Household context on financial surfaces. Optional Only me
  or Household scope lives inside Filters, not a second navigation row.
- One horizontal category row derives from the available record inventory:
  All, Accounts, Activity, Plans, Chats, Files, Memory. Plans groups goals,
  budgets and debt plans while result subtitles preserve the subtype. This is
  extensible rather than a fixed four-category product ceiling. Categories stay
  stable while typing; absent record types are not shown. Files use the existing
  settings inventory and search names only; memory uses confirmed study examples.
- Selecting Activity reveals the same account/type/category/date controls as
  Accounts. Both read shared field markup, matching and date validation from
  surface-helpers.js. Each surface retains its own filter state. Global Search
  adds an access-scope option. Active chips and the count appear only when used;
  Reset filters preserves query and category. Activity-specific criteria apply
  only to Activity, and are restored when returning to that category.
- Search is discovery, not an access grant. The prototype only has the current
  viewer's fictional records; partner-private records are not fabricated.
  Production authorization, full document-content search and future record
  providers remain technical work. Files/memory results currently open their
  existing management lists; account/activity results open the exact record.
- Small information buttons appear for recorded net worth, recorded balance,
  estimated asset value, projected balance, goal progress, budget coverage and
  unassigned commitments. One helper owns the explanation dialog. Each has a
  44px target around a 16px icon, a plain explanation and Dismiss with focus
  restoration. Familiar settings labels and existing privacy/destructive-action
  explanations do not receive extra icons.

Reference: https://linear.app/docs/search supports global discovery with optional
refinements. The horizontal category presentation follows the founder's supplied
reference; it is not a claim about Robinhood's internal implementation.

Verification: 243 existing deterministic checks pass. Browser checks verified
Plan header order, net-worth/projected-balance dialogs and Dismiss, global shared
scope returning no invented records, Expense giving two entries in both Search
and Accounts, reset retaining Lunch, and opening/returning from the exact Lunch
entry retaining the query and Activity category. This is desktop browser testing
of a phone-sized study, not native/device or production acceptance.
Evidence: journey-audit/search-unified.png, plan-hierarchy.png,
term-projection.png.


## Discoverability and profile picture refinement

- Search scope copy is All / Only me / Household. One sentence defines Only me
  as unshared records and Household as shared records; All includes both. The
  labels change presentation only, not the underlying permission assumptions.
- Accounts replaces the ellipsis with Manage. The overview owns account listing,
  adding and management; it has no duplicate activity-search entry. An account
  shows up to five recent entries and View all. View all opens the shared activity
  search with a removable account filter and a Back route to the originating
  account. The search field and filters use the same treatment as global Search.
- Personal details has one Edit picture destination, reachable from the image
  or its text label. Choose photo opens the system file picker; Use initial
  restores the existing Argus color picker. A selected JPG/PNG/WebP under 10 MB
  is decoded locally, shown in a circular preview, then explicitly applied with
  Use photo. No server upload or persistence; changes reset on reload. Cancel
  leaves the applied picture intact. Invalid images show a local error.
- Native handoff: use the platform photo picker and a crop/reposition step before
  upload. The sketch uses a centered circular crop and does not claim that
  native editing, HEIC support, cloud storage, or production profile integration
  exists. Photos and initial are alternative representations of one profile.

References: Monarch's account editor keeps account management separate from
transactions (https://help.monarch.com/hc/en-us/articles/360058636951-Edit-Accounts).
Apple's contact picture supports a photo or monogram
(https://support.apple.com/guide/iphone/add-your-contact-info-iph18b749db1/ios).
These inform choices, not a claim that copying either app is necessary.

Browser verification: visible Manage opens account organization; Search scope
shows the three revised options; a synthetic screenshot selected through the
file chooser decoded, previewed and applied; Use initial restored the picker,
Lagoon selected, and chooser cancellation worked. Existing 243 deterministic
checks pass. Evidence: journey-audit/accounts-discovery.png and
journey-audit/profile-picture-choice.png. Native devices were not tested.


## Account navigation and Household return paths

Accounts is an account overview, not another global activity-search surface.
Account detail owns the recent activity preview; View all opens the shared
activity-search screen, scoped to that account. Removing the account chip broadens
results within the current financial view. Back returns to the originating
account even after filters change. Inspecting/correcting an activity entry retains
this list and its filters on return. Global Search remains the cross-record entry.

Household captures its entry point. From Profile & settings, Back restores settings
and the underlying view; from a financial-view selector, Back restores that
surface. Invite → Back returns to Household without replacing that outer return
point. Connected journeys remains a review-only direct route; default study back
buttons no longer leak that menu into the app. Initial view routing now runs after
all surface modules, so direct links have the same controls as navigation taps.

Verified in browser: account → View all shows the removable Everyday spending
filter and four entries; Back → account → Accounts; Settings → Household → Invite
→ Back → Back restores Settings; financial-view setup → Back restores Accounts.
243 existing deterministic checks pass. Evidence: journey-audit/accounts-focused.png
and journey-audit/account-scoped-activity.png. No production code changed.


## Empty activity, consistent notes and private business spaces

Implemented in the disposable sketch, September 28:
- Empty account history has one heading and one short sentence. The opening
  balance stays distinct from activity; no duplicate motivational heading or
  empty income/spending summary.
- All financial activity uses the same optional Add note control: expenses,
  income, transfers, debt payments, borrowing, balance checks and asset estimate
  changes. Goal-progress notes use it too. `entry-notes.js` owns the 200-character
  limit, counter, field and validation. Notes survive review and correction, show
  in entry detail, and participate in activity/global search. A transaction's
  short name and an asset's valuation source remain distinct descriptive fields.
- Home, Accounts and Plan use the same horizontal spaces strip. Start with
  Personal and +. Add offers Household or a privately named Business. Household
  appears when an invitation is pending or accepted; businesses appear on creation.
- Business is private tracking for one person. It starts empty and reuses account,
  activity, goal, budget, debt-plan and cash-projection controls with separate
  state and totals. Categories are optional and can be typed manually; budgets
  can use those same categories. No employees, payroll, invoices or tax accounting.
- Household continues to project explicitly shared Personal accounts, not copies
  of their balances. Business accounts are not offered in household sharing.
  Retirement remains within Personal or Household. Cross-space transfers and
  mixed personal/business transactions remain unresolved and are not simulated.
- Accounts lists/adds/manages accounts. Recent activity → View all opens the shared
  activity screen with a removable account filter. Removing it broadens results
  only within that space. Back retains the originating account.
- Global Search searches all owned spaces plus the existing permitted records.
  Business results carry the business name; opening one activates its owning
  space. Account filters use space-qualified identities, so identical local IDs
  cannot conflate records. Only me includes private business records.
- Household invite → Back → Back restores its originating surface. Connected
  journeys remains a direct review route, not an app back destination.

Verification: 247 deterministic checks passed, including new tests of actual
space/ledger/plan owners for isolation, global collection and invalid names, plus
note-boundary tests. Browser checks covered business creation, an empty account,
balance adjustment with note, 201-character rejection, saved note in detail,
global search across Personal and Business, unchanged Personal totals, separate
business projection, custom category → budget spending, empty business Home,
and Household return navigation. Latest field screenshot:
`journey-audit/consistent-activity-note.png`; space example:
`journey-audit/business-space-home.png`; empty state:
`journey-audit/account-empty-credit.png`.

This is a local session-only sketch. Reload clears changes. Production APIs,
permissions, financial schema and deployment remain unchanged.

## Quiet space navigation candidate

Spaces now use a plain horizontal text row, with dark semibold selection and
muted readable alternatives. No selected pill, fill or underline. The + retains
a 44px target. Home, Accounts and Plan share this control; Plan keeps its
underlined section tabs beneath it. Filled pills remain action controls. This
is a founder-requested visual trial, not a change to production DESIGN.md.
Robinhood's public support describes search and filter capabilities but did not
provide a verified current mobile screenshot of this precise hierarchy; this
trial should not be represented as a copy of its current interface.

Plan header cleanup: the space row contains only spaces and Add. Removed the
redundant currency/cash-projection caption and its header argument; currency stays
with the projected amount and account selection. This gives spaces the full row.


## UI completion checkpoint — September 28, 2026

This checkpoint freezes the template for engineering handoff. It is fictional,
local session state, not a production ledger or permission implementation.

| Journey | Action → result → recovery |
| --- | --- |
| Home | Coming up reads the same Plan projection, shows two upcoming items, included accounts/currency and end date; View plan opens Overview. No expectations produces a quiet next-step invitation, not a zero-spend estimate. |
| Connected payment | In Plan, Try a moving example → Rent → related Housing budget or Record payment made. Confirm the actual account/date and optional 200-character note. One actual entry replaces that occurrence. Open linked activity to correct/remove it; the link is revalidated. |
| Household | Add a space → Household → fictional invite/acceptance → Household Plan → Goals → Try a shared plan example. Moving fund shows contributors, planned amounts, unlinked progress and Sam’s view/edit access. Private plans and source accounts are never pulled in. |
| Recovery | Remove an entry → Profile → Data & privacy → Removed financial entries. The global list and confirmation name its original private space and account. Restore the original id and both account legs where relevant. |
| Refunds | Record new activity → Refund. Partial refunds can link a same-currency original purchase, inherit its category and stay capped by the purchase. Unlinked returns remain explicitly unlinked. Refunds reduce spending in the month received, not income. Card credit is supported. |
| Balance checks | Check balance shows the discrepancy before confirmation. A subsequent activity dated on/before that check asks whether it was already included, separately for each affected account. Included activity leaves the checked balance unchanged. |

Loan principal/interest reversals still require the production contract. The
sketch offers a truthful unexplained balance check, not a fabricated purchase
refund. Property/vehicle changes remain estimates. Foreign-currency refunds use
actual received money with no guessed conversion or purchase link.

The explicit balance question prevents the demonstrated double-count case; it
does not implement residual-adjustment matching, event-time accounting or
concurrent corrections. Batch imports/forecast shortcuts encountering a prior
check stop and direct the person to Accounts review. These remain backend
handoff obligations, not a claim that the toy replay is production accounting.

Check: `node --test *.test.cjs` — 257 passing. Browser evidence in journey-audit:
recovery-space-confirmation.png, shared-plan-contributors.png,
refund-already-in-card-balance.png, completion-home.png. Earlier screenshots
remain historical; completion-home.png is the final visual checkpoint.

Toast refinement: `preview-toast.js/css` adapts the existing Argus ChatToast
neutral/error palettes and teal Undo. Account saves, entry removal, archive Undo
and settings feedback share it. It overlays rather than pushes content, replaces
older toasts, honors reduced motion and pauses dismissal on focus/hover. Evidence:
`journey-audit/production-toast-undo.png`. Inline validation remains inline.


## Account reassignment — September 28 checkpoint

Accounts → Manage → choose account → Move to another space. Choose or explicitly
create a private business destination, review source/destination and affected
budgets, then confirm. The original account and full history (including removed
entries) move together. The confirmation opens the destination account and uses
the shared toast. Move back through the same control. Cancel never moves records.
Share with household stays a separate action and routes to the existing consent
flow; joining alone shares nothing.

Linked transfers/payments (even removed ones), cross-account refunds, asset/loan
links, household access, forecast references, debt plans, documents and drafts
produce an explicit blocked state. No partial/group migration is simulated.

Verification: 262 deterministic checks passed, including preserved ids/history/
notes/recovery, reverse moves, budget effects, link blocking and id collision
avoidance. Browser verified no-destination creation, a blocked linked transfer,
confirmation, destination naming and unchanged balance. Screenshots:
`journey-audit/account-space-move-review.png` and
`journey-audit/account-space-move-blocked.png`.


### Quiet forecast date control — September 28, 2026

Until sits beneath Plan tabs, immediately above the projected balance. The
localized short-month date is right aligned, borderless, with a small chevron
and a full 44px native date-input target. Keyboard focus remains visible; the
existing date bounds and projection calculation are unchanged. This inherits
the production cards’ quiet display/progressive editing principle without
copying their two-date backtest controls.


### Forecast range continuity

Changing Until does not remove the chart from an existing plan just because
no pending movements fall inside the selected period. In that case, show the
flat projected recorded balance and explain that there are no planned movements
in this period. A genuinely empty plan still shows setup guidance. Expectations
outside the period remain stored; extending the date brings them back.


## Connected plan closure — September 28, 2026

Debt and savings intentions now own their optional projection link: funding account, destination and date. Overview derives monthly movements from those plans. It never copies their amounts into another expectation store. Plans without usable funding/date show why they are excluded. Internal transfers remain visible with zero combined-cash effect. Budgets remain limits, not extra outflows.

Recording/linking a fulfilled occurrence points to the original activity. Amount corrections update actual cash while that explicitly fulfilled occurrence stays fulfilled; changing its type/accounts invalidates the relationship. Removal restores the expectation and recovery reconnects it. Goal progress derives linked transfers plus the last explicit total checkpoint; a total update records the linked amount already included. This is a fictional experience model, not a settled backend recurrence/reconciliation contract.
