# Appearance persistence — September 28, 2026

> Historical iteration/evidence record. The final accepted template is [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md); use its current reports and acceptance boundary when implementing. Earlier gaps and recommendations below describe their dated checkpoint.

The sketch now has one appearance owner, theme-preference.js, loaded before body rendering. Light, Dark and System are stored under an isolated preview key. Only this preference persists; financial records and profile data remain fictional session state. System tracks OS changes, storage events synchronize updated tabs, and blocked storage keeps the choice for the current visit with an honest notice.

The root semantic palette applies across surfaces and body-mounted dialogs. Settings no longer removes the theme on exit. Forecast chart colors follow the same resolved appearance without resetting dates or records. Production already uses next-themes; inherit that owner during implementation, not this standalone adapter.

Validation: four focused tests passed (all three reload choices, device changes, blocked storage, invalid values and storage removal). Browser keyboard walkthrough confirmed Light, Dark and System after reload, plus Dark after exiting Settings into an account. Screenshot: journey-audit/theme-persistent-dark.png. Comprehensive dark-mode contrast and native-device acceptance are not claimed.

## Chat-mode discussion: no header change yet

Fetched integration contains the earlier three-mode sketch in docs/archive/2026-09-26-argus-answers-that-stay-true-roadmap.md: regular, private using context without learning, incognito without memory and discarded on leaving. Current web ChatHeaderMenu and memory-privacy implementation offer the narrower Private chat memory opt-out. The archived proposal is not a shipped retention contract. Recommend a chat-mode selector replacing the profile shortcut on an empty chat, preserving active-chat share/menu controls. Reuse existing scope and distinguish context use, memory writes and retention. No privacy guarantee or new implementation scope is approved by this note.

Follow-up: TEMPORARY-CHAT-STUDY.md owns the subsequent founder-requested one-mode UI sketch and chat dark-theme corrections. The initial recommendation above is retained as discussion history.
