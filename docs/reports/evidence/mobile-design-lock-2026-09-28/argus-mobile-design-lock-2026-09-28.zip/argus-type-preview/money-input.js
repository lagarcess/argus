// Disposable UI owner for money entry. No production persistence contract.
(function(root){
  const locale='en-US'; // This sketch is English; input separators follow UI locale, not currency.
  const escapeRegex=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  function config(currency,language=locale){
    const formatter=new Intl.NumberFormat(language,{style:'currency',currency,currencyDisplay:'code'});
    const digits=formatter.resolvedOptions().maximumFractionDigits;
    const parts=new Intl.NumberFormat(language).formatToParts(1234567.5);
    const group=parts.find(p=>p.type==='group')?.value||',';
    const decimal=parts.find(p=>p.type==='decimal')?.value||'.';
    const symbol=new Intl.NumberFormat(language,{style:'currency',currency}).formatToParts(0).find(p=>p.type==='currency').value;
    return {currency,language,digits,group,decimal,symbol,formatter};
  }
  function parse(raw,{currency='USD',language=locale,required=false,min=null,max=1e12}={}){
    const c=config(currency,language);
    let text=String(raw).trim().replace(/\u2212/g,'-');
    const fail=error=>({ok:false,error});
    if(text.length>80)return fail('Enter just the amount and its currency.');
    if(!text)return required?fail('Enter an amount.'): {ok:true,value:null,canonical:'',minorUnits:null};
    const markers=[currency,c.symbol,...(currency==='DOP'?['RD$','$']:currency==='USD'?['US$','$']:[])].sort((a,b)=>b.length-a.length);
    let negative=false;
    if(text.startsWith('-')){negative=true;text=text.slice(1).trim()}
    for(const marker of markers){
      if(text.toUpperCase().startsWith(marker.toUpperCase())){text=text.slice(marker.length).trim();break}
      if(text.toUpperCase().endsWith(marker.toUpperCase())){text=text.slice(0,-marker.length).trim();break}
    }
    if(text.startsWith('-')&&!negative){negative=true;text=text.slice(1).trim()}
    if(text.startsWith(c.decimal))text='0'+text;
    const decimal=escapeRegex(c.decimal),group=escapeRegex(c.group);
    const pattern=new RegExp(`^(?:[0-9]+|[0-9]{1,3}(?:${group}[0-9]{3})+)(?:${decimal}[0-9]+)?$`);
    // No guessing between decimal and group separators; no exponent notation or discarded letters.
    if(!pattern.test(text))return fail(`Use ${new Intl.NumberFormat(language,{minimumFractionDigits:c.digits,maximumFractionDigits:c.digits}).format(1234)} (${currency}). Check separators and currency.`);
    let [whole,fraction='']=text.split(c.decimal);
    whole=whole.split(c.group).join('').replace(/^0+(?=\d)/,'');
    if(fraction.length>c.digits)return fail(`${currency} allows ${c.digits===0?'whole amounts only':`up to ${c.digits} decimal places`}. Nothing was rounded.`);
    fraction=fraction.padEnd(c.digits,'0');
    const units=BigInt(whole+fraction)*(negative?-1n:1n);
    if(units>BigInt(Number.MAX_SAFE_INTEGER)||units< -BigInt(Number.MAX_SAFE_INTEGER))return fail('That amount is too large for this preview.');
    const canonical=`${negative&&units!==0n?'-':''}${whole}${c.digits?'.'+fraction:''}`;
    const value=Number(canonical);
    if(value>max||value< -max)return fail('That amount is too large for this preview.');
    if(min!==null&&value<min)return fail(min===0?'Enter zero or a positive amount.':`Enter at least ${c.formatter.format(min)}.`);
    return {ok:true,value,canonical,minorUnits:units.toString()};
  }
  const api={parse,config};
  root.ArgusMoney=api;
  if(typeof module!=='undefined')module.exports=api;
  if(typeof document==='undefined')return;
  const mounted=new WeakMap();
  function options(input){return {currency:input.dataset.moneyCurrency||'USD',required:input.required,min:input.dataset.moneyMin==null?null:Number(input.dataset.moneyMin),max:Number(input.dataset.moneyMax||1e12)}}
  api.read=input=>parse(input.value,options(input));
  function render(input,{validate=false,format=false}={}){
    const ui=mounted.get(input);if(!ui)return;
    const c=config(options(input).currency),result=api.read(input);
    ui.marker.textContent=c.currency==='DOP'?'RD$':c.symbol;
    input.placeholder=new Intl.NumberFormat(locale,{minimumFractionDigits:c.digits,maximumFractionDigits:c.digits}).format(0);
    if(format&&result.ok&&result.value!==null)input.value=new Intl.NumberFormat(locale,{minimumFractionDigits:c.digits,maximumFractionDigits:c.digits}).format(result.value);
    const invalid=validate&&!result.ok;
    input.setAttribute('aria-invalid',String(invalid));
    ui.hint.classList.toggle('money-invalid',invalid);
    if(invalid)ui.hint.textContent=result.error;
    else if(result.ok&&result.value!==null)ui.hint.textContent=c.formatter.format(result.value)+(input.dataset.currencyChanged?' · Amount not converted':'');
    else ui.hint.textContent=`${c.currency} · ${c.digits===0?'No decimal places':`${c.digits} decimal places`} · e.g. ${new Intl.NumberFormat(locale,{minimumFractionDigits:c.digits,maximumFractionDigits:c.digits}).format(1234)}`;
    return result;
  }
  function mount(input){
    if(mounted.has(input))return;
    input.type='text';input.inputMode='decimal';input.autocomplete='off';input.spellcheck=false;
    const wrap=document.createElement('div');wrap.className='money-control';
    const marker=document.createElement('span');marker.className='money-marker';marker.setAttribute('aria-hidden','true');
    input.before(wrap);wrap.append(marker,input);
    const hint=document.createElement('p');hint.className='money-hint';hint.id=`${input.id}-money-hint`;hint.setAttribute('aria-live','polite');
    wrap.after(hint);input.setAttribute('aria-describedby',[input.getAttribute('aria-describedby'),hint.id].filter(Boolean).join(' '));
    mounted.set(input,{marker,hint});
    // Do not rewrite on focus: it can destroy select-all or move a touch caret.
    // Parse formatted text directly; normalize only on blur or submission.
    input.addEventListener('input',()=>{delete input.dataset.currencyChanged;render(input);}); // Preserve the caret and partial decimal while typing.
    input.addEventListener('blur',()=>render(input,{validate:true,format:true}));
    render(input,{format:true});
  }
  api.refresh=input=>{mount(input);render(input,{validate:!!input.value,format:true});};
  api.setCurrency=(input,currency)=>{if(input.dataset.moneyCurrency!==currency&&input.value.trim())input.dataset.currencyChanged='true';input.dataset.moneyCurrency=currency;api.refresh(input);};
  const scan=()=>document.querySelectorAll('input[data-money-currency]').forEach(mount);
  new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener('submit',event=>{
    let firstInvalid=null;
    event.target.querySelectorAll('input[data-money-currency]:not(:disabled)').forEach(input=>{
      mount(input);if(!render(input,{validate:true,format:true}).ok)firstInvalid??=input;
    });
    if(firstInvalid){event.preventDefault();event.stopImmediatePropagation();const details=firstInvalid.closest('details');if(details)details.open=true;firstInvalid.focus();}
  },true);
  document.addEventListener('reset',event=>queueMicrotask(()=>event.target.querySelectorAll('input[data-money-currency]').forEach(input=>render(input))));
  scan();
})(globalThis);
