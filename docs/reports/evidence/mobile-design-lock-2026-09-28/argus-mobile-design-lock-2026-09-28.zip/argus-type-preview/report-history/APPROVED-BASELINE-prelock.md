# Argus sketch — approved visual and interaction baseline

Founder accepted this sketch as the current design baseline on September 27, 2026: “ok good enough, lock all of this”.

Entry point: `index.html`, currently served at http://127.0.0.1:8025/.
This document records the accepted sketch. `INHERITANCE.md` contains source comparisons, detailed decisions and verification limits. It does not supersede repository product/API/data authority or authorize production implementation, deployment, or unfinished native capabilities. `typography.html` is an earlier exploration, not this baseline.

## Preserve when continuing the design

- Keep the current Argus visual identity: restrained near-black/white surfaces, muted semantic accents, Space Grotesk and Inter. Bundled fonts match the repository assets. Financial amounts stay neutral unless an actual status/change warrants semantic color; figures use tabular numerals.
- Primary CTAs are near-black pills with white labels; secondary actions use a light neutral fill. Surface CTA targets are at least 48px. Remove decorative CTA arrows; use chevrons for navigational rows. Keep appropriate chat-specific follow-up behavior distinct.
- Shared mobile surface headings use Space Grotesk 500 at 32/22/18px; body uses Inter. Existing chat/settings-specific sizes remain. Marketing headline sizes are not mobile defaults.
- Bottom navigation: Home, Accounts, Chat, Plan, Search. Preserve the glass treatment and icon-only presentation. Reading scroll shrinks the main-surface bar while retaining all five destinations; upward scroll expands it. Updates keeps its separate hide-on-scroll treatment. Profile/settings keeps its own navigation treatment.
- Header: bell/profile outside active conversations. Empty Chat keeps Recents/New chat plus bell/profile; active Chat keeps Recents/New chat plus Share/More. No phone conversation title or redundant Argus branding in the chat header. Recents/Search/options retain titles. New chat has one header entry point. Header targets are 48px, with 8px group gaps and 16px side spacing.
- Preserve the continuous scroll-edge blur without solid banner seams; Profile & settings overview and Personal details are excluded. Keep reduced-motion/transparency behavior.
- Preserve inherited profile icons, avatar choices, feedback types/templates and settings details. Shared Conversations naming, notification settings concept, Rate the App concept, smaller ghost A and version/build placeholder remain.
- Preserve the time-sensitive greeting, starter prompts and empty-chat A. The subtle neutral edge-light study is decorative, not loading; reduced motion disables it.
- Composer: two rows, “Type a message” placeholder, Plus below left, dictation and future spoken-conversation controls below right. Text/attachments reveal Send in place of the waveform. Keep 48px toolbar targets and 8px spacing.
- Plus opens the composer-attached tray with Scan receipt, Choose photo and Upload file; it replaces starter chips while open. No separate context picker or mock @ anchoring. Existing production mentions are not changed.
- Typing closes the tray. Opening Plus while typing exchanges the keyboard for the tray. On a real phone, keyboard appearance hides the menu and positions the composer directly above the keyboard; keyboard dismissal restores the resting composer/menu. Avoid an intermediate layout jump. Desktop focus without a software keyboard leaves navigation available.
- Outside background taps dismiss keyboard/tray without clearing or sending. Scrolling alone does not dismiss them. Interactive controls retain their first-tap action. Drafts persist across surface switches in the local session. Escape respects the active dialog/tray/focus layer.

## Account entry acceptance — September 27, 2026

Founder accepted the simplified account entry and money controls: “Perfect,
looks better and simpler … let’s lock it.” This extends the approved baseline.

- Short creation: choose a type, optional nickname, currency and optional value.
  The chosen type folds into a compact Change row. Extra financial details are
  available when editing a saved item, not during initial creation.
- Optional property, vehicle and other asset entry; plain-language ownership
  choices (all, half, another share). Calculate the personal portion without
  duplicating the asset or its related debt.
- One consistent money-entry treatment across account balances, asset estimates,
  credit limits, goals and proposal corrections. Currency markers, separators,
  cents, unknown values and validation follow the recorded design direction.
- Repository experience owner: MVEE “Quick account setup and optional assets.”
  Money interaction owner: DESIGN.md “Money entry in the ecosystem sketch.”
  `ACCOUNT-ENTRY-STUDY.md` describes the accepted implementation; source comparison
  and verification limits are in `MONEY-ENTRY-AUDIT.md`.

Carry this accepted behavior forward. The subsequently requested account
journey is implemented for review in `ACCOUNT-JOURNEY-STUDY.md`; it is not yet
part of this approved baseline. Real-device/native checks and production
contracts remain implementation work.

## Boundaries that remain open

Native keyboard transitions, safe areas, hardware touch targeting, native back gestures and haptics still require device verification. The web sketch uses a viewport heuristic and does not establish native acceptance. Some toolbar pointer checks were unreliable through browser automation and were checked with keyboard activation instead.

All accounts, chats, captures, proposals and settings are disposable local examples. Reload resets session data. No live model, microphone, camera, upload, bank connection, persistence, notifications, sharing publication or store integration is implied. Final account onboarding, real cross-surface context transport and backend contracts remain separate work. Design acceptance is not runtime acceptance.

## Preservation

A timestamped sibling checkpoint contains this complete sketch, font assets/licenses, inheritance notes, available preview screenshots and SHA-256 checksums. The zip archive is verified against those bytes. Earlier checkpoints remain intact. Continue subsequent exploration in the working sketch without rewriting this checkpoint.

## Account clarification and balance-check lock — September 27, 2026

Founder requested “fix UI and lock it, and record the note for the backend.”
Account setup ends with the saved starting balance. Record new activity adds a
transaction; an activity row opens an existing entry; the pencil edits metadata.
Check balance previews the recorded/observed values and difference before an
explicit confirmation. Adjustments stay visible and outside income/spending.
Unknown and matching balances have their own explanations. Source/category is
optional and does not duplicate the selected activity type. Required amount
errors are inline. Entry removal inherits the existing Argus confirmation dialog
and rose destructive action, with truthful immediate Undo in this sketch.

Canonical experience: MVEE “Account activity and balance checks.”
Canonical visual pattern: DESIGN.md “Destructive confirmations.”
Backend handoff: `docs/specs/argus-account-balance-reconciliation-handoff.md` in
the repository. Production reconciliation remains unresolved and unimplemented.

### Shared destructive treatment across surfaces

The rose family now applies to account-entry removal, preview-chat deletion,
Delete all conversations and Request account deletion in Profile & settings.
`confirm-preview.js` and `confirm-preview.css` own confirmation presentation for
all four; palette.css remains the color owner. Contact support retains the
production soft-rose request treatment, while delete/remove uses a filled rose
action. Settings controls remain simulations: no support request or real chat
deletion occurs. Ordinary navigation to Recently Deleted remains neutral.

## Populated Home and growing-list lock — September 27, 2026

Founder approved the simplified Home and requested explicit inheritance notes.
`HOME-STUDY.md` records the accepted preview and links to repository owners.
DESIGN.md “Growing lists across ecosystem surfaces” owns the cross-surface
behavior; MVEE “Populated Home summary and list boundary” owns product meaning.
Existing Recents/Omnisearch behavior is identified for reuse. At that approved checkpoint, only Home preview navigation was implemented.
The subsequent surface-polish candidate is documented in SURFACE-NITPICK-REVIEW.md;
it adds local list disclosure, not production pagination. Currency-separated summaries remain the current behavior.

## Surface review approved — September 27, 2026

Founder: “back to the surface review, i like it, lock it.”
The Accounts, Plan goal overview, Updates, Search grouping, and settings polish
in SURFACE-NITPICK-REVIEW.md are now approved as a disposable design baseline.
This includes inherited list disclosure, typography, primary pill controls and
shared preview records. It does not approve production data/auth contracts.
Next requested exploration: budgets, debt plans, goal progress, activity search,
login/social sign-in presentation, and cross-surface motion. Those additions
remain candidates until reviewed. The approved checkpoint is:
argus-sketch-20260927-172317-approved-surface-review.zip


## Connected-loop checkpoint — September 28, 2026

The founder requested closure of the four audited handoffs. See [LOOP-CLOSURE.md](LOOP-CLOSURE.md) for implementation, before/after decisions, verification and limits. Earlier notes saying linked actual savings are absent or describing a separate monthly-room calculation are superseded by this checkpoint. The same account ledger now supports sample capture, plan-linked activity, received household contributions, and correction/recovery. This is a local template checkpoint for review, not production implementation or deployment approval.

## Simplified chat header — September 28, 2026

Founder approved the Temporary chat naming, optional Use my context control and simplified state-aware header. [TEMPORARY-CHAT-STUDY.md](TEMPORARY-CHAT-STUDY.md) owns the locked header matrix, motion, recovery and verification. Production privacy contracts remain separate.

## Space lifecycle refinement — September 28, 2026

Founder requested completion of space creation and removal within the template. [SPACE-LIFECYCLE-STUDY.md](SPACE-LIFECYCLE-STUDY.md) records Custom spaces, shared naming/move flow, rename, archive, empty-space deletion and recovery. Production limits and lifecycle contracts remain separate.

## Chat recovery refinement — September 28, 2026

Founder requested coherent Recents search/empty states, Archive in chat options, and a complete temporary-to-regular transition. New chat stays left; temporary mode stays right. See [CHAT-RECOVERY-STUDY.md](CHAT-RECOVERY-STUDY.md) for behavior and evidence.

### Settings grouping · 2026-09-28

The root keeps Personal details as its identity row, then groups direct destinations by purpose: App (Preferences, Personalization, Notifications), Account (Security, Data & privacy, Usage), Support (Help & feedback). Usage is an account control. Group boundaries use quiet labels and whitespace; separators only divide rows within a group. No additional navigation level. Existing destinations and recovery flows remain unchanged. Syntax checked; browser verified root grouping, Usage and Help destinations, and return navigation. Screenshot: journey-audit/settings-groups-dark.png.

Settings no longer duplicates Spaces or Household management. Use the existing space controls (+ → Manage spaces) and Manage household entry. The root groups are App, Account, Support.
