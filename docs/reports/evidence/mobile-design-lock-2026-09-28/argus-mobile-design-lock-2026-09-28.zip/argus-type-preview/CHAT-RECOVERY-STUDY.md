# Recents, chat actions and temporary exit — September 28, 2026

Founder requested consistent search, useful empty states, missing archive behavior, and a complete exit from temporary chat. The follow-up explicitly rejects moving New chat between sides.

## Experience

- Recents shares the quiet underlined search treatment with Search and Activity. Semantic theme tokens, explicit clear control, a visible focus underline, and 44px clear target replace the bulky focused field. Native search cancellation is replaced by the named clear action.
- True cold start has no seeded history. Populated examples remain under `?demo=accounts`. No orphan example chats appear in global Search.
- No chats yet, No recent chats after archiving/deletion, and No results are distinct. Each offers New chat. A search query becomes an editable draft, never an automatic send. An archive-only empty list also offers View archived chats.
- More is ordered Mark unread/read, Pin/unpin, Rename, Archive/unarchive, separator, Delete. Every action has an inherited icon. Temporary entry is removed from this menu.
- Archive keeps the conversation and Search identity, hides it from Recents, and supports Undo and Settings → Data & privacy → Conversations → Archived chats → Restore. Delete uses the shared rose confirmation and Recently deleted recovery. Delete all conversations operates on this same mock library, not an unrelated placeholder.
- New chat stays on the left. In temporary mode it is available before and after sending, labeled New regular chat. The right dashed-bubble icon remains temporary settings. Return to regular chat in mode settings restores the previous regular conversation/draft; New regular chat starts fresh.
- Empty temporary sessions exit directly. A draft, attachment or transcript invokes the existing discard confirmation. Cancel preserves it. No icon changes sides or changes semantic meaning.

## Inheritance and scope

Inspected production ChatHeaderMenu.tsx, useArchiveActiveConversation.ts and ArchivedChatsView.tsx. The existing archive hook and settings recovery inform this sketch; the inspected production header menu itself did not contain an archive row. No production runtime or retention contract changes are claimed. This local study resets on reload and makes no model calls.

## Verification

288 checks pass, including five focused chat-library checks: no invented cold-start Search/history, archive transcript and Search identity preservation, delete/restore, temporary exclusion with regular continuity, and delete-all recovery. Browser keyboard checks covered cold start, no results to an unsent draft with composer focus, archive removal from Recents, settings and direct empty-state archive recovery, restored Recents entry, light/dark visuals, empty temporary exit, cancellation preserving a draft, and confirmed active temporary exit. Left-side New chat x-position matched between regular and temporary states. Undo now restores the record without unexpectedly navigating away from the user's current surface. No full native accessibility audit is claimed.

Evidence in journey-audit: recents-no-results-dark.png, recents-cold-light.png, chat-options-archive.png, chat-recovery-tests.txt.

## Composer attachment motion correction

Regular-chat suggestions now collapse on the same 200ms grid transition as the attachment tray opens. Removing them with display:none had caused an instant hero jump followed by movement back as the tray grew. The greeting and logo stay mounted; hidden suggestions are inert and excluded from accessibility while the tray is open. Temporary chat keeps its zero-height suggestion area. Reduced motion disables both transitions.

Verified regular opening and closing with sampled DOM geometry (monotonic logo movement), pointer and keyboard activation, preserved composer draft, and temporary attachment opening. JavaScript syntax checks pass; browser console has no errors. Evidence: journey-audit/composer-attachment-motion.json and composer-attachment-motion.png. No native keyboard or full accessibility audit claimed.
