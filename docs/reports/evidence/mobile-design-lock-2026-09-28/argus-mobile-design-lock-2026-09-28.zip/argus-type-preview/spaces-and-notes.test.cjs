const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const notes=require('./entry-notes.js');
function setup(){
  const noop=()=>{};
  const node={addEventListener:noop,append:noop,appendChild:noop,classList:{add:noop,remove:noop,toggle:noop}};
  const ctx={console,URLSearchParams,Event,location:{search:''},loaded:false,accounts:[{id:'bank',name:'Personal checking',kind:'Checking',currency:'DOP',balance:1000}],draft:null,editIndex:null,show:noop,headerGlyph:()=>'',screen:node,phone:node,escape:String,document:{createElement:()=>({...node}),addEventListener:noop,dispatchEvent:noop,body:node},ArgusMoney:require('./money-input.js'),AccountActivity:require('./account-activity-model.js')};
  ctx.window=ctx;vm.createContext(ctx);
  for(const f of ['plan-preview.js','account-journey.js','financial-spaces.js'])vm.runInContext(fs.readFileSync(__dirname+'/'+f,'utf8'),ctx);
  vm.runInContext('globalThis.Plans=PlanPreview',ctx);
  return ctx;
}
const expense={accountId:'bank',type:'expense',amount:'50',date:'2026-09-28',memo:'Supplies'};
test('private business balances and activity survive switching without changing Personal',()=>{
  const c=setup();c.AccountJourney.recordExpense(expense);c.Plans.all().push({id:'personal-goal',name:'Emergency fund'});
  const business=c.FinancialSpaces.create('Studio');assert.equal(c.accounts.length,0);assert.equal(c.Plans.all().length,0);
  c.accounts.push({id:'bank',name:'Studio checking',kind:'Checking',currency:'DOP',balance:500});c.AccountJourney.recordExpense({...expense,amount:'25'});
  assert.equal(c.accounts[0].balance,475);
  c.FinancialSpaces.activate('personal');assert.equal(c.accounts[0].balance,950);assert.equal(c.AccountJourney.entries()[0].amount,'50');assert.equal(c.Plans.all()[0].name,'Emergency fund');
  c.FinancialSpaces.activate(business.id);assert.equal(c.accounts[0].balance,475);assert.equal(c.AccountJourney.entries()[0].amount,'25');assert.equal(c.Plans.all().length,0);
});
test('global collection includes both spaces and restores the original owner even on error',()=>{
  const c=setup(),b=c.FinancialSpaces.create('Studio');c.accounts.push({id:'bank',name:'Studio checking',kind:'Checking',currency:'DOP',balance:null});
  const all=c.FinancialSpaces.allAccounts();assert.equal(all.length,2);assert.notEqual(all[0].spaceId,all[1].spaceId);assert.equal(c.FinancialSpaces.current(),b.id);
  assert.throws(()=>c.FinancialSpaces.collect(()=>{throw Error('failed reader');}));assert.equal(c.FinancialSpaces.current(),b.id);assert.equal(c.accounts[0].balance,null);
});
test('space names reject ambiguous reserved names and duplicates',()=>{
  const c=setup();for(const name of ['','Personal','Household','x'.repeat(41)])assert.throws(()=>c.FinancialSpaces.create(name));c.FinancialSpaces.create(' Studio ');assert.throws(()=>c.FinancialSpaces.create('studio'));
});
test('every financial note uses the same optional 200-character boundary',()=>{
  assert.equal(notes.validate(), '');assert.equal(notes.validate('x'.repeat(200)).length,200);assert.throws(()=>notes.validate('x'.repeat(201)),/200 characters/);
});
test('moving a standalone account preserves balance, original ids, notes and removed history',()=>{
 const c=setup();const id=c.AccountJourney.recordExpense(expense),model=c.AccountJourney.moveState().ledger;
 model.save({...expense,amount:'75',memo:'Corrected note'},id);const removed=c.AccountJourney.recordExpense({...expense,amount:'25'});model.remove(removed);
 const business=c.FinancialSpaces.create('Studio');c.FinancialSpaces.activate('personal');const review=c.FinancialSpaces.moveReview('bank',business.id);assert.equal(review.issues.length,0);assert.equal(review.entryCount,2);
 c.FinancialSpaces.moveAccount('bank',business.id);assert.equal(c.accounts.length,0);assert.equal(c.AccountJourney.entries().length,0);
 c.FinancialSpaces.activate(business.id);assert.equal(c.accounts[0].balance,925);assert.equal(c.AccountJourney.entries()[0].id,id);assert.equal(c.AccountJourney.entries()[0].memo,'Corrected note');assert.equal(c.AccountJourney.entries()[0].history.length,1);assert.equal(c.AccountJourney.removedEntries()[0].id,removed);
 c.AccountJourney.restoreEntry(removed);assert.equal(c.accounts[0].balance,900);c.FinancialSpaces.moveAccount('bank','personal');c.FinancialSpaces.activate('personal');assert.equal(c.accounts[0].balance,900);
});
test('transfer links block a move without changing either space, even when removed',()=>{
 const c=setup();c.accounts.push({id:'cash',name:'Cash',kind:'Cash',currency:'DOP',balance:100});const id=c.AccountJourney.recordExpense({...expense,type:'transfer',otherId:'cash'});c.AccountJourney.moveState().ledger.remove(id);
 const b=c.FinancialSpaces.create('Studio');c.FinancialSpaces.activate('personal');assert.match(c.FinancialSpaces.moveReview('bank',b.id).issues.join(' '),/Transfers/);assert.throws(()=>c.FinancialSpaces.moveAccount('bank',b.id));assert.equal(c.accounts.length,2);assert.equal(c.accounts[0].balance,1000);c.FinancialSpaces.activate(b.id);assert.equal(c.accounts.length,0);
});
test('move review names source and destination budgets without moving the plans',()=>{
 const c=setup();const date='2026-09-28';c.AccountJourney.recordExpense({...expense,date,category:'Supplies'});c.Plans.budgets().push({id:'p',name:'Supplies',currency:'DOP',month:date.slice(0,7),limit:100});
 const b=c.FinancialSpaces.create('Studio');c.Plans.budgets().push({id:'b',name:'Supplies',currency:'DOP',month:date.slice(0,7),limit:200});c.FinancialSpaces.activate('personal');const review=c.FinancialSpaces.moveReview('bank',b.id);assert.equal(review.fromBudgets.length,1);assert.equal(review.toBudgets.length,1);c.FinancialSpaces.moveAccount('bank',b.id);assert.equal(c.Plans.spent(c.Plans.budgets()[0]),0);c.FinancialSpaces.activate(b.id);assert.equal(c.Plans.spent(c.Plans.budgets()[0]),50);
});
test('sharing and forecast references prevent silent reassignment',()=>{
 const c=setup(),b=c.FinancialSpaces.create('Studio');c.FinancialSpaces.activate('personal');c.EcosystemPreview={isShared:()=>true};c.ForecastPreview={accountLinks:()=>true};assert.equal(c.FinancialSpaces.moveReview('bank',b.id).issues.length,2);assert.throws(()=>c.FinancialSpaces.moveAccount('bank',b.id));assert.equal(c.accounts[0].balance,1000);
});
test('custom spaces archive without losing balances, activity, notes or search collection',()=>{
 const c=setup(),s=c.FinancialSpaces.create('Rental property','custom');c.accounts.push({id:'rent',name:'Rent account',kind:'Checking',currency:'DOP',balance:500});c.AccountJourney.recordExpense({...expense,accountId:'rent'});c.FinancialSpaces.archive(s.id);
 assert.equal(c.FinancialSpaces.current(),'personal');assert.equal(c.FinancialSpaces.active().some(x=>x.id===s.id),false);assert.equal(c.FinancialSpaces.allAccounts().find(a=>a.id==='rent').balance,450);assert.equal(c.FinancialSpaces.allAccounts().find(a=>a.id==='rent').spaceArchived,true);
 c.FinancialSpaces.restore(s.id);c.FinancialSpaces.activate(s.id);assert.equal(c.AccountJourney.entries()[0].memo,expense.memo);assert.equal(c.accounts[0].balance,450);
});
test('only empty private spaces can be deleted and restored with the same identity',()=>{
 const c=setup(),s=c.FinancialSpaces.create('Second personal','custom');c.FinancialSpaces.remove(s.id);assert.equal(c.FinancialSpaces.current(),'personal');assert.equal(c.FinancialSpaces.list().some(x=>x.id===s.id),false);assert.throws(()=>c.FinancialSpaces.activate(s.id));assert.throws(()=>c.FinancialSpaces.create(s.name));c.FinancialSpaces.restore(s.id);c.FinancialSpaces.activate(s.id);assert.equal(c.accounts.length,0);c.FinancialSpaces.rename(s.id,'Property');assert.equal(c.FinancialSpaces.name(),'Property');
 for(const method of ['remove','archive'])assert.throws(()=>c.FinancialSpaces[method]('personal'));assert.throws(()=>c.FinancialSpaces.rename('personal','Mine'));
});
for(const [name,seed] of Object.entries({account:c=>c.accounts.push({id:'empty',name:'Empty account',kind:'Cash',currency:'DOP',balance:0}),goal:c=>c.Plans.all().push({id:'goal'}),budget:c=>c.Plans.budgets().push({id:'budget'}),debt:c=>c.Plans.debts().push({id:'debt'}),draft:c=>c.AccountJourney.moveState().drafts.set('draft',{}),forecast:c=>c.ForecastPreview={spaceItemCount:()=>1},recovery:c=>c.AccountManagement={removedCount:()=>1}}))test(name+' prevents deletion without changing current space',()=>{const c=setup(),s=c.FinancialSpaces.create('Keep records','custom');seed(c);assert.throws(()=>c.FinancialSpaces.remove(s.id));assert.equal(c.FinancialSpaces.current(),s.id);assert.equal(c.FinancialSpaces.get(s.id).deleted,undefined);});
test('archived destinations cannot receive moved accounts',()=>{const c=setup(),s=c.FinancialSpaces.create('Archived','custom');c.FinancialSpaces.archive(s.id);assert.throws(()=>c.FinancialSpaces.moveAccount('bank',s.id));assert.equal(c.accounts[0].balance,1000);});
