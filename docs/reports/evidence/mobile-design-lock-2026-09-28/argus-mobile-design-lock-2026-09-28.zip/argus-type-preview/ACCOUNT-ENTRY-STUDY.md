# Account entry — accepted sketch

Founder-approved September 27, 2026; part of `APPROVED-BASELINE.md`.
This document replaces the earlier pending exploration notes. It records the
accepted disposable UI, not production financial contracts.

## Current experience

- Six primary types: Cash, Checking, Savings, Investment, Credit card, Other debt.
  A secondary disclosure offers Property, Vehicle and Other asset.
- Choose a type, then its grid folds into a compact Change row. Creation asks
  only for type, currency, optional nickname and optional balance/estimate.
  Add confirms manual entry; imported proposals retain their review step.
- No More details section during creation. Tapping a saved item opens its detail
  surface; the pencil opens editing, where type-specific details live: institution, dates, limits, interest,
  estimate basis and an existing related loan as appropriate.
- Assets show “You own all of it · Change.” Choices are All of it, Half or
  Another share. Only Another share reveals a percentage field. Enter the
  whole asset value; personal contribution uses the ownership share.
- A mortgage/loan remains a separate debt; linking it does not deduct it twice.
  Sharing access and partner invitations are separate from ownership.
- Unknown balances remain unknown, not zero. Home groups each currency and
  separates cash/bank, investments, estimated assets and debt. Incomplete
  totals are identified; property and vehicles are not spendable cash.
- DOP is an explicit editable demo default. Currency search uses the September
  27 snapshot of main's generated 154-code catalog. Production preference
  sourcing remains governed by its canonical owner.
- Money fields share `money-input.js`. See `MONEY-ENTRY-AUDIT.md` for production
  inheritance, stronger parsing, 194 checks and browser evidence.
- Account entry hides bottom navigation, does not autofocus, and offers Cancel.
  Real-device keyboard behavior remains unverified. Local examples reset on
  reload; no backend, household permissions, financial operation, automatic
  valuation or source scraping is implemented.

## Retained verification

Browser checks covered unknown Cash/DOP, Savings/EUR, currency search and
separate totals; DOP 6,000,000 property at 50% with a separate linked DOP
1,000,000 mortgage produces DOP 2,000,000 net recorded value. Unknown vehicle
value leaves that total incomplete. Editing retains full value and ownership;
125% is rejected, while 25% produces DOP 1,500,000 personal contribution.
Creation/edit visibility and money-field flows were checked separately.

## Authority

Product experience: repository MVEE, “Quick account setup and optional assets.”
Money interaction: repository DESIGN.md, “Money entry in the ecosystem sketch.”
SuperCarros/SuperCasas are future comparison-source candidates, not live feeds.
The subsequent account journey study is recorded in `ACCOUNT-JOURNEY-STUDY.md`;
it extends this accepted entry flow and awaits founder review.
