# Space creation and recovery — September 28, 2026

Founder requested an end-to-end MVEE template refinement, with pushback on unnecessary expansion. This adds Custom as another named private financial picture, not a third permission system. Personal is the one permanent default; Business and Custom can be created more than once. The earlier conversational assertion of unlimited personal spaces is not a production entitlement.

## Changes

- Add a space now offers Household, Business and Custom, followed by Manage spaces. Business and Custom share a naming form and the existing account/activity/plan behavior. Private spaces start empty.
- The same creation flow works when choosing a destination for an account. Creating a space does not move an account until the existing move review is confirmed.
- Manage spaces lives in the plus menu. The duplicate Profile & settings entry was removed in the final mobile lock. Rename retains record identity. Names are unique across active, archived and recoverable deleted spaces.
- Archive hides the space from ordinary space navigation. Balances, history, plans and recovery stay intact; Search labels archived records. An opened archived space is explicitly labeled in the selector. This is organization, not read-only mode or cancellation of commitments.
- Only genuinely empty private spaces expose Delete. Existing accounts, all activity, plans, expected items, drafts and recoverable empty accounts block it. Shared confirmation styling applies. Undo is reachable after the sheet closes; Recently deleted allows later restoration within the preview session.
- Personal is permanent. Household keeps membership/sharing controls and is not deletable through this private-space action. Active space removal returns to Personal; settings return refreshes the surface instead of reopening an unrelated account.

## Owner and limits

FinancialSpaces owns lifecycle state, validation, and deletion eligibility; UI reads those facts. Account and plan owners retain financial records. No database, provider, permission system, cascade deletion, production entitlement, or retention duration is implemented. Backend handoff must enforce these guards atomically, preserve links/recovery, resolve limits and purge rules, and scope retrieval/search by access. All mock records reset on reload.

## Verification

283 checks pass, including ten focused lifecycle cases for preserved balances/notes, empty-space restore identity, default-space protection, unique names, account/plan/draft/forecast/recovery deletion guards, and archived move destinations. Browser keyboard verification covered Custom creation, account-move destination creation and confirmation, renamed populated space, deletion unavailable for populated space, archive/search preservation and explicit archived context, empty-space archive/restore, delete cancellation, delete and Undo, Recently deleted restoration, multiple private spaces and Household invitation entry/back. Settings return was corrected and rechecked on the final settings code. No complete native device or accessibility matrix is claimed.

Screenshots and test output: journey-audit/spaces-add.png, spaces-manage.png, spaces-recovery.png, space-lifecycle-tests.txt. Household continues the existing mock invitation flow, not a new membership implementation.
