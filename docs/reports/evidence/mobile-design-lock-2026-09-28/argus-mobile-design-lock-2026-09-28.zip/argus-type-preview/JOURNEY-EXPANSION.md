# Plan, Search, sign-in and motion — September 27, 2026

> Historical iteration/evidence record. The final accepted template is [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md); use its current reports and acceptance boundary when implementing. Earlier gaps and recommendations below describe their dated checkpoint.

Status: implemented disposable preview for founder review. The preceding surface review is approved and checkpointed; these new journeys are candidates. No production source, auth service, API, database, native project or chat runtime was changed by this expansion.

Open `journey-review.html` for the visual walkthrough. Changes live in this browser session and reset on reload. Screenshots show synthetic examples and may include edits made during QA rather than the initial fixture values.

## Before / after

| Surface | Before | This candidate | Decision and tradeoff |
| --- | --- | --- | --- |
| Plan | Goal overview and creation | Goals, Budgets, Debts; each has creation, detail, editing and confirmed removal | Three compact sections instead of a dashboard of competing cards |
| Goals | Static saved amount | Update the absolute total; progress history; undo latest; target reached and overfunded states; optional monthly saving scenario | Actual progress is separate from the monthly intention and from account money. No double-counting or implied allocation |
| Budgets | Unrelated alert example | Category/currency/month limit; recorded spending; remaining/over; included activity opens the original entry; corrections flow back | One category per budget, one currency per total. No automatic rollover or complete-coverage claim |
| Debts | No planning journey | Choose an existing debt, monthly payment, optional next date; record payment through Accounts; return to updated debt plan | Reuse the account balance and date. No guessed payoff date without interest/fee assumptions |
| Search | Accounts, goals and chats | Activity, budgets and debt plans as well; original-record destinations; query survives return | Transfers/payments appear once, not once per account leg. Local substring search, not a server ranking contract |
| Sign-in | Outside sketch | Existing Argus form language plus Apple/Google; signup, recovery, expired link, success/cancel/error, guest continuation | Providers are clearly simulated. Account gating and guest migration policy are not decided here |
| Motion | Several separate treatments | Shared press, navigation, dialog and progress motion; reduced-motion/keyboard exceptions | Keep established chat/header/glass behavior; native keyboard, haptics and frame timing still need native validation |

## Journeys to try

1. Plan → Budgets → Dining → Lunch → Correct entry. Change 320 to 250, save and go Back. A 300 budget changes from 20 over to 50 left. Removing/recategorizing an entry removes it from the derived budget; payments, transfers and balance reconciliation do not become spending. Card purchases use the same expense type as other purchases.
2. Plan → Goals → Emergency fund → Edit goal → Monthly plan: enter 5,000. The remaining 15,000 gives a three-month scenario; the saved total stays 60,000. Update progress to 75,000 to reach the target. Undo latest restores the previous total without changing accounts.
3. Plan → Debts → Plan a payment → My credit card: 2,000 monthly. Record a payment from Everyday spending. Preview both balances, save, then Back. The card changes from 8,500 owed to 6,500 owed; the funding account decreases by 2,000. Removing the plan does not remove the account or its entries.
4. Search → type Lunch → open the entry → Back. Query remains. Try Cash for the week to see one transfer with both accounts in its context.
5. Sign-in → use fictional details, or explore Apple/Google simulated returns. Recovery → expired link → new link stays in password recovery, not signup. No SDK is loaded, email sent, session created or credential changed.

## Existing work inherited

- Production `web/app/login/page.tsx` redirects into the shared form in `web/components/auth/AuthForm.tsx`. The sketch inherits its rounded fields, visual hierarchy, password visibility, recovery/signup/confirmation concepts and pill CTA. It does not claim a fresh deployed-production audit or copy its runtime.
- Existing sketch font assets match production Space Grotesk/Inter; palette, neutral financial figures, semantic rose destructive actions and shared confirmation treatment are retained.
- `money-input.js` owns currency precision, separators and validation. All new monetary inputs reuse it and the existing currency catalog.
- `account-journey.js` owns recording categories and exposes them to Plan. Plan does not maintain a second category list.
- `account-activity-model.js` remains the account/entry owner. Plan reads it; Search opens it. No second bookkeeping model was added.
- `PlanPreview` owns goal/budget/debt-plan examples. Search and Updates derive from it. Updates remains a prepared feed, not live monitoring.
- Show more/fewer, accessible icon labels, established profile/avatar/feedback flows and chat interaction details remain inherited.

## Verification and limits

- Node checks: 211 passing checks across money input, account activity and five Plan derivation tests. Exact command/output: `journey-audit/deterministic-checks.txt`.
- Browser: goal total update and monthly scenario; budget correction round trip; duplicate category/currency/month guard; debt creation, two-account payment and return; one search result per transfer/payment; preserved query; empty sign-in validation; Apple cancellation; Google successful return; recovery-expiry renewal.
- Responsive DOM inspection at requested 390 and 320 widths: no page overflow; dialog fits within viewport and scrolls to its actions. Browser zoom resulted in reported CSS widths approximately 394/323. This is desktop emulation, not iOS/Android device proof.
- Reduced-motion preview resolves transitions to zero; keyboard navigation suppresses animated transitions. No native frame-rate, hardware keyboard, screen-reader or real software-keyboard acceptance is claimed.
- Captured screenshots are stored in `journey-audit/`. Motion timing is specified in `MOTION-SPEC.md`; still images do not prove animation timing.
- Synthetic in-memory data only; no reload persistence, bank connection, real SSO, notification delivery or guest-account merge.
- English design copy is a review artifact. Production must use the existing English/Spanish localization system.

## Backend/native handoff — unresolved implementation decisions

- Production budget periods/time zones, category IDs, uncategorized policy, account coverage, rollover and concurrency remain contract work. This preview chooses monthly category/currency buckets for exploration only.
- Production goals need an explicit choice about linked/allocated funds and shared ownership. Current total is user-reported and does not reserve money. The monthly projection assumes constant saving, no interest, no withdrawals.
- Debt interest, minimums, fees, amortization and future borrowing need proper inputs before a payoff forecast. Existing chat calculators remain available and unchanged.
- Account records must retain the earlier reconciliation/correction audit semantics; this UI work does not substitute for a durable ledger or permission model.
- Supabase provider configuration, native secure sessions, redirects/deep links, captcha, identity linking, guest continuity and account deletion remain with the auth contract/implementation lane.
- Apple guideline 4.8 is conditional when third-party login is used; it does not say every app must offer Apple and Google. Both are design options here. Sources checked September 27, 2026: https://developer.apple.com/app-store/review/guidelines/#login-services ; https://supabase.com/docs/guides/auth/social-login/auth-apple ; https://supabase.com/docs/guides/auth/social-login/auth-google .
- Native implementations should map the motion intent to platform transitions, safe areas and accessibility settings. Do not copy web dialogs into Swift/Kotlin as a shell.
