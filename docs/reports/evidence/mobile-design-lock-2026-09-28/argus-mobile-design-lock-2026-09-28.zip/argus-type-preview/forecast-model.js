// Disposable forecast: integer minor units, explicit assumptions, no ledger writes.
(function(root){
  const day=s=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(s))throw Error('Choose a date.');const d=new Date(s+'T12:00:00Z');if(!Number.isFinite(+d)||d.toISOString().slice(0,10)!==s)throw Error('Choose a valid date.');return d;};
  const iso=d=>d.toISOString().slice(0,10);
  const plus=(date,n)=>{const d=day(date);d.setUTCDate(d.getUTCDate()+n);return iso(d);};
  function rule(item){
    const defaults={once:{frequency:'once',interval:1},daily:{frequency:'daily',interval:1},weekly:{frequency:'weekly',interval:1},fortnightly:{frequency:'weekly',interval:2},monthly:{frequency:'monthly',interval:1},yearly:{frequency:'yearly',interval:1}};
    const r=item.repeat==='custom'?item.recurrence:defaults[item.repeat];
    if(!r||!['once','daily','weekly','monthly','yearly'].includes(r.frequency)||!Number.isInteger(r.interval)||r.interval<1||r.interval>999)throw Error('Choose a repeat interval from 1 to 999.');
    if(r.weekdays&&(!r.weekdays.length||r.weekdays.some(d=>!Number.isInteger(d)||d<0||d>6)))throw Error('Choose at least one weekday.');
    if(r.day!==undefined&&(!Number.isInteger(r.day)||(r.day!==-1&&(r.day<1||r.day>31))))throw Error('Choose a day from 1 to 31, or the last day.');
    if(r.month!==undefined&&(!Number.isInteger(r.month)||r.month<1||r.month>12))throw Error('Choose a month.');
    return r;
  }
  function dates(item,start,end){
    const r=rule(item),anchor=day(item.date),out=[];
    const week=d=>Math.floor((+d-((d.getUTCDay()+6)%7)*86400000)/604800000);
    for(let date=item.date>start?item.date:start;date<=end;date=plus(date,1)){
      const d=day(date),diff=Math.round((+d-+anchor)/86400000),monthDiff=(d.getUTCFullYear()-anchor.getUTCFullYear())*12+d.getUTCMonth()-anchor.getUTCMonth();
      const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();
      const desiredDay=r.day===-1?last:Math.min(r.day||anchor.getUTCDate(),last);
      const hit=r.frequency==='once'?date===item.date:r.frequency==='daily'?diff%r.interval===0:r.frequency==='weekly'?(week(d)-week(anchor))%r.interval===0&&(r.weekdays||[anchor.getUTCDay()]).includes(d.getUTCDay()):r.frequency==='monthly'?monthDiff%r.interval===0&&d.getUTCDate()===desiredDay:(d.getUTCFullYear()-anchor.getUTCFullYear())%r.interval===0&&d.getUTCMonth()===(r.month||anchor.getUTCMonth()+1)-1&&d.getUTCDate()===desiredDay;
      if(hit)out.push(date);
    }
    return out;
  }
  function repeatLabel(item){
    const labels={once:'Never',daily:'Every day',weekly:'Every week',fortnightly:'Every 2 weeks',monthly:'Every month',yearly:'Every year'};
    if(item.repeat!=='custom')return labels[item.repeat];
    const r=rule(item),unit={daily:'day',weekly:'week',monthly:'month',yearly:'year'}[r.frequency];
    let text='Every '+(r.interval===1?'':r.interval+' ')+unit+(r.interval===1?'':'s');
    if(r.frequency==='weekly'&&r.weekdays)text+=' · '+r.weekdays.map(d=>['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d]).join(', ');
    if(['monthly','yearly'].includes(r.frequency)&&r.day)text+=' · '+(r.day===-1?'last day':'day '+r.day);
    return text;
  }
  function project({start,end,opening,items,matches={}}){
    day(start);day(end);if(end<start||end>plus(start,366))throw Error('Choose an end date within the next year.');
    if(!Number.isSafeInteger(opening))throw Error('Opening balance is too large.');
    const events=[];
    for(const item of items){
      if(!['income','expense','transfer'].includes(item.type)||!Number.isSafeInteger(item.amount)||item.amount<=0)throw Error('Check the planned amount.');
      day(item.date);
      for(const date of dates(item,start,end)){
        const key=item.id+':'+date;if(!matches[key])events.push({...item,date,key});
      }
    }
    // Same-day expenses first exposes a conservative intraday low, not just net daily flow.
    events.sort((a,b)=>a.date.localeCompare(b.date)||(a.type===b.type?0:a.type==='expense'?-1:1));
    let balance=opening,income=0,expenses=0,low=opening,lowDate=start;
    const points=[{date:start,balance}];
    for(const e of events){if(e.type==='income'){income+=e.amount;balance+=e.amount;}else if(e.type==='expense'){expenses+=e.amount;balance-=e.amount;}if(!Number.isSafeInteger(balance)||!Number.isSafeInteger(income)||!Number.isSafeInteger(expenses))throw Error('This total is too large.');e.balance=balance;points.push({date:e.date,balance});if(balance<low){low=balance;lowDate=e.date;}}
    points.push({date:end,balance});return {opening,income,expenses,net:income-expenses,ending:balance,low,lowDate,events,points};
  }
  root.ForecastMath={project,plus,day,rule,repeatLabel,dates};if(typeof module!=='undefined')module.exports=root.ForecastMath;
})(globalThis);
