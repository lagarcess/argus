const {test}=require('node:test');
const assert=require('node:assert/strict');
const {parse,config}=require('./money-input.js');
const good=[
 ['1234.50','DOP',1234.5],['1,234.50','DOP',1234.5],['RD$ 1,234.50','DOP',1234.5],
 ['DOP 1,234.50','DOP',1234.5],['1,234.50 DOP','DOP',1234.5],['$1,234.50','USD',1234.5],
 ['US$ 1,234.50','USD',1234.5],['0','DOP',0],['0.00','DOP',0],['.50','DOP',.5],
 ['-1,234.50','DOP',-1234.5],['−1,234.50','DOP',-1234.5],['RD$ -1.50','DOP',-1.5],
 ['1,234','JPY',1234],['1.234','KWD',1.234],['1000000000000.00','DOP',1e12],
 ['1.234,50','EUR',1234.5,'es-ES'],['1,234.50','DOP',1234.5,'es-419']
];
for(const [raw,currency,expected,language] of good)test(`accept ${currency} ${raw} ${language||'en-US'}`,()=>{
 const r=parse(raw,{currency,language});assert.equal(r.ok,true,r.error);assert.equal(r.value,expected);
 assert.equal(parse(r.canonical,{currency}).value,expected);
});
const bad=['12,50','1.234,50','1,23,456','12,,345','1e3','0x10','NaN','Infinity','1 234','USD 20','€20','20 cats','--2','1..2','2.','1.001','1000000000001','1,234.50 USD'];
for(const raw of bad)test(`reject ambiguous or invalid DOP ${raw}`,()=>assert.equal(parse(raw,{currency:'DOP'}).ok,false));
test('blank stays unknown, zero stays zero',()=>{assert.equal(parse('  ').value,null);assert.equal(parse('0').value,0);assert.equal(parse('',{required:true}).ok,false)});
test('currency precision never silently rounds',()=>{assert.equal(parse('1.5',{currency:'JPY'}).ok,false);assert.equal(parse('1.2345',{currency:'KWD'}).ok,false);assert.equal(parse('0.10').minorUnits,'10')});
test('minimum applies to positive-only and required goal fields',()=>{assert.equal(parse('-1',{min:0}).ok,false);assert.equal(parse('0',{min:0}).ok,true);assert.equal(parse('0.99',{min:1}).ok,false)});
test('currency change revalidates, never converts or rounds',()=>{assert.equal(parse('12.50',{currency:'USD'}).ok,true);assert.equal(parse('12.50',{currency:'JPY'}).ok,false);assert.equal(parse('12',{currency:'EUR'}).value,12)});
// Round-trip precision follows the same currency catalog as the sketch.
const vm=require('node:vm'),fs=require('node:fs');const context={window:{}};vm.runInNewContext(fs.readFileSync('./account-currencies.js','utf8'),context);
for(const currency of context.window.accountPreviewCurrencies)test(`catalog round trip ${currency}`,()=>{
 const c=config(currency);const units=1234*10**c.digits+ (c.digits?1:0);const value=units/10**c.digits;
 const raw=new Intl.NumberFormat('en-US',{minimumFractionDigits:c.digits,maximumFractionDigits:c.digits}).format(value);
 const r=parse(raw,{currency});assert.equal(r.ok,true,r.error);assert.equal(r.minorUnits,String(units));
});
