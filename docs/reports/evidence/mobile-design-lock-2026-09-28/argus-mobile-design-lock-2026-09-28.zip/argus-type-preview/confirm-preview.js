// One confirmation owner for destructive preview actions. No backend operations.
window.confirmPreview=({title,description,confirmLabel,onConfirm,onCancel,request=false})=>{
  const trigger=document.activeElement,dialog=document.createElement('dialog');
  dialog.className='argus-confirm'+(document.querySelector('.settings-dark')?' argus-confirm-dark':'');
  dialog.setAttribute('role','alertdialog');dialog.setAttribute('aria-labelledby','preview-confirm-title');dialog.setAttribute('aria-describedby','preview-confirm-description');
  dialog.innerHTML=`<h2 id="preview-confirm-title">${escape(title)}</h2><p id="preview-confirm-description">${escape(description)}</p><div class="argus-confirm-actions"><button type="button" data-confirm-cancel autofocus>Cancel</button><button type="button" data-confirm-accept ${request?'data-support-request':''}>${escape(confirmLabel)}</button></div>`;
  document.body.append(dialog);let accepted=false;
  dialog.querySelector('[data-confirm-cancel]').onclick=()=>dialog.close();
  dialog.querySelector('[data-confirm-accept]').onclick=()=>{accepted=true;dialog.close();onConfirm();};
  dialog.addEventListener('keydown',event=>{if(event.key==='Escape')event.stopPropagation();});
  dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();});
  dialog.addEventListener('close',()=>{dialog.remove();if(!accepted&&onCancel)onCancel();else if(trigger?.isConnected)trigger.focus();});
  dialog.showModal();return dialog;
};
