// Account detail and recording experience. Fictional session data only.
(() => {
  const categoriesFor=type=>[...new Set([...(type==='income'?['Salary','Remittance','Interest','Other income']:['Other','Groceries','Dining','Transport','Housing','Health','Shopping','Interest & fees']),...ledger.entries.filter(e=>!e.removed&&(e.type===type||(type==='refund'&&e.type==='expense'))&&e.category).map(e=>e.category)])];
  const personalAccounts=accounts;let ledger=new AccountActivity(()=>personalAccounts);
  const debt=a=>['Credit card','Other debt','Loan'].includes(a.kind);
  const asset=a=>['Property','Vehicle','Other asset'].includes(a.kind);
  const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
  const money=(value,currency)=>new Intl.NumberFormat('en-US',{style:'currency',currency,currencyDisplay:'code'}).format(value);
  const date=d=>d?new Intl.DateTimeFormat('en',{month:'short',day:'numeric',year:'numeric'}).format(new Date(d+'T12:00:00')):'Date not recorded';
  const glyph=key=>key==='left'?'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 5-7 7 7 7"/></svg>':headerGlyph(key);
  const transferIcon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h15m-4-4 4 4-4 4M20 17H5m4-4-4 4 4 4"/></svg>';
  const arrow=direction=>`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${direction==='in'?'M6 6l12 12m-8 0h8v-8':'M6 18 18 6m-8 0h8v8'}"/></svg>`;
  const labels={expense:'Expense',income:'Income',transfer:'Transfer',payment:'Payment',borrow:'Borrowing',refund:'Refund',balance:'Balance update'};
  let currentId=null,entryDraft=null,editingId=null,mode='list',lastRemoved=null,externalBack=null;
  let drafts=new Map();
  let spaceId="personal";const spaceStates=new Map();
  const parentShow=show;
  const notice=(message,variant='neutral')=>PreviewToast.show(message,variant);
  function shell(form=false){
    parentShow('accounts');mode=form?'record':'detail';
    phone.classList.add('account-journey-mode');phone.classList.toggle('account-entry-mode',form);
    screen.scrollTop=0;
  }
  function summaryLabel(a){return asset(a)?'Estimated total value':debt(a)?a.balance>0?'Credit balance':'Amount owed':'Recorded balance'}
  function amountLabel(e,id){const leg=ledger.effects(e).find(x=>x.id===id);const c=ledger.account(id).currency;if(leg.set!==undefined){if(e.check?.difference!=null){const d=BigInt(e.check.difference);return `${d<0n?'−':d>0n?'+':''}${money(Math.abs(ledger.amount(d,c)),c)}`;}return money(ledger.amount(leg.set,c),c);}return `${leg.delta<0n?'−':'+'}${money(Math.abs(ledger.amount(leg.delta,c)),c)}`;}
  function row(e){const leg=ledger.effects(e).find(x=>x.id===currentId);const picture=['transfer','payment'].includes(e.type)?transferIcon:e.type==='balance'?glyph('edit'):arrow(leg.delta>0n?'in':'out');
    return `<button class="activity-row" data-journey-entry="${e.id}"><span class="activity-glyph">${picture}</span><span class="activity-copy"><strong>${escape(e.description||e.category||labels[e.type])}</strong><small>${escape(e.category||labels[e.type])} · ${date(e.date)}${e.history?.length?' · Edited':''}${e.checkResolution?.[currentId]?.included?' · Included in checked balance':''}</small></span><span class="activity-value">${amountLabel(e,currentId)}</span></button>`;
  }
  function activity(){
    const items=ledger.activity(currentId).slice().reverse().slice(0,5);
    const a=ledger.account(currentId);
    const empty=asset(a)?(a.balance==null?'Add an estimate to start tracking its value.':'Your current estimate is saved. Future changes will appear here.'):a.balance==null?'Record your first entry to start tracking activity.':a.kind==='Credit card'?'Your balance is saved. Purchases and payments will appear here.':debt(a)?'Your balance is saved. Payments and borrowing will appear here.':'Your balance is saved. New activity will appear here.';
    document.getElementById('journey-activity').innerHTML=items.length?items.map(row).join(''):`<div class="account-empty"><p>${empty}</p></div>`;
  }
  function detail(id){
    ledger.attach();currentId=id;const a=ledger.account(id);shell();
    const debtLink=a.linkedDebtId&&accounts.find(x=>x.id===a.linkedDebtId);
    const records=ledger.activity(id);
    const month=today().slice(0,7),current=records.filter(e=>e.date.startsWith(month));
    const spend=current.reduce((n,e)=>n+(e.type==='expense'?Number(e.amount):e.type==='refund'?-Number(e.amount):e.type==='payment'&&e.otherId===id?Number(e.fees||0):0),0);
    const income=current.filter(e=>e.type==='income').reduce((n,e)=>n+Number(e.amount),0);
    screen.innerHTML=`<div class="journey-body"><div class="journey-toolbar"><button data-journey="back" class="journey-back" aria-label="${externalBack?'Back to previous view':'Back to accounts'}">${glyph('left')}<span>${externalBack?'Back':'Accounts'}</span></button><button data-journey="settings" class="journey-icon" aria-label="Edit account details">${glyph('edit')}</button></div><p class="eyebrow">${spaceId!=='personal'?escape(FinancialSpaces.name())+' · ':''}${escape(a.kind)} · ${a.currency}</p><h1 class="journey-name">${escape(a.name)}</h1><p class="balance-caption term-label">${summaryLabel(a)}${PreviewUI.info(asset(a)?'valuation':'balance')}</p><div class="journey-balance">${a.balance==null?'Not added yet':money(debt(a)?Math.abs(a.balance):a.balance,a.currency)}</div><p class="balance-freshness">${escape(a.source||'Recorded manually')} · ${date(a.asOf)}</p>${asset(a)?`<p class="ownership-summary">${a.ownershipShare===50?'You own half':(a.ownershipShare??100)===100?'You own all of it':`You own ${a.ownershipShare}%`}${a.balance!=null?` · Your part ${money(a.balance*(a.ownershipShare??100)/100,a.currency)}`:''}</p>${a.valuationNote?`<p class="balance-freshness">Based on ${escape(a.valuationNote)}</p>`:''}`:''}<div class="journey-actions"><button class="primary" data-journey="record">${asset(a)?'Update estimate':debt(a)&&a.balance<=0?'Record payment':'Record new activity'}</button>${!asset(a)?'<button class="journey-update" data-journey="balance">Check balance</button>':''}</div>${records.length&&!asset(a)&&!debt(a)&&a.kind!=='Investment'?`<div class="activity-month"><span>This month · recorded activity</span><div><p><small>Income</small><strong>${money(income,a.currency)}</strong></p><p><small>${spend<0?'Net refunds':'Spending'}</small><strong>${money(Math.abs(spend),a.currency)}</strong></p></div><small>Refunds reduce spending on the date received. Transfers and balance updates excluded.</small>${records.some(e=>e.check?.difference!=null&&e.check.difference!=='0')?'<p class="coverage-note">A balance adjustment is recorded. Income and spending may be incomplete.</p>':''}</div>`:''}${debt(a)&&a.paymentDue?`<div class="account-context"><span>Next payment</span><strong>${date(a.paymentDue)}</strong></div>`:''}${debtLink?`<button class="linked-account" data-journey-account="${debtLink.id}"><span>Related loan<br><strong>${escape(debtLink.name)}</strong></span><span>${debtLink.balance==null?'Not added':money(Math.abs(debtLink.balance),debtLink.currency)}</span></button>`:''}<section class="journey-history"><div class="sectionhead"><h2>${records.length?(asset(a)?'Recent value changes':'Recent activity'):(asset(a)?'No value changes yet':'No activity yet')}</h2>${records.length?'<button class="home-view-all" data-journey="all-activity">View all</button>':''}</div><div id="journey-activity"></div></section><p class="account-demo">Recorded here · Not bank-connected<br>Local preview · Changes reset on reload</p></div>`;
    activity();
  }
  function typesFor(a){return asset(a)?['balance']:a.kind==='Credit card'?['payment','expense','refund']:debt(a)?['payment','borrow']:a.kind==='Investment'?['transfer','income']:['expense','income','transfer','refund'];}
  function peers(a,type){return accounts.filter(x=>x.id!==a.id&&!asset(x)&&!debt(x)&&(type!=='payment'||x.currency===a.currency));}
  function start(type,id=null){
    const a=ledger.account(currentId);editingId=id;
    const cached=!id&&drafts.get(`${currentId}:${type==='balance'||asset(a)?'balance':'entry'}`);
    if(cached){entryDraft={...cached.draft};editingId=cached.editingId;form();return;}
    entryDraft=id?{...ledger.entries.find(e=>e.id===id)}:{accountId:a.id,type:type||(a.kind==='Credit card'&&a.balance>0?'expense':typesFor(a)[0]),amount:'',description:'',category:'',date:today(),recordedOn:today(),otherId:'',received:'',fees:'0'};
    if(id&&entryDraft.type==='balance'&&!entryDraft.memo&&entryDraft.description){entryDraft.memo=entryDraft.description;entryDraft.description='';}
    if(entryDraft.type==='balance'&&a.kind==='Credit card')entryDraft.balanceSide=(id?Number(entryDraft.amount):a.balance)>0?'credit':'owed';
    if(id&&entryDraft.type==='balance'&&debt(a))entryDraft.amount=String(Math.abs(Number(entryDraft.amount)));
    form();
  }
  function captureDraft(){
    if(!document.getElementById('activity-form'))return;
    for(const [key,id] of Object.entries({amount:'activity-amount',description:'activity-description',memo:'activity-memo',category:'activity-category',date:'activity-date',otherId:'activity-other',received:'activity-received',fees:'activity-fees',originalId:'activity-original',balanceSide:'activity-balance-side'})){
      const input=document.getElementById(id);if(!input)continue;
      const parsed=input.dataset.moneyCurrency?ArgusMoney.read(input):null;
      entryDraft[key]=parsed?.ok?parsed.canonical:input.value;
    }
  }
  function form(){
    const a=ledger.account(entryDraft.accountId),type=entryDraft.type,isBalance=type==='balance',isMove=['transfer','payment'].includes(type),eligible=peers(a,type);
    shell(true);
    const other=eligible.find(x=>x.id===entryDraft.otherId);const fx=type==='transfer'&&other&&other.currency!==a.currency;
    const categories=categoriesFor(type);
    const amountLabel=isBalance?asset(a)?'Estimated total value':debt(a)?entryDraft.balanceSide==='credit'?'Credit in your favor':'Amount owed':'Balance you checked':type==='payment'?'Payment amount':type==='transfer'?'Amount transferred':type==='refund'?'Refund received':type==='income'?'Amount received':type==='expense'?'Amount spent':'Amount borrowed';
    screen.innerHTML=`<div class="account-quick journey-form"><div class="journey-toolbar"><button data-journey="cancel" class="journey-back">${glyph('left')}<span>${escape(a.name)}</span></button></div><h1>${editingId?'Correct entry':isBalance?asset(a)?'Update your estimate':'Check your balance':'Record new activity'}</h1>${!isBalance&&!editingId?`<div class="activity-type-picker" role="group" aria-label="Activity type">${typesFor(a).map(t=>`<button type="button" data-journey-type="${t}" aria-pressed="${t===type}">${t==='expense'&&debt(a)?'Charge':labels[t]}</button>`).join('')}</div>`:''}<form id="activity-form" novalidate><label for="activity-amount">${amountLabel}</label><input id="activity-amount" data-money-currency="${a.currency}" ${isBalance&&!debt(a)&&!asset(a)?'':'data-money-min="'+(isBalance?'0':String(1/10**ArgusMoney.config(a.currency).digits))+'"'} inputmode="decimal" type="text" value="${escape(entryDraft.amount)}" required>${isBalance?`<p class="account-help">${asset(a)?'Enter the whole asset’s value. Your ownership share stays the same.':'We’ll compare this with your records before you save. It is not income or spending.'}</p>`:''}${isBalance&&a.kind==='Credit card'?`<label for="activity-balance-side">Balance type</label><select id="activity-balance-side"><option value="owed">Amount owed</option><option value="credit" ${entryDraft.balanceSide==='credit'?'selected':''}>Credit in your favor</option></select>`:''}${type==='refund'?`<label for="activity-original">Original purchase <span class="optional">Optional</span></label><select id="activity-original"><option value="">Purchase not linked</option>${ledger.entries.filter(e=>!e.removed&&e.type==='expense'&&ledger.account(e.accountId).currency===a.currency).map(e=>`<option value="${e.id}" ${entryDraft.originalId===e.id?'selected':''}>${escape(e.description||e.category||'Purchase')} · ${money(Number(e.amount),a.currency)}</option>`).join('')}</select><p class="account-help">Record only money already returned to this account. It reduces spending, not income. A partial refund is fine.</p>`:''}${isMove?`<label for="activity-other">${type==='payment'?'Paid from':'To account'}</label><select id="activity-other" required><option value="">Choose an account</option>${eligible.map(x=>`<option value="${x.id}" ${other?.id===x.id?'selected':''}>${escape(x.name)} · ${x.currency}</option>`).join('')}</select>${!eligible.length?'<p class="account-help">Add another cash or bank account first'+(type==='payment'?' in this currency':'')+'. Your draft stays here when you go back.</p>':''}`:''}${fx?`<label for="activity-received">Amount received · ${other.currency}</label><input id="activity-received" type="text" data-money-currency="${other.currency}" data-money-min="${1/10**ArgusMoney.config(other.currency).digits}" value="${escape(entryDraft.received||'')}" required><p class="account-help">Use the actual received amount. No exchange rate is assumed.</p>`:''}${type==='payment'&&a.kind!=='Credit card'?`<label for="activity-fees">Interest and fees included <span class="optional">${a.currency}</span></label><input id="activity-fees" type="text" data-money-currency="${a.currency}" data-money-min="0" value="${escape(entryDraft.fees||'0')}"><p class="account-help">The rest reduces what you owe. Check your payment breakdown.</p>`:''}${!isBalance?`<label for="activity-description">What was it for? <span class="optional">Optional</span></label><input id="activity-description" maxlength="80" value="${escape(entryDraft.description||'')}" placeholder="${type==='expense'?'e.g. Lunch':type==='income'?'e.g. Monthly salary':'e.g. Savings contribution'}" autocomplete="off">`:''}${['expense','income','refund'].includes(type)?`<label for="activity-category">${type==='income'?'Source':'Category'} <span class="optional">Optional</span></label>${spaceId!=='personal'?`<input id="activity-category" list="activity-categories" maxlength="60" value="${escape(entryDraft.category||'')}" placeholder="Choose or type your own"><datalist id="activity-categories">${categories.map(c=>`<option value="${escape(c)}"></option>`).join('')}</datalist>`:`<select id="activity-category"><option value="">Choose if you know</option>${categories.map(c=>`<option ${entryDraft.category===c?'selected':''}>${escape(c)}</option>`).join('')}</select>`}`:''}<label for="activity-date">${isBalance?'Checked today':'Date'}</label><input id="activity-date" type="date" value="${entryDraft.date}" max="${today()}" ${isBalance?'readonly':''} required>${EntryNotes.field('activity-memo',entryDraft.memo||'')}<div id="activity-reconciliation"></div><div id="activity-impact" class="activity-impact" aria-live="polite"></div><p id="activity-error" class="account-error" role="alert"></p><button class="primary" type="submit">${isBalance?'Review balance':editingId?'Save correction':'Save entry'}</button><p class="account-demo">Records activity only · No money is moved</p></form></div>`;
    document.getElementById('activity-balance-side')?.addEventListener('change',()=>{captureDraft();form();});
    document.getElementById('activity-original')?.addEventListener('change',()=>{captureDraft();const original=ledger.entries.find(e=>e.id===entryDraft.originalId);if(original)entryDraft.category=original.category;form();});
    if(type==='refund'&&entryDraft.originalId)document.getElementById('activity-category').disabled=true;
    document.getElementById('activity-other')?.addEventListener('change',()=>{captureDraft();entryDraft.received='';form()});
    document.getElementById('activity-form').addEventListener('input',impact);
    document.getElementById('activity-form').addEventListener('change',impact);
    impact();
  }
  function proposed(){captureDraft();entryDraft.checkResolution={...entryDraft.checkResolution};document.querySelectorAll('[data-check-account]').forEach(el=>{if(el.value)entryDraft.checkResolution[el.dataset.checkAccount]={checkId:el.dataset.checkId,included:el.value==='included'};else delete entryDraft.checkResolution[el.dataset.checkAccount];});const e={...entryDraft,recordedOn:today()};const a=ledger.account(e.accountId);e.memo=EntryNotes.validate(e.memo);
    if(e.type==='balance'){e.amount=String(debt(a)?(a.kind==='Credit card'&&e.balanceSide==='credit'?1:-1)*Math.abs(Number(e.amount)):Number(e.amount));e.category=asset(a)?'Value update':'Balance check';e.date=today();}
    if(e.type==='refund'&&!e.description)e.description=e.originalId?'Refund · '+(ledger.entries.find(x=>x.id===e.originalId)?.description||'Purchase'):'Refund';
    if(e.type==='transfer')e.category='Transfer';if(e.type==='payment')e.category='Debt payment';if(e.type==='borrow')e.category='Borrowing';
    return e;
  }
  function impact(){
    const box=document.getElementById('activity-impact');
    try {const input=document.getElementById('activity-amount');if(!ArgusMoney.read(input).ok||!input.value.trim()){box.textContent='';return}
      const e=proposed(),questions=ledger.checkQuestions(e,editingId);document.getElementById('activity-reconciliation').innerHTML=questions.map(q=>`<label for="check-${q.accountId}">${escape(q.name)} · balance checked ${date(q.date)}</label><select id="check-${q.accountId}" data-check-account="${q.accountId}" data-check-id="${q.checkId}" required><option value="">Was this already included?</option><option value="included" ${e.checkResolution?.[q.accountId]?.included===true?'selected':''}>Yes · keep the checked balance</option><option value="after" ${e.checkResolution?.[q.accountId]?.included===false?'selected':''}>No · this changed the balance afterward</option></select><p class="account-help">Activity is recorded either way. This choice prevents counting the balance change twice.</p>`).join('');const preview=ledger.preview(e,editingId);
      box.innerHTML=ledger.effects(e).map(leg=>{const a=ledger.account(leg.id),value=ledger.amount(preview.get(leg.id).units,a.currency);return `<div><span>${escape(a.name)}</span><strong>${value===null?'Balance stays unknown':money(debt(a)?Math.abs(value):value,a.currency)}${debt(a)&&value!==null?(value>0?' credit':' owed'):''}</strong></div>`}).join('')+`<p>${e.type==='balance'?'A balance update, not a transaction.':['transfer','payment'].includes(e.type)?'Both accounts update together. This is not new spending.':'After saving this entry.'}${e.type==='payment'&&Number(e.fees)>0?' Interest and fees are recorded separately from debt reduction.':''}</p>`;
    }catch{box.textContent='';}
  }
  function entryDetail(id){
    const e=ledger.entries.find(e=>e.id===id);if(!e)return;
    shell(true);mode='entry';editingId=id;
    screen.innerHTML=`<div class="journey-body"><button class="journey-back" data-journey="cancel">${glyph('left')}<span>${externalBack?'Back':'Account'}</span></button><p class="eyebrow">${labels[e.type]}</p><h1>${escape(e.description||e.category||labels[e.type])}</h1><div class="journey-balance">${amountLabel(e,currentId)}</div><div class="entry-facts"><div><span>Date</span><strong>${date(e.date)}</strong></div><div><span>Category</span><strong>${escape(e.category||labels[e.type])}</strong></div><div><span>Source</span><strong>${e.sourceDocument?escape(e.sourceDocument)+' · row '+escape(e.sourceRow):'Manually recorded'}</strong></div>${['transfer','payment'].includes(e.type)?ledger.effects(e).map(leg=>`<div><span>${escape(ledger.account(leg.id).name)}</span><strong>${amountLabel(e,leg.id)}</strong></div>`).join(''):''}</div>${e.checkResolution?.[currentId]?.included?'<p class="account-help">Already included in this account’s checked balance. Recording it did not change that balance again.</p>':''}${e.type==='refund'?`<p class="account-help">${e.originalId?'Linked purchase: '+escape(ledger.entries.find(x=>x.id===e.originalId)?.description||'Purchase'):'Original purchase not linked.'} Reduces spending on the refund date; it is not income.</p>`:''}${e.memo?`<section class="entry-note"><h2>Note</h2><p>${escape(e.memo)}</p></section>`:''}<button class="primary" data-journey="correct">Correct entry</button><button class="journey-update journey-destructive" data-journey="remove">Remove entry</button>${e.check?'<p class="balance-freshness">Amounts at confirmation</p>'+checkFacts(e.check,ledger.account(e.accountId)):''}${e.type==='payment'&&Number(e.fees)>0?`<p class="balance-freshness">Interest & fees: ${money(Number(e.fees),ledger.account(e.accountId).currency)} · Debt reduced: ${money(Number(e.amount)-Number(e.fees),ledger.account(e.accountId).currency)}</p>`:''}${e.history?.length?`<details class="account-details"><summary>Correction history <span>${e.history.length}</span></summary>${e.history.map(h=>`<p class="account-help">Previously ${escape(h.description||labels[h.type])} · ${money(Math.abs(Number(h.amount)),ledger.account(h.accountId).currency)} · ${date(h.date)}</p>`).join('')}</details>`:''}<p class="account-demo">${['transfer','payment'].includes(e.type)?'Removing or correcting this entry updates both accounts.':'Changes affect this recorded account only.'}</p></div>`;
  }
  let reviewedEntry=null;
  function balanceCheck(e){
    const a=ledger.account(e.accountId),index=editingId?ledger.entries.findIndex(x=>x.id===editingId):-1;
    const before=ledger.calculate(index<0?ledger.entries:ledger.entries.slice(0,index)).get(a.id).units;
    const checked=ledger.units(e.amount,a.currency);
    return {before:before===null?null:String(before),checked:String(checked),difference:before===null?null:String(checked-before),date:e.date};
  }
  function checkFacts(c,a){
    const fmt=n=>n===null?'Not known':money(ledger.amount(BigInt(n),a.currency),a.currency);
    const d=c.difference===null?null:BigInt(c.difference);
    const delta=d===null?'Cannot calculate':`${d>0n?'+':''}${fmt(c.difference)}`;
    const caption=debt(a)?'Signed account balance (debt is negative)':'Balance';
    return `<div class="entry-facts balance-check-facts">${c.date?`<div><span>Checked on</span><strong>${date(c.date)}</strong></div>`:''}<div><span>${caption} before check</span><strong>${fmt(c.before)}</strong></div><div><span>${caption} you checked</span><strong>${fmt(c.checked)}</strong></div><div><span>${asset(a)?'Estimate change':'Difference'}</span><strong>${delta}</strong></div></div>`;
  }
  function reviewBalance(e){
    const a=ledger.account(e.accountId),check=balanceCheck(e),different=check.difference!==null&&check.difference!=='0';
    reviewedEntry={...e,check,category:asset(a)?'Value update':check.before===null?'Balance recorded':different?'Balance adjustment':'Balance checked'};
    shell(true);mode='balance-review';
    screen.innerHTML=`<div class="journey-body"><button class="journey-back" data-journey="balance-edit">${glyph('left')}<span>Edit amount</span></button><p class="eyebrow">${escape(a.name)} · ${a.currency}</p><h1>${asset(a)?'Review estimate':check.before===null?'Record your balance':different?'Review the difference':'Your balance matches'}</h1>${checkFacts(check,a)}${e.checkResolution?.[currentId]?.included?'<p class="account-help">Already included in this account’s checked balance. Recording it did not change that balance again.</p>':''}${e.type==='refund'?`<p class="account-help">${e.originalId?'Linked purchase: '+escape(ledger.entries.find(x=>x.id===e.originalId)?.description||'Purchase'):'Original purchase not linked.'} Reduces spending on the refund date; it is not income.</p>`:''}${e.memo?`<section class="entry-note"><h2>Note</h2><p>${escape(e.memo)}</p></section>`:''}<p class="muted">${asset(a)?'This updates your estimate, not your income or spending.':check.before===null?'There is no earlier known balance to compare. Saving establishes a balance; it does not create income.':different?'This difference is unexplained. Save a visible balance adjustment, or record missing activity first. Your income and spending totals will not change.':'No adjustment is needed. Save the date you checked it.'}</p><button class="primary" data-journey="balance-save">${asset(a)?'Save estimate':different?'Save balance adjustment':'Confirm balance'}</button>${different&&!asset(a)?'<button class="journey-update" data-journey="missing">Record missing activity</button>':''}<p class="account-demo">${asset(a)?'An estimate, not a market valuation.':'Balance checks do not prove your transaction history is complete.'}</p></div>`;
  }
  function saveEntry(entry){
    const correcting=!!editingId;if(!editingId&&entry.sourceKey&&ledger.entries.some(x=>x.sourceKey===entry.sourceKey)){notice('This entry was already recorded. Find it in activity or Removed financial entries.');return;}ledger.save(entry,editingId);document.dispatchEvent(new Event('preview-records-changed'));drafts.delete(`${currentId}:${entry.type==='balance'?'balance':'entry'}`);
    detail(currentId);notice(correcting?'Entry corrected.':entry.type==='balance'?`${entry.category} saved.`:'Entry saved.');entryDraft=null;editingId=null;reviewedEntry=null;
  }
  function confirmRemoval(){
    const e=ledger.entries.find(e=>e.id===editingId),paired=['transfer','payment'].includes(e.type);
    try{ledger.calculate(ledger.entries.map(x=>x.id===e.id?{...x,removed:true}:x));}catch(error){notice(error.message,'error');return;}
    confirmPreview({title:'Remove this entry?',description:`Remove “${e.description||e.category||labels[e.type]}” from recorded activity? ${paired?'Both accounts will be recalculated.':'This account will be recalculated.'} Later confirmed balances stay in place. Undo now, or restore it later from Data & privacy → Removed financial entries.`,confirmLabel:'Remove entry',onConfirm:()=>{
      lastRemoved=e.id;ledger.remove(e.id);document.dispatchEvent(new Event('preview-records-changed'));detail(currentId);const originalSpace=spaceId,removedId=e.id,originalBack=externalBack;PreviewToast.show('Entry removed','neutral',{action:{label:'Undo',onPress:()=>{FinancialSpaces.within(originalSpace,()=>AccountJourney.restoreEntry(removedId));if(FinancialSpaces.current()===originalSpace&&!phone.classList.contains('settings-mode'))AccountJourney.open(e.accountId,originalBack);notice('Entry restored to '+FinancialSpaces.list().find(s=>s.id===originalSpace).name+'.');}}});
    }});
  }
  function seed(){
    if(accounts.length)return;
    accounts.push({id:'demo-bank',name:'Everyday spending',nickname:'Everyday spending',kind:'Checking',currency:'DOP',balance:35000,asOf:today(),source:'Sample opening balance'},
      {id:'demo-cash',name:'Pocket money',kind:'Cash',currency:'DOP',balance:2000,asOf:today(),source:'Sample opening balance'},
      {id:'demo-savings',name:'Safety net',kind:'Savings',currency:'DOP',balance:60000,asOf:today(),source:'Sample opening balance'},
      {id:'demo-card',name:'My credit card',kind:'Credit card',currency:'DOP',balance:-8500,asOf:today(),source:'Sample opening balance'});
    ledger.attach();for(const e of [
      {type:'income',amount:'42000',description:'Salary',category:'Salary'},
      {type:'expense',amount:'2450.75',description:'Supermarket',category:'Groceries'},
      {type:'transfer',amount:'1500',description:'Cash for the week',category:'Transfer',otherId:'demo-cash'},
      {type:'expense',amount:'320',description:'Lunch',category:'Dining'}
    ])ledger.save({...e,accountId:'demo-bank',date:today(),recordedOn:today()});
    detail('demo-bank');
  }
  const oldShow=show;
  show=function(p){externalBack=null;phone.classList.remove('account-journey-mode');mode='list';oldShow(p);ledger.attach();
    if(p==='accounts'&&!accounts.length&&spaceId==='personal')screen.insertAdjacentHTML('beforeend','<button class="link" data-journey="sample">Explore sample accounts</button>');
  };
  window.AccountJourney={
    formatDate:date,
    switchSpace(id){
      if(id===spaceId)return;
      spaceStates.set(spaceId,{accounts,ledger,drafts,currentId,entryDraft,editingId,mode,lastRemoved,externalBack,reviewedEntry});
      const next=spaceStates.get(id)||{accounts:[],drafts:new Map(),currentId:null,entryDraft:null,editingId:null,mode:'list',lastRemoved:null,externalBack:null,reviewedEntry:null};
      accounts=next.accounts;next.ledger??=new AccountActivity(()=>next.accounts);
      ({ledger,drafts,currentId,entryDraft,editingId,mode,lastRemoved,externalBack,reviewedEntry}=next);spaceId=id;
    },
    moveState:()=>({ledger,drafts}),
    categories:categoriesFor,
    startRecord(id,back=null){externalBack=back;ledger.attach();currentId=id;start();},
    reviewProposal(entry,back=null){externalBack=back;ledger.attach();currentId=entry.accountId;editingId=null;entryDraft={...entry,recordedOn:today()};form();},
    canRemoveAccount(id){const a=ledger.account(id);return (a.balance===null||a.balance===0)&&!ledger.entries.some(e=>e.accountId===id||e.otherId===id)&&!accounts.some(x=>x.linkedDebtId===id)&&!PlanPreview.debts().some(d=>d.accountId===id)&&!window.EcosystemPreview?.isShared(id);},
    removeEmptyAccount(id){if(!this.canRemoveAccount(id))throw Error('This account has a balance, history or a link. Archive it instead.');const index=accounts.findIndex(a=>a.id===id),[record]=accounts.splice(index,1);ledger.openings.delete(id);return record;},
    restoreEmptyAccount(record){if(accounts.some(a=>a.id===record.id))return;accounts.push(record);ledger.attach();},
    importBatch(batch){const ids=ledger.saveBatch(batch);document.dispatchEvent(new Event('preview-records-changed'));return ids;},
    previewBatch(batch){const result=ledger.calculate([...ledger.entries,...batch]);return [...result].map(([id,r])=>({id,balance:ledger.amount(r.units,ledger.account(id).currency)}));},
    linkGoal(id,goalId,destination){const entry=ledger.entries.find(e=>e.id===id&&!e.removed);if(!entry||entry.type!=='transfer'||entry.otherId!==destination)throw Error('Choose the contribution received in this goal’s account.');if(entry.goalId&&entry.goalId!==goalId)throw Error('This contribution already belongs to another goal.');const newlyLinked=entry.goalId!==goalId;ledger.save({...entry,goalId,goalDestinationId:destination},id);return newlyLinked;},
    recordExpense(entry){const id=ledger.save(entry);document.dispatchEvent(new Event('preview-records-changed'));return id;},
    removedEntries(){return ledger.entries.filter(e=>e.removed).map(e=>({...e,accountName:ledger.account(e.accountId).name,currency:ledger.account(e.accountId).currency}));},
    previewRestore(id){const e=ledger.entries.find(e=>e.id===id&&e.removed);if(!e)throw Error('This entry is already restored.');const after=ledger.preview({...e,removed:false},id);return ledger.effects(e).map(leg=>{const a=ledger.account(leg.id);return {name:a.name,currency:a.currency,after:ledger.amount(after.get(a.id).units,a.currency)}});},
    restoreEntry(id){ledger.restore(id);document.dispatchEvent(new Event('preview-records-changed'));},
    refreshAfterRestore(){if(page==='accounts'&&currentId)detail(currentId);else show(page);},
    open(id,back=null){externalBack=back;ledger.attach();detail(id);},
    entries(){ledger.attach();return ledger.entries.filter(e=>!e.removed).map(e=>({...e}));},
    openEntry(id,back=null){const e=ledger.entries.find(e=>e.id===id&&!e.removed);if(!e)return;externalBack=back;currentId=e.accountId;entryDetail(id);},
    recordPayment(id,back=null){externalBack=back;ledger.attach();currentId=id;start('payment');},
    saveAccount(record,index){
      ledger.attach();const old=index==null?null:accounts[index];
      if(old){
        const history=ledger.activity(old.id);if(history.length&&(old.kind!==record.kind||old.currency!==record.currency))throw Error('Keep the currency and account type with their recorded activity.');
        if(!history.length&&(old.currency!==record.currency||old.kind!==record.kind)){accounts[index]=record;ledger.openings.delete(record.id);ledger.attach();}
        else {const changed=old.balance!==record.balance;accounts[index]={...record,balance:old.balance,source:old.source,asOf:old.asOf};if(changed&&record.balance!==null)ledger.save({accountId:record.id,type:'balance',amount:String(record.balance),date:today(),recordedOn:today(),description:'Balance updated in details',category:'Balance update'});else if(changed){ledger.openings.set(record.id,{units:null,date:null,source:'Value not added'});ledger.sync();}}
      }else {accounts.push(record);ledger.attach();}
      currentId=record.id;detail(record.id);notice(old?'Account details saved.':record.balance==null?'Account added. Add a balance when you know it.':'Account added. Your starting balance is saved. Nothing else is required.');
    },
    prepareEdit(){const a=ledger.account(currentId);editIndex=accounts.findIndex(x=>x.id===a.id);draft={...a};show('manual');
      {if(ledger.activity(a.id).length){document.getElementById('account-type-summary').disabled=true;document.getElementById('account-currency').disabled=true;} 
        document.getElementById('account-amount').readOnly=true;document.getElementById('account-date').readOnly=true;
        document.getElementById('account-type-summary').querySelector('span')?.remove();
        document.getElementById('account-type-summary').querySelector('strong').textContent=`${a.kind} · ${a.currency}`;
        document.getElementById('account-amount-label').parentElement.hidden=true;
        document.getElementById('account-amount').closest('.money-control').hidden=true;
        document.getElementById('account-amount-money-hint').hidden=true;
        screen.querySelectorAll('.account-help').forEach(el=>{if(el.textContent.startsWith('Leave blank'))el.hidden=true});
        document.getElementById('account-date').hidden=true;document.getElementById('account-date-label').hidden=true;
        document.getElementById('account-details-hint').textContent=asset(a)?'Estimate & loan':debt(a)?'Payment details':'Institution';
      }
      document.querySelector('[aria-label="Cancel account entry"]').removeAttribute('data-tab');document.querySelector('[aria-label="Cancel account entry"]').dataset.journey='cancel';
    }
  };
  document.addEventListener('click',e=>{
    const b=e.target.closest('button');if(!b)return;
    if(b.dataset.edit!==undefined){e.preventDefault();e.stopImmediatePropagation();ledger.attach();detail(accounts[Number(b.dataset.edit)].id);return}
    const op=b.dataset.journey;
    if(!op&&!b.dataset.journeyEntry&&!b.dataset.journeyType&&!b.dataset.journeyAccount)return;
    e.preventDefault();e.stopImmediatePropagation();
    if(b.dataset.journeyEntry){entryDetail(b.dataset.journeyEntry);return}
    if(b.dataset.journeyAccount){detail(b.dataset.journeyAccount);return}
    if(b.dataset.journeyType){captureDraft();entryDraft.type=b.dataset.journeyType;entryDraft.otherId='';entryDraft.category='';form();return}
    if(op==='sample'){seed();return}
    if(op==='back'){const back=externalBack;externalBack=null;if(back)back();else show('accounts');return}
    if(op==='cancel'){if(mode==='entry'&&externalBack){const back=externalBack;externalBack=null;back();return;}if(mode==='record'){captureDraft();drafts.set(`${currentId}:${entryDraft.type==='balance'?'balance':'entry'}`,{draft:{...entryDraft},editingId});}detail(currentId);return}
    if(op==='settings'){AccountJourney.prepareEdit();return}
    if(op==='record'){start();return}
    if(op==='balance'){start('balance');return}
    if(op==='all-activity'){const id=currentId,back=externalBack;ActivityPreview.open(id,()=>AccountJourney.open(id,back));return}
    if(op==='correct'){const e=ledger.entries.find(e=>e.id===editingId);start(e.type,e.id);return}
    if(op==='remove'){confirmRemoval();return}
    if(op==='balance-edit'){form();return}
    if(op==='balance-save'){saveEntry(reviewedEntry);return}
    if(op==='missing'){drafts.set(`${currentId}:balance`,{draft:{...entryDraft},editingId});start();return}
    if(op==='undo'){ledger.restore(lastRemoved);detail(currentId);notice('Entry restored.');}
  },true);
  document.addEventListener('submit',e=>{if(e.target.id!=='activity-form')return;e.preventDefault();e.stopImmediatePropagation();
    try{
      const invalid=[...e.target.querySelectorAll('input,select')].find(input=>!input.validity.valid);
      if(invalid){document.getElementById('activity-error').textContent=invalid.hasAttribute('data-check-account')?'Choose how this activity relates to your checked balance.':invalid.id==='activity-other'?'Choose an account.':'Enter a valid date that is not in the future.';invalid.focus();return;}
      const entry=proposed();ledger.preview(entry,editingId);
      if(entry.type==='balance'){reviewBalance(entry);return;}
      saveEntry(entry);
    }catch(error){document.getElementById('activity-error').textContent=error.message;}
  },true);
  if(new URLSearchParams(location.search).get('demo')==='accounts')seed();
})();
