# Argus mobile design reference

Locked September 28, 2026 as `mobile-2026-09-28`.

1. Serve this directory with a static server, for example `python3 -m http.server 8025 --bind 127.0.0.1`.
2. Open `http://127.0.0.1:8025/mobile-design-lock.html` for the complete report.
3. Open `http://127.0.0.1:8025/?demo=accounts&view=home` for populated examples, or `/` for cold-start chat.
4. Read `MOBILE-DESIGN-LOCK.md` before translating the template into production code.

Fonts and the chart library are bundled with their license/attribution records. Financial data is fictional and resets on reload. Only the appearance preference persists in an isolated browser key. Examples use the current local date; frozen screenshots record the acceptance date.

`python3 build-mobile-reports.py` regenerates all six current report pages from `mobile-report-data.json`. Do not edit one report independently. `node --test *.test.cjs` runs the 288 deterministic checks. `LOCK-MANIFEST.json` identifies the archived bytes. Earlier dated studies remain provenance, not competing current designs.

This package does not contain credentials or a running backend and does not grant deployment authority. Further changes need an explicit request and a new checkpoint.
