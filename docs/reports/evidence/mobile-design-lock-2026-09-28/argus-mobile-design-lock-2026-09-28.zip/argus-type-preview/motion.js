// Animate whole-view replacement only. Typing, streaming tokens, and search stay immediate.
(()=>{
  const previewReduced=new URLSearchParams(location.search).get('motion')==='reduce';
  if(previewReduced)document.documentElement.classList.add('preview-reduced-motion');
  const reduce=matchMedia('(prefers-reduced-motion: reduce)');let keyboard=false,animation=null,frame=0;
  document.addEventListener('keydown',e=>{if(['Tab','Enter','Escape','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){keyboard=true;document.documentElement.classList.add('keyboard-navigation');animation?.cancel();}},true);
  document.addEventListener('pointerdown',()=>{keyboard=false;document.documentElement.classList.remove('keyboard-navigation')},true);
  new MutationObserver(changes=>{
    if(!changes.some(c=>c.target===screen&&c.addedNodes.length))return;
    cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{
      animation?.cancel();if(reduce.matches||previewReduced||keyboard||screen.querySelector('input:focus,textarea:focus'))return;
      animation=screen.animate([{opacity:.75,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],{duration:180,easing:'cubic-bezier(.22,1,.36,1)'});
    });
  }).observe(screen,{childList:true});
  reduce.addEventListener('change',()=>animation?.cancel());
})();
