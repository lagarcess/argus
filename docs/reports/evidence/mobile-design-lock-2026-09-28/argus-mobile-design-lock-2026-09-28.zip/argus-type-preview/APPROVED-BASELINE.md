# Argus approved mobile baseline

**Locked September 28, 2026: `mobile-2026-09-28`.**

The founder requested a full mobile sweep and final design lock, including all ecosystem HTML reports. [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md) is the current template handoff and verification record. [Open the full report](mobile-design-lock.html).

Preserve the accepted behavior, visual system and corrections documented there. MVEE remains the repository product owner; DESIGN.md remains the visual owner. Design approval does not authorize a production deployment, a new API/schema, model-facing changes or provider work.

All six current HTML reports derive from `mobile-report-data.json`; use `python3 build-mobile-reports.py` to regenerate them together. Earlier candidate reviews and acceptance history remain in `report-history/` and earlier checkpoint archives. Later explicit refinements in the mobile lock supersede those older descriptions.

The complete package is preserved as a dated archive with SHA-256 verification, including source, fonts/licenses, report catalog, tests, current screenshots and historical studies. Further changes require an explicit request and a new dated checkpoint.
