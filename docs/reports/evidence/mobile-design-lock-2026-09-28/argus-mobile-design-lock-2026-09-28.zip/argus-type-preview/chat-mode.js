// Disposable interaction study. Retention, memory and financial context need backend contracts.
(() => {
  const S=ChatSession;
  const glyph='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 5.7A9 9 0 0 1 10 3m4 0a9 9 0 0 1 6 4m1 4a9 9 0 0 1-2 6m-3 3a9 9 0 0 1-6 1M6 20l-3 1 1-4a9 9 0 0 1-1-6"/></svg>';
  const trigger=document.createElement('button');trigger.className='chat-mode-trigger';trigger.dataset.chatMode='open';trigger.setAttribute('aria-haspopup','dialog');trigger.innerHTML=glyph;appHeader.querySelector('.chattopactions').append(trigger);
  const dialog=document.createElement('dialog');dialog.className='chat-mode-sheet';dialog.setAttribute('aria-label','Temporary chat');phone.append(dialog);let focus;
  function leave(next){
    if(!S.temporary){next();return;}
    const discard=()=>{S.end();next();};
    if(!S.started&&!document.getElementById('chattext')?.value.trim()&&!document.querySelector('.capture-chip')){discard();return;}
    confirmPreview({title:'End temporary chat?',description:'Its messages and attachments will leave this preview. They will not appear in Chats or Search.',confirmLabel:'End chat',onConfirm:discard});
  }
  window.ChatMode={leave};
  const oldShow=show;show=function(p){if(S.temporary&&p!=='chat'){leave(()=>oldShow(p));return;}oldShow(p);};
  function decorate(){
    const chat=page==='chat';trigger.hidden=!chat||S.started&&!S.temporary;
    trigger.setAttribute('aria-label',S.temporary?'Temporary chat settings':'Start a temporary chat');if(S.temporary)trigger.setAttribute('aria-haspopup','dialog');else trigger.removeAttribute('aria-haspopup');trigger.setAttribute('aria-pressed',String(S.temporary));
    const nextState=chat?(S.temporary?'temporary':'regular')+(S.started?'-active':'-empty'):'other';
    if(appHeader.dataset.chatState!==nextState){appHeader.dataset.chatState=nextState;appHeader.classList.remove('chat-state-enter');void appHeader.offsetWidth;appHeader.classList.add('chat-state-enter');}
    if(S.temporary&&chat){
      appHeader.querySelector('.header-title').textContent='';
      if(!S.started){
        clearInterval(heroTimer);
        const welcome=screen.querySelector('.chatwelcome');
        if(welcome)welcome.innerHTML=`<div class="temporary-mark">${glyph}</div><h2>Temporary chat</h2><p>Outside your chat history.<br>No new memories.</p><button class="temporary-context" data-chat-mode="open">${S.useContext?'Using my context':'Without my context'} <span aria-hidden="true">⌄</span></button>`;
        screen.querySelector('.starters')?.setAttribute('hidden','');
      }else if(!screen.querySelector('.temporary-status')){
        const status=document.createElement('button');status.className='temporary-status';status.dataset.chatMode='open';status.innerHTML=`${glyph}<span>Temporary · ${S.useContext?'Using my context':'Without my context'}</span>`;screen.querySelector('.chatstage')?.prepend(status);
      }
    }
  }
  const oldHeader=refineHeader;refineHeader=function(){oldHeader();decorate();};
  const oldRender=renderChat;renderChat=function(){oldRender();decorate();};
  function open(){
    focus=document.activeElement;S.closePanel();
    const locked=S.temporary&&S.started;
    dialog.innerHTML=`<h2>Temporary chat</h2><p>Keep this conversation out of Chats and Search. It won’t add new memories.</p><div class="temporary-choice"><span><strong>Use my context</strong><small>Reference my saved memories, response preferences and financial records I can access.</small></span><button role="switch" aria-label="Use my context" aria-checked="${S.useContext}" data-chat-mode="context" ${locked?'disabled':''}><span></span></button></div><p class="temporary-help">${locked?'Context is fixed for this chat. Start a new temporary chat to change it.':S.useContext?'Existing privacy and sharing permissions still apply.':'Off: use only what you provide in this chat. Device language and accessibility settings still apply.'}</p><details><summary>What happens when I leave?</summary><p>Ending this chat or leaving for another surface discards this preview’s messages. Switching briefly to another app does not end it.</p><p>Temporary chats do not create financial records in this sketch. Existing regular chats and drafts stay intact.</p><p>Design preview only. No AI or private data is accessed. Production retention and provider handling still need implementation; this is not an anonymity guarantee.</p></details><button class="primary" data-chat-mode="${S.temporary?'done':'start'}">${S.temporary?'Done':'Start temporary chat'}</button>${S.temporary?'<button class="temporary-end" data-chat-mode="end">Return to regular chat</button>':'<button class="secondary" data-chat-mode="done">Cancel</button>'}`;
    if(!dialog.open)dialog.showModal();
  }
  let proposedContext=false;
  document.addEventListener('click',event=>{const b=event.target.closest('[data-chat-mode]');if(!b)return;event.preventDefault();event.stopImmediatePropagation();const action=b.dataset.chatMode;
    if(action==='open'){if(!S.temporary){S.startTemporary(false);return;}proposedContext=S.useContext;open();return;}
    if(action==='context'){
      proposedContext=!(b.getAttribute('aria-checked')==='true');if(S.temporary)S.setContext(proposedContext);
      b.setAttribute('aria-checked',String(proposedContext));dialog.querySelector('.temporary-help').textContent=proposedContext?'Existing privacy and sharing permissions still apply.':'Off: use only what you provide in this chat. Device language and accessibility settings still apply.';decorate();return;
    }
    if(action==='done'){dialog.close();return;}
    if(action==='start'){dialog.close();S.startTemporary(proposedContext);return;}
    if(action==='end'){dialog.close();leave(()=>show('chat'));}
  },true);
  dialog.addEventListener('close',()=>{if(focus?.isConnected&&!focus.hidden)focus.focus({preventScroll:true});});
  decorate();
})();
