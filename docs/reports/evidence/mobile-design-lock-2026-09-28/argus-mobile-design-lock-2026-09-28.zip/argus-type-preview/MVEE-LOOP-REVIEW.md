# MVEE ecosystem UI loop review

> Historical iteration/evidence record. The final accepted template is [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md); use its current reports and acceptance boundary when implementing. Earlier gaps and recommendations below describe their dated checkpoint.

**Follow-up:** the requested closure is implemented in [LOOP-CLOSURE.md](LOOP-CLOSURE.md). The findings below preserve the pre-fix review.

Reviewed September 28, 2026. Scope: the local fictional sketch, not production readiness. No application code changed during this review.

## Verdict

The surface design is substantially established, but the connected experience is not yet fully closed. Four existing handoffs need a representative end-to-end demonstration before freezing the template. This does not call for more surfaces, settings, or a production backend inside the sketch.

The earlier assessment that nearly everything remaining was backend work was too broad. Browser replay found a contradictory statement-import path, and Plan and Household still have incomplete handoffs.

## 1. Capture must reach the same saved record — confirmed defect

**Observed:** Accounts offers both an older “Use a sample statement” path and a newer batch-review path. The older confirmation promises three transactions. After confirming, Accounts shows three static statement rows, but opening the resulting Everyday checking account says “No activity yet.”

**Reproduction:** Accounts → Use a sample statement → Confirm and add account → Accounts → Everyday checking.

**Evidence:** [Confirmation](journey-audit/loop-audit-legacy-statement.png), [resulting empty activity](journey-audit/loop-audit-statement-empty-account.png).

**Source:** `account-preview.js:154`, `index.html:13,15`; newer batch flow in `ecosystem-journeys.js:31-40`. Separately, `composer-preview.js:69-85` keeps proposals in its own map: Confirm changes the card only and does not create an AccountJourney entry. That card is honestly labelled fictional, but it does not demonstrate the approved capture-to-record loop.

**Small closure:** Consolidate old statement entry points onto the existing batch-review flow. Keep typed/voice/file extraction authored, but let one representative confirmed proposal open the same saved activity record used by Accounts and Search. Corrections must update that record. No real OCR, model, or chat runtime required.

**Acceptance:** Review a sample with a duplicate and a correction → confirm once → find the same entries in account activity and Search → correct/remove/restore → totals reflect those entries once. There must be no parallel static “Statement activity” ledger.

## 2. Plan intentions must explain their relationship to cash projection — confirmed missing handoff

**Observed:** A DOP 1,000 monthly debt plan dated October 2 was saved for My credit card. Plan Overview still omitted that dated payment. Projected expenses and ending cash remained unchanged. The forecast and goal/debt monthly intentions currently live in separate sketch state.

**Evidence:** [Saved debt plan](journey-audit/loop-audit-debt-plan.png), [forecast after saving](journey-audit/loop-audit-forecast-missing-debt.png).

**Source:** `plan-preview.js:36,41`, `forecast-preview.js`, and the separate older monthly-room calculation in `ecosystem-journeys.js:86-87`. A coverage disclaimer explains that dated movements are needed, but the normal journey provides no link from the debt plan to that movement.

**Small closure:** Demonstrate one dated debt payment and one savings intention with an explicit funding account and inclusion status. Derive the forecast from their linked expected movements. A budget remains a spending limit, not an extra withdrawal; a transfer between included cash accounts must not reduce their combined cash. Do not silently assume a funding source.

**Acceptance:** Save intention → see whether and why it is included in Overview/Home → record actual payment → replace the matching expectation once → correct/remove/restore that activity → inclusion and progress remain understandable.

**What already works:** Recording a sample rent payment lowered the recorded opening cash by DOP 12,000 and removed one expected rent occurrence. Ending projected cash stayed the same. That is the correct no-double-count behavior for that replayed path.

## 3. Household contribution progress stops before receipt — confirmed incomplete example

**Observed:** The invite preview supports pending invitation, recipient acceptance, and explicit sharing. The shared Moving fund example displays Alex and Sam’s planned contributions and a view/edit choice, but recorded progress is “Not linked yet.” There is no received-contribution or correction destination in that example.

**Evidence:** [Shared plan detail](journey-audit/loop-audit-shared-progress.png).

**Source:** `ecosystem-journeys.js:69-83`; shared Updates is a fixed empty state. The shared account presentation is a balance-only view. This is a missing representative interaction, not a request to implement multi-user security in the sketch.

**Small closure:** Demonstrate one planned contribution becoming a linked received record, shared goal/budget progress updating, and a correction. Show the view-only member’s experience. Preserve the separation between plan access and private funding-account visibility; do not count an internal contribution as new income.

**Acceptance:** Invitation → acceptance → explicit sharing → agreed contribution → received/linked activity → progress → correction. A member without edit permission has a clear destination and explanation; removing access does not pretend historical transfers are reversed.

## 4. The return loop needs one actionable example — source-confirmed experience gap

Populated Home connects balances and upcoming expectations, but does not yet demonstrate the MVEE’s readily available Record action and resume-unfinished-review state. Updates links a few example cards; it does not demonstrate a pending review, due commitment, or stale fact being resolved and then reflecting that resolution. Household Updates remains empty.

**Source:** `forecast-preview.js:41-44`, `navigation.js:31-39`, `ecosystem-journeys.js:77`; MVEE sections 3, 6, and 12.

**Small closure:** Add one representative unfinished-review return and one actionable due/stale example using existing destinations. After acting, show a resolved/read outcome and the updated Home/Plan fact. No notification scheduler, email, or push delivery needed.

## Narrow consistency defect to include with closure

`account-preview.js:29` always labels debt-type account rows “owed” and displays the absolute amount. Account detail already supports a positive credit-card credit after a refund; the account-list/Home preview label can therefore disagree. This is source-confirmed, not replayed in the browser during this audit. Derive both labels from the existing account balance meaning. Include a positive-credit example in the closure check.

## Coverage and strengths

| Area | Evidence in this review | Disposition |
| --- | --- | --- |
| Account records, money precision, notes, transfers, refunds, adjustments, recovery, moves | Existing sketch tests rerun; source inspection | Strong foundation, not a claim every UI permutation was replayed |
| Expected rent → actual record → projection | Browser replay | Correct single-count behavior for replayed example |
| Legacy statement → account activity | Browser replay | Broken handoff |
| Debt plan → projection | Browser replay | Missing inclusion/funding handoff |
| Invite → accepted household → shared goal | Browser replay, fictional data only | Invitation clear; received-contribution loop incomplete |
| Home/Updates return | Source inspection and populated Home observation | Needs representative actionable state |
| Search | Source inspection | Uses shared record collectors; household example gaps carry downstream |
| Profile/settings/auth/voice/storage | Boundaries considered, not a fresh exhaustive replay | Do not treat illustrative settings as delivered integrations |

`node --test *.test.cjs`: **262 passed, 0 failed**. [Full output](journey-audit/loop-audit-tests.txt). These model/helper checks are useful but did not catch the browser handoff failures above.

The sketch preserves separate currency totals, distinguishes unknown from zero, separates balance adjustments from income, and separates private account moves from household sharing. Private Business tracking is an approved single-person scope, not an unexplained expansion into payroll or tax accounting.

## What remains implementation, not more visual design

Real extraction and conversational runtime, persistence, authorization/RLS, concurrency, synchronization, bank integrations, actual invitation/notification delivery, provider-backed voice, and production localization remain implementation work. Real device keyboard, assistive-technology, and responsive verification still need implementation-stage acceptance. This review does not certify those capabilities.

Keep the approved Plan cash projection and chat backtest charts. No new top-level navigation, household accounting engine, or second application is recommended.

## Freeze criterion

Close the four handoffs above using existing surfaces and fictional records, fix the credit label, and replay one connected story: capture → review → record → find → plan → act → shared progress where permitted → correct/remove/restore → return to the revised picture. Then freeze the template and hand off implementation boundaries.

## Provenance and limits

Canonical repository HEAD at review: `57f36d5f45d36c2073e84a98b32cb33cfaad6172`. The sketch is outside Git and has additional local work; that SHA identifies the repository context, not an exact sketch release. [Source and evidence hashes](journey-audit/loop-audit-manifest.json) identify the reviewed local files.

The audit used a separate temporary browser tab and disposable fictional data. No user tab was reloaded, no invitation was sent, and no production/provider service was exercised. Screenshots and this report are local evidence, not published PR acceptance evidence. No full viewport or accessibility matrix was performed.
