// Local UI-only conversation navigation. No API, storage or interpretation changes.
(() => {
  let current=null,returnFocus=null,temporary=false,useContext=false,suspended=null;
  const conversations=(new URLSearchParams(location.search).get('demo')==='accounts'?sampleQuestions:[]).map((q,i)=>({id:'example-'+i,title:['Investing or a CD?','September spending','A savings plan'][i],turns:[{q,a:sampleAnswer(q)}],pinned:i===0,unread:false}));
  const panel=document.createElement('dialog');panel.className='chat-shell-panel';phone.appendChild(panel);
  const glyph=key=>`<svg viewBox="0 0 24 24" aria-hidden="true">${inheritedIcons[key]}</svg>`;
  const menuRow=(label,key,action)=>`<button class="chat-shell-row" data-chat-shell="${action}">${glyph(key)}<span>${label}</span></button>`;
  window.previewChatTitle=()=>current?.title||chatTurns[0]?.q||'';
  const originalSend=sendPreview;
  sendPreview=function(q){q=q||document.getElementById('chattext')?.value.trim();if(!q)return;if(!current){current={id:crypto.randomUUID(),title:q.slice(0,80),turns:chatTurns,pinned:false,unread:false};if(!temporary){conversations.unshift(current);registerSearch(current)}}originalSend(q)};
  function open(title,body){if(!panel.open)returnFocus=document.activeElement;panel.setAttribute('aria-label',title);panel.innerHTML=`<div class="chat-shell-heading"><h2>${escape(title)}</h2><button data-chat-shell="close" aria-label="Close ${escape(title)}">${glyph('x')}</button></div>${body}`;if(!panel.open)panel.showModal()}
  function close(){panel.close();if(returnFocus?.isConnected&&!returnFocus.hidden)returnFocus.focus({preventScroll:true})}
  function startNew(prefill=''){returnFocus=null;close();current=null;chatTurns=[];temporary=false;useContext=false;suspended=null;show('chat');const input=document.getElementById('chattext');if(input){input.value=prefill;input.dispatchEvent(new Event('input',{bubbles:true}));input.focus();}}
  function openConversation(id){const found=conversations.find(c=>c.id===id&&!c.deleted);if(!found)return;close();temporary=false;useContext=false;current=found;current.unread=false;chatTurns=current.turns;show('chat')}
  function renderRecentList(query=''){
    const active=conversations.filter(c=>!c.archived&&!c.deleted),q=query.trim().toLowerCase();
    const list=active.filter(c=>(c.title+' '+c.turns.map(t=>t.q).join(' ')).toLowerCase().includes(q));
    const groups=[['Pinned',list.filter(c=>c.pinned)],['Recent',list.filter(c=>!c.pinned)]];
    panel.querySelector('#recent-chat-list').innerHTML=list.length?groups.map(([label,items])=>items.length?`<section><h3>${label}</h3>${items.map(c=>`<button class="chat-shell-row recent-chat" data-open-conversation="${c.id}" ${current===c?'aria-current="true"':''}><span><strong>${escape(c.title)}</strong></span>${c.unread?'<i class="chat-unread" aria-label="Unread"></i>':''}${current===c?glyph('check'):''}</button>`).join('')}</section>`:'').join(''):`<div class="chat-empty"><div class="chat-empty-icon">${q?icon('search'):glyph('message')}</div><h3>${q?'No results':conversations.length?'No recent chats':'No chats yet'}</h3><p>${q?'Try another search, or start a new conversation.':'Your saved conversations will appear here.'}</p><button class="primary" data-chat-shell="new-from-search">New chat</button>${!q&&conversations.some(c=>c.archived&&!c.deleted)?'<button class="chat-empty-archive" data-chat-shell="archived">View archived chats</button>':''}</div>`;
    panel.querySelector('[data-chat-shell=clear-search]').hidden=!query;
    panel.querySelector('#recent-chat-count').textContent=q?`${list.length} ${list.length===1?'chat':'chats'} found`:'';
  }
  function recents(){open('Chats',`<label class="sr" for="recent-chat-search">Search chats</label><div class="activity-searchbar chat-searchbar">${icon('search')}<input id="recent-chat-search" type="search" placeholder="Search chats" autocomplete="off" spellcheck="false"><button class="activity-filter-trigger" data-chat-shell="clear-search" aria-label="Clear chat search" hidden>${glyph('x')}</button></div><span class="sr" role="status" id="recent-chat-count"></span><div id="recent-chat-list"></div><p class="chat-shell-note">Local preview · Changes reset on reload</p>`);renderRecentList();panel.querySelector('#recent-chat-search').addEventListener('input',e=>renderRecentList(e.target.value));}
  function options(){open('Chat options',`<p class="chat-option-title">${escape(window.previewChatTitle())}</p>`+menuRow(current?.unread?'Mark as read':'Mark as unread',current?.unread?'mailopen':'mail','unread')+menuRow(current?.pinned?'Unpin chat':'Pin chat','pin','pin')+menuRow('Rename chat','edit','rename')+menuRow(current?.archived?'Unarchive chat':'Archive chat','archive',current?.archived?'unarchive':'archive')+'<div class="chat-menu-divider" role="separator"></div>'+menuRow('Delete chat','trash','delete'));}
  function notify(){document.dispatchEvent(new Event('preview-chats-changed'));}
  function remove(id){const c=conversations.find(c=>c.id===id);if(!c)return;c.deleted=true;const i=searchRecords.findIndex(r=>r.conversationId===id);if(i>=0)searchRecords.splice(i,1);notify();}
  function restore(id){const c=conversations.find(c=>c.id===id);if(!c)return;c.deleted=false;c.archived=false;registerSearch(c);notify();}
  function archive(id){const c=conversations.find(c=>c.id===id&&!c.deleted);if(c){c.archived=true;notify();}}
  window.PreviewChats={
    all:status=>conversations.filter(c=>status==='deleted'?c.deleted:status==='archived'?c.archived&&!c.deleted:!c.archived&&!c.deleted),archive,remove,restore,
    deleteAll(){conversations.forEach(c=>remove(c.id));if(!temporary){current=null;chatTurns=[];}},
    recovery(status){const items=this.all(status);return items.length?items.map(c=>`<div class="settings-row"><span><strong>${escape(c.title)}</strong><small>${status==='archived'?'Archived chat':'Deleted chat'}</small></span><button class="eco-link" data-chat-restore="${c.id}" aria-label="Restore ${escape(c.title)}">Restore</button></div>`).join(''):`<div class="settings-empty">${glyph(status==='archived'?'archive':'trash')}<h3>${status==='archived'?'No archived chats':'Nothing recently deleted'}</h3><p>${status==='archived'?'Chats you archive will appear here.':'Deleted chats can be restored here.'}</p></div>`;}
  };
  document.addEventListener('click',e=>{const b=e.target.closest('[data-chat-shell],[data-open-conversation]');if(!b)return;e.stopImmediatePropagation();if(b.dataset.openConversation){window.ChatMode.leave(()=>openConversation(b.dataset.openConversation));return}const a=b.dataset.chatShell;
    if(a==='archived'){close();openSettingsPreview('archived');return;}if(a==='clear-search'){const input=panel.querySelector('#recent-chat-search');input.value='';renderRecentList();input.focus();return;}if(a==='new-from-search'){const query=panel.querySelector('#recent-chat-search').value.trim();window.ChatMode.leave(()=>startNew(query));return;}if(a==='close'){close();return}if(a==='recents'){recents();return}if(a==='new'){window.ChatMode.leave(()=>startNew());return}if(a==='options'){options();return}
    if(a==='share'){open('Share conversation','<p class="chat-option-title">'+escape(window.previewChatTitle())+'</p><p class="muted">This is the place to review what you share before creating a link.</p><p class="chat-shell-note">Layout preview only. No public link is created. Production sharing permissions and availability still apply.</p>');return}
    if(!current)return;
    if(a==='pin'||a==='unread'){current[a==='pin'?'pinned':'unread']=!current[a==='pin'?'pinned':'unread'];options()}
    if(a==='rename'){open('Rename chat',`<form id="rename-preview-chat"><label for="chat-title-input">Conversation title</label><input id="chat-title-input" name="title" maxlength="80" required value="${escape(current.title)}"><button class="primary">Save title</button></form>`);panel.querySelector('input').focus()}
    if(a==='archive'||a==='unarchive'){const saved=current;if(a==='archive'){archive(saved.id);startNew();PreviewToast.show('Chat archived','neutral',{action:{label:'Undo',onPress:()=>{restore(saved.id);PreviewToast.show('Chat restored');}}});}else{restore(saved.id);close();PreviewToast.show('Chat restored');}return;}
    if(a==='delete'){
      const saved=current;panel.close();confirmPreview({title:'Delete this chat?',description:`“${saved.title}” will move to Recently deleted. Restore it in Settings → Data & privacy → Conversations.`,confirmLabel:'Delete chat',onCancel:options,onConfirm:()=>{remove(saved.id);startNew();PreviewToast.show('Chat deleted','neutral',{action:{label:'Undo',onPress:()=>{restore(saved.id);PreviewToast.show('Chat restored');}}});}});
    }
  },true);
  document.addEventListener('submit',e=>{if(e.target.id!=='rename-preview-chat')return;e.preventDefault();const value=new FormData(e.target).get('title').trim();if(!value)return;current.title=value;close();refineHeader()});
  panel.addEventListener('close',()=>{if(returnFocus?.isConnected&&!returnFocus.hidden)returnFocus.focus({preventScroll:true})});
  // Global Search opens the same local examples, rather than appending them to another chat.
  function registerSearch(conversation,record){record=record||conversation.searchRecord||{kind:'Conversation',terms:''};conversation.searchRecord=record;Object.defineProperty(record,'title',{get:()=>conversation.title,configurable:true});Object.defineProperty(record,'detail',{get:()=>conversation.archived?'Archived chat':'Local preview conversation',configurable:true});record.conversationId=conversation.id;if(!searchRecords.includes(record))searchRecords.push(record);}
  for(const record of [...searchRecords]){if(record.sample!==undefined){const c=conversations.find(c=>c.id==='example-'+record.sample);if(c)registerSearch(c,record);else searchRecords.splice(searchRecords.indexOf(record),1);}}
  window.openPreviewConversation=id=>window.ChatMode.leave(()=>openConversation(id));
  window.ChatSession={newRegular:()=>window.ChatMode.leave(()=>startNew()),get temporary(){return temporary},get useContext(){return useContext},get started(){return chatTurns.length>0},startTemporary(context){close();suspended={current,turns:chatTurns};current=null;chatTurns=[];temporary=true;useContext=context;show('chat')},setContext(value){if(!chatTurns.length)useContext=value},end(){current=suspended?.current||null;chatTurns=suspended?.turns||[];suspended=null;temporary=false;useContext=false},closePanel:close};
  refineHeader();
})();
