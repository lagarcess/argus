# Surface nitpick review — September 27, 2026

> Historical iteration/evidence record. The final accepted template is [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md); use its current reports and acceptance boundary when implementing. Earlier gaps and recommendations below describe their dated checkpoint.

Status: founder-approved on September 27, 2026. Historical before/after snapshot; the later Plan, Search, auth and motion expansion is documented in JOURNEY-EXPANSION.md. No production code, APIs, deployment, financial contracts or chat runtime changed. Existing approved behavior is preserved unless explicitly listed below.

The major improvement is consistency: Accounts owns account examples, Plan owns goal examples, and the existing chat shell owns chat identities. Search and Updates read those owners rather than presenting unrelated copies.

## Before / after and tradeoffs

### 1. Accounts — Clear; core journey preserved

**Before:** Three introductory lines repeated the header; raw dates and repeated currency codes; all accounts grew into one long list.

**After:** List and count first. Human-readable update dates. Currency stays with amounts and unknown balances. First five rows with Show more/fewer. Blank-balance confirmation no longer says a balance was saved.

**Decision / tradeoff:** Give the space to accounts, not introductory copy. Extra accounts take one disclosure tap; account detail and balance-check semantics stay intact.

![Before Accounts](surface-audit/01-accounts-before.png)
![After Accounts](surface-audit/01-accounts-after.png)

### 2. Plan — Clearer; goal experience still partial

**Before:** A slogan and always-open USD-only goal form. Newly created goals disappeared on navigation. Account demo had no visible sample goals.

**After:** Goals first, then Add a goal. Short name/currency/target form, shared money validation and currency catalog. Goals survive navigation during this session, appear in Search, and open consistent details. Three-row preview with disclosure.

**Decision / tradeoff:** One additional tap to create a goal buys a calmer overview. Goal progress remains separate from account balances; no allocation or extra net worth is implied. Budget/debt creation and progress editing remain unfinished.

![Before Plan](surface-audit/02-plan-before.png)
![After Plan](surface-audit/02-plan-after.png)

### 3. Updates — Clearer; intentionally illustrative

**Before:** Repeated heading/subheading, a completed goal inconsistent with Plan, a vague dining alert, and future-feature descriptions posing as feed content.

**After:** Direct progress and over-budget headings. View goal opens the Plan record. View breakdown explains the standalone budget example. Open comparison opens the existing preview chat. Alerts & scheduled briefs goes to notification settings.

**Decision / tradeoff:** Keep explicit sample labels. Monitoring is not active. This is three prepared items, not a real event feed, read-state system or pagination implementation.

![Before Updates](surface-audit/03-updates-before.png)
![After Updates](surface-audit/03-updates-after.png)

### 4. Search — Working local navigation

**Before:** Slogan above search; repeated item-type labels; fictional account unrelated to Accounts; result sheets disconnected from the actual records. Copy advertised activity search without implementing it.

**After:** Search field first. Accounts, Goals and Chats groups with counts. Current account and goal records, existing chat identities, real local destinations, empty state, and five-row group disclosure.

**Decision / tradeoff:** Group headings replace repeating type labels. Search covers local accounts, goals and chats; account activity still has its own search. No global activity search, server cursor, ranking or retry behavior is claimed.

![Before Search](surface-audit/04-search-before.png)
![After Search](surface-audit/04-search-after.png)

### 5. Profile & settings — Established design preserved

**Before:** Generic introductory lines in preference/privacy/security screens; repeated Argus footer branding; preferred currency limited to DOP/USD.

**After:** Removed filler; kept useful row descriptions. Plain Settings / Topics / Schedule labels. Usage says Allowance & reset times. Preferred currency now searches the shared catalog by name/code. Watermark and version remain.

**Decision / tradeoff:** Keep descriptions where they clarify scope. Avatar themes, feedback templates, account deletion request and destructive colors remain. Preferences are local previews; changing currency does not convert balances or set up native delivery.

![Before Profile & settings](surface-audit/05-profile-before.png)
![After Profile & settings](surface-audit/05-profile-after.png)

## Verification

- Current-turn before/after screenshots captured and visually inspected for all five surfaces, in the approximately 390px phone frame.
- Accounts: six records exercised Show more/fewer; existing rows retained. Unknown balances stayed unknown. Account rows measured 92–93px high; primary/secondary actions 48px; no horizontal content overflow at this frame width.
- Plan: invalid `12,34` rejected inline; EUR 2,500.50 accepted. The goal survived a tab change, appeared in Search and opened with the same amount. Four goals exercised disclosure.
- Search: account, goal and chat destinations exercised; unmatched query showed No results. A six-account group expanded without replacing earlier rows. Closing goal details preserved the query.
- Updates: View goal matched Plan; View breakdown exposed USD 850 / 750 / 100 and the standalone-example caveat. Scheduled-briefs link opened notification settings.
- Settings: preferred-currency search matched Japanese Yen and saved JPY locally. No conversion occurred. Avatar, feedback and destructive-action implementations were preserved; this pass did not repeat a full regression of those unchanged flows.
- Changed JavaScript and inline scripts passed syntax checks. The existing money-entry and account-activity suites passed 206/206 (see surface-audit/deterministic-checks.txt). No new implementation-mirroring tests added for copy/style changes.
- No browser console warnings or errors observed at the checked checkpoint.

## Inheritance and evidence limits

Recents supplies the disclosure interaction; Omnisearch supplies the future server loading/retry model. This sketch implements local disclosure only. Existing Inter/Space Grotesk fonts, palette, near-black primary CTAs, 48px action sizing, glass navigation, scroll-edge blur and destructive colors are retained.

Accessibility work here includes semantic headings, named controls, expanded-state announcements, keyboard activation, focus restoration for goal details and inline amount errors. This is not a WCAG certification, VoiceOver/TalkBack audit, native keyboard test, or device-matrix acceptance. Screenshots show browser keyboard focus rings where controls were activated by keyboard.

Remaining experience work: Plan budgets/debt and goal progress editing; global activity search and return-to-search context from account details; real Updates ordering/read state/loading; real/native settings behavior. Account detail reached through Search currently returns to Accounts. Preferred currency is only a preference in this sketch, not a cross-surface conversion or defaulting contract. Goal creation uses a native select for currency, while Settings and Accounts offer searchable pickers; sharing that picker across all entry points is later polish.

Sample goals have unlinked example progress. They are not included in account/net-worth totals. The dining budget remains a clearly labeled standalone example. Monitoring, scheduling, real uploads, model calls, database persistence and financial execution are not connected. Reload resets all session data.

## Files

Changed: index.html, navigation.js, settings.js, account-preview.js, account-journey.js.
Added: plan-preview.js (one local goal owner), surface-polish.css, this report, the HTML comparison and surface-audit evidence.
Inheritance notes updated. APPROVED-BASELINE.md distinguishes the prior founder lock from this review candidate.

Rollback: restore the earlier `argus-sketch-20260927-155532-home-list-lock.zip` checkpoint. A separate snapshot preserves this candidate and its evidence. No production rollback is needed.
