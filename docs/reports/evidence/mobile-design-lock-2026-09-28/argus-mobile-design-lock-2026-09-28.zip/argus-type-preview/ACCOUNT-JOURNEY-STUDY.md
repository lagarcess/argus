# Account journey — reviewable disposable study

> Historical iteration/evidence record. The final accepted template is [MOBILE-DESIGN-LOCK.md](MOBILE-DESIGN-LOCK.md); use its current reports and acceptance boundary when implementing. Earlier gaps and recommendations below describe their dated checkpoint.

September 27, 2026. Requested extension to the accepted account-entry sketch.
The balance-check and action-clarity follow-up is founder-locked in
`APPROVED-BASELINE.md`; other extended journeys remain reviewable. It does not change production runtime or
define the production financial-record contract.

## Explore

- Local: http://127.0.0.1:8025/?demo=accounts
- Same WiFi: http://192.168.1.127:8026/?demo=accounts

The query loads fictional checking, cash, savings and credit-card accounts with
example activity. Without the query, the existing empty entry flow remains.
Reload resets the session. Account list rows open details; the pencil edits
metadata. No real money moves.

## Implemented journey

- Detail shows the recorded balance, source/date, contextual actions and searchable
  activity. Cash/bank accounts show recorded monthly income and spending.
- Manual expense/income, transfers, card charges and debt borrowing/payments use
  short forms with the shared money control, category/date and optional description.
- Before saving, the form shows balance effects. Transfers update both accounts
  from one entry. Cross-currency transfers require the actual received amount;
  the sketch does not invent an exchange rate.
- Debt payments update the funding account and debt together. An explicit interest/
  fees portion does not reduce principal. Funding currencies must match for now.
- Balance updates and property/vehicle estimates are separate from income. Unknown
  balances stay unknown until supplied; zero is explicit. Ownership shares and
  linked loans retain the accepted account-entry behavior.
- Activity details allow correction, retain previous values, and offer removal
  with confirmation and an immediate Undo. Corrections replace the existing entry
  and both paired effects rather than appending duplicate spending.
- Back retains unfinished recording drafts in this session. The ordinary recording action restores
  the draft; its label stays Record new activity (or the account-specific action). Account metadata editing cannot silently change a currency/type once
  activity exists. Balance changes then use the explicit update action.
- Existing neutral typography, money formatting, header, blur and navigation remain.
  Recording forms hide navigation and do not autofocus.

## One local owner

`account-activity-model.js` owns activity effects, correction history, removal,
restoration and replay into the existing account array. Home/Accounts consume
that array; there is no independent second balance store for those surfaces.
Effects use integer minor units, with number-valued balances handed to existing
preview rendering. `account-journey.js` owns the interaction adapter.

The local model replays in recording order. A later balance snapshot is
authoritative over earlier activity, including a correction to that earlier
activity. This is an explicit sketch simplification, not a decision on production
posting dates, historical balances, reconciliation or audit retention.

## Verification

- 206 tests passed: 194 existing money tests and 12 activity-model tests.
- Browser: expense save and monthly totals; transfer correction and both balances;
  removal and Undo; credit-card payment and both balances; unknown-balance cash
  account followed by a balance update without income; interrupted entry draft
  resume; category selection; metadata save preserving balance/source.
- Model checks additionally cover principal/fees, cross-currency required received
  amount, zero/three-decimal precision, invalid operations without partial mutation,
  and authoritative balance snapshots.
- Browser errors/warnings empty on final demo. JavaScript syntax checks passed.
- Screenshots: `account-detail-preview.png`, `account-record-preview.png`.
- Test transcript: `account-journey-test-results.txt`.

## Remaining boundaries

No bank connection, real upload/OCR, durable storage, household permissions,
valuation feed, loan schedule or investment holdings ledger is implemented.
The existing sample-statement review remains illustrative; it does not prove
that all ingestion methods feed a production recording operation. Account
archival/deletion and household collaboration are not added in this study.
Native keyboards, safe areas, screen readers and real-device touch behavior
still need device verification. The browser preview is not native acceptance.

## Clavito feedback

Removed the Resume entry CTA: visiting an empty activity form and returning made
a completed account look unfinished. The account balance and a transaction amount
are different values. Stable action labels now preserve that distinction; existing
recording drafts are still restored when reopening the form.

## Balance review and destructive confirmation follow-up

Check balance now has a review step with confirmation-time recorded/observed
amounts, date and difference. A mismatch becomes a visible Balance adjustment
with unchanged income/spending and a coverage note. Matching/unknown/estimated
values have distinct copy. Record missing activity returns to recording and
retains the unfinished check. Confirmed entries retain the check metadata.

This still uses the pre-existing in-memory absolute-snapshot model. Later
backdated/imported transaction matching and adjustment reconciliation are not
implemented; see the repository backend handoff. Confirmation-time discrepancy
metadata is historical evidence, not a live recalculated unresolved amount.

Removal now uses a native web alert dialog matching the inspected
`web/components/ui/ConfirmDialog.tsx` in integration and the local origin/main
reference: centered 18px panel, dim/blur backdrop, outlined Cancel, rose Remove
entry. No deployed-production browser verification was performed. Native dialog
focus containment, Escape cancellation/focus return, confirmed removal and Undo
were checked. The demo does not promise financial-entry Recently Deleted.

Browser evidence: `balance-check-review.png`, `remove-entry-confirmation.png`.
Verified a -500 difference, matching balance, unchanged income/spending, explicit
adjustment history, inline required-money error, removal cancellation and Undo.

Shared-confirmation follow-up: account removal, chat deletion, settings deletion
request and Delete all conversations now derive from `confirm-preview.js` and
`confirm-preview.css`. Verified settings request/delete-all presentation, Escape
remaining on the same settings route, and chat cancellation returning to its
options menu. No browser errors/warnings. Support requests remain simulations.
Evidence: `settings-delete-request.png`, `settings-delete-all.png`.
