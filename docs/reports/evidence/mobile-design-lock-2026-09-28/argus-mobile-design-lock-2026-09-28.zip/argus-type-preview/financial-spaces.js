// Session-only space owner. Household reads Personal; private spaces own separate records.
const FinancialSpaces=(()=>{
  const spaces=[{id:'personal',name:'Personal',kind:'personal'}];let current='personal',sequence=0;
  function activate(id){if(!spaces.some(s=>s.id===id&&!s.deleted))throw Error('Space unavailable.');if(id===current)return;AccountJourney.switchSpace(id);PlanPreview.switchSpace(id);current=id;draft=null;editIndex=null;}
  function collect(read){const prior=current;try{return spaces.filter(s=>!s.deleted).flatMap(space=>{activate(space.id);return read(space);});}finally{activate(prior);}}
  function moveReview(id,destination){
    const source=current,a=accounts.find(a=>a.id===id);if(!a)throw Error('Account unavailable.');
    const target=spaces.find(s=>s.id===destination&&s.id!==source&&!s.archived&&!s.deleted);if(!target)throw Error('Choose another private space.');
    const {ledger,drafts}=AccountJourney.moveState();ledger.attach();const links=ledger.moveLinks(id),issues=[];
    if(links.paired)issues.push('Transfers or payments link this account to another account, including removed activity. Keep those records together; this preview cannot move linked accounts as a group.');
    if(links.refunds)issues.push('A purchase or refund links to another account. That relationship must stay intact.');
    if(a.linkedDebtId||accounts.some(x=>x.linkedDebtId===id))issues.push('A property or vehicle is linked to this loan. Its ownership and loan link need review together.');
    if(PlanPreview.debts().some(d=>d.accountId===id))issues.push('A debt payment plan uses this account. Review that plan before moving it.');
    if(window.EcosystemPreview?.isShared(id))issues.push('This account is shared with your household. Review sharing before moving it into another private space.');
    if(window.ForecastPreview?.accountLinks(id))issues.push('Your cash projection uses this account or its recorded activity. Review Money included and linked activity in Plan first.');
    if([...drafts.keys()].some(key=>key.startsWith(id+':')))issues.push('There is an unfinished entry for this account. Finish it before moving the account.');
    const entries=ledger.entries.filter(e=>e.accountId===id),live=entries.filter(e=>!e.removed);
    if(entries.some(e=>e.sourceDocument))issues.push('Statement review is linked to this account. Moving its document links needs a separate review; this preview keeps them together.');
    const relevant=()=>PlanPreview.budgets().filter(b=>b.currency===a.currency&&live.some(e=>['expense','refund'].includes(e.type)&&e.category===b.name&&e.date.slice(0,7)===b.month)).map(b=>b.name+' · '+PlanPreview.period(b.month));
    const fromBudgets=relevant();let toBudgets;
    try{activate(destination);toBudgets=relevant();if(accounts.some(x=>x.id===id))issues.push('This account already exists in the destination.');}finally{activate(source);}
    return {account:a,source,sourceName:spaces.find(s=>s.id===source).name,target,issues,fromBudgets,toBudgets,entryCount:entries.length};
  }
  function moveAccount(id,destination){
    const review=moveReview(id,destination);if(review.issues.length)throw Error('Review the linked records before moving this account.');
    const source=AccountJourney.moveState().ledger;let target;
    try{activate(destination);target=AccountJourney.moveState().ledger;}finally{activate(review.source);}
    source.moveTo(id,target);document.dispatchEvent(new Event('preview-records-changed'));return review;
  }
  function get(id){const s=spaces.find(s=>s.id===id);if(!s)throw Error('Space unavailable.');return s;}
  function validName(name,id){name=name.trim();if(!name||name.length>40)throw Error('Use a name between 1 and 40 characters.');if(['personal','household'].includes(name.toLowerCase())||spaces.some(s=>s.id!==id&&s.name.toLowerCase()===name.toLowerCase()))throw Error('That name is already in use. Check archived and recently deleted spaces too.');return name;}
  function editable(id){const s=get(id);if(id==='personal')throw Error('Personal is your permanent default space.');return s;}
  function contents(id){const prior=current;try{activate(id);const state=AccountJourney.moveState();return {accounts:accounts.length,activity:state.ledger.entries.length,plans:PlanPreview.all().length+PlanPreview.budgets().length+PlanPreview.debts().length,expected:window.ForecastPreview?.spaceItemCount(id)||0,drafts:state.drafts.size,removedAccounts:window.AccountManagement?.removedCount(id)||0};}finally{activate(prior);}}
  function remove(id){const s=editable(id);if(s.deleted)return;if(Object.values(contents(id)).some(Boolean))throw Error('This space still has records or plans. Archive it to keep them together.');if(current===id)activate('personal');s.deleted=true;s.archived=false;}
  return {activate,collect,moveReview,moveAccount,get,contents,remove,
    rename(id,name){const s=editable(id);if(s.deleted)throw Error('Restore this space before renaming it.');s.name=validName(name,id);return s;},
    archive(id){const s=editable(id);if(s.deleted)throw Error('Restore this space first.');if(current===id)activate('personal');s.archived=true;},
    restore(id){const s=editable(id);s.archived=false;s.deleted=false;return s;},
    within(id,read){const prior=current;try{activate(id);return read();}finally{activate(prior);}},current:()=>current,
    list:()=>spaces.filter(s=>!s.deleted),active:()=>spaces.filter(s=>!s.deleted&&!s.archived),all:()=>spaces.slice(),name:()=>get(current).name,
    create(name,kind='business'){if(!['business','custom'].includes(kind))throw Error('Choose Business or Custom.');const space={id:kind+'-'+ ++sequence,name:validName(name),kind};spaces.push(space);activate(space.id);return space;},
    allAccounts(){return collect(space=>accounts.map(a=>({...a,spaceId:space.id,spaceName:space.name,spaceArchived:!!space.archived})));}
  };
})();
window.FinancialSpaces=FinancialSpaces;
