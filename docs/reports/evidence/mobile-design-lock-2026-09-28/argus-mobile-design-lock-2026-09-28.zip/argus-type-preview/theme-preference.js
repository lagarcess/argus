// One device-level appearance owner. No financial records or profile data persist.
(() => {
  const key='argus.sketch.appearance.v1', values=['Light','System','Dark'];
  const system=matchMedia('(prefers-color-scheme: dark)');
  let preference='System';
  try { const stored=localStorage.getItem(key);if(values.includes(stored))preference=stored; } catch {}
  function apply(){
    const dark=preference==='Dark'||preference==='System'&&system.matches;
    document.documentElement.dataset.theme=dark?'dark':'light';
    document.documentElement.style.colorScheme=dark?'dark':'light';
    window.dispatchEvent(new Event('preview-theme-change'));
  }
  window.PreviewTheme={get:()=>preference,set(value){
    if(!values.includes(value))return false;
    preference=value;let saved=true;
    try {localStorage.setItem(key,value);} catch {saved=false;}
    apply();return saved;
  }};
  system.addEventListener('change',()=>{if(preference==='System')apply();});
  window.addEventListener('storage',event=>{if(event.key!==key&&event.key!==null)return;preference=values.includes(event.newValue)?event.newValue:'System';apply();});
  apply();
})();
