// Pure arithmetic for the disposable commitment study. Amounts are minor units.
(function(root){
  function summarize({cash,budgets=[],bills=[],goals=[],debts=[]}){
    const categories=new Map();
    for(const b of budgets){if(categories.has(b.category))throw Error('One budget per category in this preview.');categories.set(b.category,{budget:Math.max(0,b.limit-b.spent),bills:0});}
    for(const b of bills){const row=categories.get(b.category)||{budget:0,bills:0};row.bills+=b.remaining;categories.set(b.category,row);}
    const living=[...categories.values()].reduce((n,x)=>n+Math.max(x.budget,x.bills),0);
    const overlap=[...categories.values()].reduce((n,x)=>n+Math.min(x.budget,x.bills),0);
    const planned=goals.reduce((n,g)=>n+g.remaining,0)+debts.reduce((n,d)=>n+d.remaining,0)+living;
    return {cash,planned,remaining:cash-planned,overlap,living};
  }
  root.EcosystemMath={summarize};if(typeof module!=='undefined')module.exports={summarize};
})(globalThis);
