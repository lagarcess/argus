icons.search='<circle cx="10.5" cy="10.5" r="7"/><path d="m16 16 5 5"/>';
icons.updates='<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>';
let updatesSeen=false;
const navItems=[['home','Home'],['accounts','Accounts'],['chat','Ask Argus'],['plan','Plan'],['search','Search']];
drawNav=function(){nav.innerHTML=navItems.map(([k,label])=>`<button class="tab ${active===k?'active':''}" data-tab="${k}" aria-label="${label}${k==='updates'&&!updatesSeen?', new example updates':''}" ${active===k?'aria-current="page"':''}>${k==='chat'?ARGUS_MARK:icon(k)}${k==='updates'&&!updatesSeen?'<i class="update-dot" aria-hidden="true"></i>':''}</button>`).join('')};
// A single header survives every surface transition; controls never remount.
const appHeader=document.createElement('header');appHeader.className='app-header';
const headerGlyph=key=>'<svg viewBox="0 0 24 24" aria-hidden="true">'+inheritedIcons[key]+'</svg>';
appHeader.innerHTML='<button class="chat-recents-trigger" data-chat-shell="recents" aria-label="Recent chats" hidden>'+headerGlyph('history')+'</button><button class="chat-new-trigger" data-chat-shell="new" aria-label="New chat" hidden>'+headerGlyph('newchat')+'</button><span class="header-title brand"></span><div class="chattopactions"><button data-chat-shell="share" aria-label="Share conversation" hidden>'+headerGlyph('link')+'</button><button data-chat-shell="options" aria-label="Chat options" aria-haspopup="dialog" hidden>'+headerGlyph('more')+'</button><button class="profile-trigger header-bell" data-open-updates aria-label="Updates, new example updates">'+icon('updates')+'<i class="update-dot" aria-hidden="true"></i></button><button class="profile-trigger" data-profile="open" aria-label="Profile and settings">'+headerGlyph('user')+'</button></div>';
phone.appendChild(appHeader);
function refineHeader(){
 screen.querySelectorAll('.top').forEach(el=>el.remove());
 const label=appHeader.querySelector('.header-title');
 const chat=page==='chat',conversation=chat&&chatTurns.length>0,temporary=chat&&!!window.ChatSession?.temporary;
 label.textContent=page==='chat'?(conversation?(window.previewChatTitle?.()||chatTurns[0].q):''):page==='search'?'Search':page==='home'||page==='start'?'argus':({accounts:'Accounts',plan:'Plan',updates:'Updates',manual:'Accounts',review:'Accounts'})[page]||'';
 label.className='header-title '+(page==='chat'?'conversation-title':page==='home'||page==='start'?'brand':'page-label');
 label.title=label.textContent;
 appHeader.classList.toggle('conversation-header',page==='chat');
 appHeader.querySelector('[data-chat-shell=recents]').hidden=page!=='chat';
 appHeader.querySelector('[data-chat-shell=new]').hidden=!chat||(!conversation&&!temporary);appHeader.querySelector('[data-chat-shell=new]').setAttribute('aria-label',temporary?'New regular chat':'New chat');appHeader.querySelector('[data-chat-shell=new]').title=temporary?'New regular chat':'New chat';
 appHeader.querySelector('[data-chat-shell=share]').hidden=!conversation||temporary;
 appHeader.querySelector('[data-chat-shell=options]').hidden=!conversation||temporary;
 appHeader.querySelector('[data-open-updates]').hidden=chat;
 appHeader.querySelector('[data-profile]').hidden=chat;
 appHeader.querySelector('.update-dot').hidden=updatesSeen;
 appHeader.querySelector('[data-open-updates]').setAttribute('aria-label','Updates'+(updatesSeen?'':', new example updates'));
}
const oldRenderChat=renderChat;renderChat=function(){oldRenderChat();refineHeader()};
const oldShowNav=show;
show=function(p){
 oldShowNav(p);
 if(p==='updates'){
  page='updates';active='updates';updatesSeen=true;drawNav();
  const goal=PlanPreview.all()[0],budget=PlanPreview.budget,f=PlanPreview.format,comparison=searchRecords.find(r=>r.conversationId==='example-0');
  screen.innerHTML=`<h1 class="sr">Updates</h1><p class="surface-note">Example updates · Monitoring is not connected</p><div class="updates-feed">
  ${goal?`<section class="update-item"><span class="update-kind">Goal progress</span><h2>${escape(goal.name)} · ${PlanPreview.progress(goal)}%</h2><p>${PlanPreview.remaining(goal)?`${f(PlanPreview.remaining(goal),goal.currency)} left to reach your target.`:'Your target is reached.'}</p><button class="primary surface-cta" data-goal="${goal.id}">View goal</button></section>`:''}
  ${budget?`<section class="update-item"><span class="update-kind">Budget · ${budget.period}</span><h2>${escape(budget.name)} · ${f(Math.abs(budget.spent-budget.limit),budget.currency)} ${budget.spent>budget.limit?'over':'left'}</h2><p>${f(budget.spent,budget.currency)} recorded against a ${f(budget.limit,budget.currency)} budget.</p><button class="primary surface-cta" data-update-budget>View budget</button></section>`:''}
  ${comparison?`<section class="update-item"><span class="update-kind">Saved comparison · Example</span><h2>${escape(comparison.title)}</h2><p>Revisit the sample comparison and its assumptions.</p><button class="primary surface-cta" data-update-conversation="${comparison.conversationId}">Open comparison</button></section>`:''}
  </div><button class="choice" data-update-preferences><span><strong>Alerts & scheduled briefs</strong><small>Choose topics and delivery in settings.</small></span>${rowChevron}</button>`;
 }
 if(p==='search'){
  page='search';active='search';drawNav();
  screen.innerHTML=`<h1 class="sr">Search</h1><label class="sr" for="omnisearch">Search Argus</label><div class="activity-searchbar"><input id="omnisearch" type="search" placeholder="Search Argus" autocomplete="off">${PreviewUI.filter('data-global-filter','Filter search','global-filter-count')}</div><div id="search-kinds" class="search-kinds" role="group" aria-label="Search categories"></div><div id="search-scope-chips" class="activity-filter-chips"></div><div id="searchresults"></div><span class="sr" id="searchcount" role="status"></span><p class="account-demo">Searches this local preview only</p>`;
  renderResults('');document.getElementById('omnisearch').addEventListener('input',e=>renderResults(e.target.value));
 }
 refineHeader();
};
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-open-updates')){e.stopImmediatePropagation();show('updates');return}if(b.dataset.profile){e.stopImmediatePropagation();if(b.dataset.profile==='open')openSettingsPreview()}if(b.dataset.updateQuestion!==undefined){e.stopImmediatePropagation();show('chat');sendPreview(sampleQuestions[Number(b.dataset.updateQuestion)])}},true);
const searchRecords=[
{title:'Compare investing with a CD',kind:'Conversation',detail:'Opportunity cost · Illustrative comparison',sample:0,terms:'investment certificate deposit market'},
{title:'September spending',kind:'Conversation',detail:'Understand a sample month',sample:1,terms:'budget dining transactions'},
{title:'A savings plan',kind:'Conversation',detail:'A target and a timeline',sample:2,terms:'goal contribution money'}];
let currentSearchResults=[],lastSearchQuery='',searchKind='All',searchScope='all',searchKinds=[],searchActivity={};
function returnToSearch(){const query=lastSearchQuery;show('search');const input=document.getElementById('omnisearch');input.value=query;renderResults(query);input.focus({preventScroll:true})}
function searchAccountOptions(){return FinancialSpaces.allAccounts().map(a=>({...a,id:a.spaceId+'|'+a.id,name:a.name+(a.spaceId!=='personal'?' · '+a.spaceName:'')}));}
function renderResults(query){
 lastSearchQuery=query;const q=query.trim().toLowerCase(),f=PlanPreview.format;
 const financialRecords=()=>[
  ...accounts.map(a=>({title:a.name,kind:'Accounts',detail:`${a.kind} · ${a.currency||'USD'}${a.archived?' · Archived':''}`,terms:a.institution||'',accountId:a.id})),
  ...PlanPreview.all().map(g=>({title:g.name,kind:'Goals',detail:`${f(PlanPreview.saved(g),g.currency)} of ${f(g.target,g.currency)}`,terms:'savings target',goalId:g.id})),
  ...PlanPreview.budgets().map(b=>({title:b.name,kind:'Budgets',detail:`${f(PlanPreview.spent(b),b.currency)} of ${f(b.limit,b.currency)} · ${PlanPreview.period(b.month)}`,terms:'spending limit',planId:b.id})),
  ...PlanPreview.debts().map(d=>({title:PlanPreview.debtAccount(d)?.name||'Payment plan',kind:'Debt plans',detail:`${f(d.monthly,PlanPreview.debtAccount(d)?.currency||'DOP')} / month`,terms:'debt payment',planId:d.id})),
  ...(window.AccountJourney?.entries()||[]).map(e=>{const a=accounts.find(a=>a.id===e.accountId),other=accounts.find(a=>a.id===e.otherId);return {title:e.description||e.category||e.type,kind:'Activity',detail:`${e.type[0].toUpperCase()+e.type.slice(1)} · ${f(Number(e.amount),a.currency)} · ${a.name}${other?' · '+other.name:''} · ${new Intl.DateTimeFormat('en',{month:'short',day:'numeric'}).format(new Date(e.date+'T12:00:00'))}`,terms:`${e.category||''} ${e.type} ${e.memo||''}`,entryId:e.id,activity:e}})
 ].map(r=>({...r,spaceId:window.FinancialSpaces?.current()||'personal',spaceName:window.FinancialSpaces?.name()||'Personal',spaceArchived:!!window.FinancialSpaces?.get(FinancialSpaces.current()).archived,shared:(window.FinancialSpaces?.current()||'personal')==='personal'&&(r.accountId?!!window.EcosystemPreview?.isShared(r.accountId):r.activity?!!window.EcosystemPreview?.isShared(r.activity.accountId)&&(!r.activity.otherId||EcosystemPreview.isShared(r.activity.otherId)):false)}));
 const records=[...(window.FinancialSpaces?FinancialSpaces.collect(financialRecords):financialRecords()),
  ...(window.EcosystemPreview?.searchItems()||[]),
  ...searchRecords.map(r=>({...r,kind:'Chats'})),
  ...(window.SettingsStudy?.searchItems()||[])
 ];
 const normalized=records.map(r=>({...r,kind:['Goals','Budgets','Debt plans'].includes(r.kind)?'Plans':r.kind,detail: (r.spaceId&&r.spaceId!=='personal'?r.spaceName+(r.spaceArchived?' · Archived space':'')+' · ':'')+(['Goals','Budgets','Debt plans'].includes(r.kind)?r.kind.replace(/s$/,'')+' · '+r.detail:r.detail)}));
 const order=['Accounts','Activity','Plans','Chats'];searchKinds=[...new Set(normalized.map(r=>r.kind))].sort((a,b)=>(order.includes(a)?order.indexOf(a):order.length)-(order.includes(b)?order.indexOf(b):order.length));
 if(searchKind!=='All'&&!searchKinds.includes(searchKind))searchKind='All';
 const matches=normalized.filter(r=>(searchScope==='all'||(searchScope==='shared'?r.shared:!r.shared))&&(r.title+' '+r.kind+' '+r.detail+' '+r.terms).toLowerCase().includes(q));
 currentSearchResults=matches.filter(r=>(searchKind==='All'||r.kind===searchKind)&&(searchKind!=='Activity'||PreviewUI.activityMatches({...r.activity,accountId:r.spaceId+'|'+r.activity.accountId,otherId:r.activity.otherId?r.spaceId+'|'+r.activity.otherId:undefined},searchActivity)));
 const groups=searchKinds;
 document.getElementById('search-kinds').innerHTML=['All',...searchKinds].map(k=>`<button data-search-kind="${k}" aria-pressed="${searchKind===k}">${k}</button>`).join('');
 document.getElementById('search-scope-chips').innerHTML=searchScope==='all'?'':`<button class="activity-filter-chip" data-search-scope-clear aria-label="Remove ${searchScope==='shared'?'shared':'private'} records filter">${searchScope==='shared'?'Household':'Only me'} <span aria-hidden="true">×</span></button>`;
 const activeActivity=searchKind==='Activity'?Object.entries(searchActivity).filter(([,v])=>v):[];
 document.getElementById('search-scope-chips').innerHTML+=activeActivity.map(([k,v])=>`<button class="activity-filter-chip" data-search-filter-clear="${k}" aria-label="Remove ${escape(k)} filter">${escape(k==='account'?searchAccountOptions().find(a=>a.id===v)?.name||v:k==='from'?'From '+v:k==='to'?'Until '+v:k==='type'?({borrow:'Borrowing',balance:'Balance check'}[v]||v[0].toUpperCase()+v.slice(1)):v)} <span aria-hidden="true">×</span></button>`).join('');
 const count=activeActivity.length+(searchScope==='all'?0:1),badge=document.getElementById('global-filter-count');badge.hidden=!count;badge.textContent=count;badge.parentElement.setAttribute('aria-label',count?'Filter search, '+count+' active':'Filter search');
 document.getElementById('searchresults').innerHTML=currentSearchResults.length?groups.map(kind=>{
  const rows=currentSearchResults.filter(r=>r.kind===kind);if(!rows.length)return '';
  const id='search-'+kind.toLowerCase().replaceAll(' ','-');
  return `<section class="search-group"><h2>${kind} <span>${rows.length}</span></h2><div id="${id}">${rows.map((r,i)=>`<button class="choice" data-search-record="${currentSearchResults.indexOf(r)}" ${i>=5?'hidden data-search-overflow':''}><span><strong>${escape(r.title)}</strong><small>${escape(r.detail)}${r.shared?' · Household':''}</small></span>${rowChevron}</button>`).join('')}</div>${rows.length>5?`<button class="list-disclosure" data-search-expand="${id}" aria-expanded="false" aria-controls="${id}">Show more ${kind.toLowerCase()}</button>`:''}</section>`;
 }).join(''):'<div class="search-empty"><h2>No results</h2><p class="muted">Try another name or topic.</p></div>';
 document.getElementById('searchcount').textContent=currentSearchResults.length+(currentSearchResults.length===1?' result':' results');
}
const globalFilterDialog=document.createElement('dialog');globalFilterDialog.className='eco-dialog';document.body.append(globalFilterDialog);let globalFilterFocus;
globalFilterDialog.addEventListener('close',()=>globalFilterFocus?.isConnected&&globalFilterFocus.focus({preventScroll:true}));
document.addEventListener('click',e=>{const b=e.target.closest('[data-search-kind],[data-global-filter],[data-global-filter-close],[data-search-scope-clear],[data-search-filter-clear],[data-search-reset]');if(!b)return;e.preventDefault();e.stopImmediatePropagation();if(b.hasAttribute('data-global-filter-close')){globalFilterDialog.close();return;}if(b.dataset.searchKind){searchKind=b.dataset.searchKind;renderResults(lastSearchQuery);document.querySelector(`[data-search-kind="${searchKind}"]`)?.focus({preventScroll:true});return;}if(b.hasAttribute('data-search-filter-clear')){delete searchActivity[b.dataset.searchFilterClear];renderResults(lastSearchQuery);document.getElementById('omnisearch').focus({preventScroll:true});return;}if(b.hasAttribute('data-search-reset')){searchActivity={};searchScope='all';globalFilterDialog.close();renderResults(lastSearchQuery);return;}if(b.hasAttribute('data-search-scope-clear')){globalFilterDialog.close();searchScope='all';renderResults(lastSearchQuery);document.getElementById('omnisearch').focus({preventScroll:true});return;}globalFilterFocus=b;globalFilterDialog.setAttribute('aria-label','Filter search');globalFilterDialog.innerHTML=`<div class="account-heading"><h2>Filter search</h2><button class="account-close" data-global-filter-close aria-label="Close">×</button></div><form id="global-search-filters"><label for="global-search-scope">Include</label><select id="global-search-scope">${[['all','All'],['private','Only me'],['shared','Household']].map(([v,l])=>`<option value="${v}" ${searchScope===v?'selected':''}>${l}</option>`).join('')}</select>${searchKind==='Activity'?PreviewUI.activityFields(searchActivity,searchAccountOptions(),FinancialSpaces.collect(()=>AccountJourney.entries()),'search-filter'):''}<p class="eco-note">Only me shows what you haven’t shared. Household shows what’s shared with your household. All includes both.</p><p class="error" id="search-filter-error" role="alert"></p><button class="primary">Apply filters</button>${searchScope!=='all'||(searchKind==='Activity'&&Object.values(searchActivity).some(Boolean))?'<button type="button" class="activity-reset" data-search-reset>Reset filters</button>':''}</form>`;globalFilterDialog.showModal();},true);
document.addEventListener('submit',e=>{if(e.target.id!=='global-search-filters')return;e.preventDefault();try{if(searchKind==='Activity')searchActivity=PreviewUI.readActivityFilters(globalFilterDialog,'search-filter');searchScope=document.getElementById('global-search-scope').value;globalFilterDialog.close();renderResults(lastSearchQuery);}catch(error){document.getElementById('search-filter-error').textContent=error.message;}});
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-search-record],[data-search-expand],[data-update-budget],[data-update-conversation],[data-update-preferences]');if(!b)return;
 e.stopImmediatePropagation();
 if(b.dataset.searchRecord!==undefined){const r=currentSearchResults[Number(b.dataset.searchRecord)];if(r.sharedGoal){EcosystemPreview.openSharedPlan();return;}if(r.spaceId)EcosystemPreview.chooseSpace(r.spaceId);if(r.settingsRoute)openSettingsPreview(r.settingsRoute);else if(r.entryId)AccountJourney.openEntry(r.entryId,returnToSearch);else if(r.accountId)AccountJourney.open(r.accountId,returnToSearch);else if(r.planId)PlanPreview.openRecord(r.planId);else if(r.goalId)PlanPreview.openGoal(r.goalId);else if(r.conversationId)openPreviewConversation(r.conversationId);return}
 if(b.dataset.searchExpand){const expanded=b.getAttribute('aria-expanded')!=='true';document.getElementById(b.dataset.searchExpand).querySelectorAll('[data-search-overflow]').forEach(row=>row.hidden=!expanded);b.setAttribute('aria-expanded',String(expanded));b.textContent=`Show ${expanded?'fewer':'more'} ${b.dataset.searchExpand.slice(7)}`;return}
 if(b.hasAttribute('data-update-preferences')){openSettingsPreview('notifications');return}
 if(b.dataset.updateConversation){openPreviewConversation(b.dataset.updateConversation);return}
 const budget=PlanPreview.budget;if(budget)PlanPreview.openBudget(budget.id);
},true);
show('chat');
