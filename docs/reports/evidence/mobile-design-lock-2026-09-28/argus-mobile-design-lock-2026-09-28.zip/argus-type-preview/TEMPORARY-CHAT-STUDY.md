# Temporary chat and dark-theme polish — September 28, 2026

Founder-locked disposable UI experience; simplified header approved September 28, 2026. Supersedes the three-name presentation in the earlier appearance discussion, not the production memory or retention contract.

## Experience

- One Temporary chat entry replaces Profile on the empty chat header. Use a dashed conversation bubble, not a disguise/anonymity icon. Profile stays on other surfaces.
- Regular active chats preserve Share and Chat options. Temporary chat is started from a fresh chat; Chat options is reserved for the current conversation. Existing messages are not retroactively reclassified.
- Temporary chat has one optional Use my context switch, default off. On means permitted saved memories, financial records and response preferences; off means only input given here, while device language/accessibility remain. This is illustrative, not actual data retrieval.
- Neither temporary variant creates memories or appears in local Chats/Search. This combines the old private/incognito concepts without requiring users to learn two privacy names.
- Context is fixed after the first message. Turning it off later could not undo already consumed context.
- Mode remains visible during the conversation. Leaving for another surface, opening another chat or New chat asks before discarding nonempty temporary content. Merely opening Recents or briefly backgrounding does not discard it.
- Ending returns to the prior regular chat/draft; its local identity and composer drafts remain intact. Reload still resets the entire disposable sketch.
- Sample captures in temporary chat do not create financial records. Explicit saving from a temporary conversation is deliberately not introduced here; production needs an agreed durable-record boundary.
- Details disclose that no model/private data is accessed and production retention/provider handling remain unresolved. No anonymity, zero retention or guaranteed erasure claim.

## Theme correction

Replaced hard-coded white backgrounds and foregrounds in the composer, receipt/capture previews and actions with existing semantic tokens. Dark composer has a subtle raised charcoal surface. Recents search, placeholders, form fields and modal scrims follow the selected theme. The previous persistent appearance owner is unchanged.

## Verification

273 existing/focused checks passed; JavaScript syntax checks passed. Browser keyboard walkthrough covered dark composer/tray, Recents search, context off/on, temporary message exclusion from Recents and Search, exit cancellation and completion, sample receipt with no record action, locked context after sending, preservation of a regular conversation, and final-code regular-draft restoration. No browser console errors observed.

Screenshots in journey-audit: dark-composer-tray.png, recents-dark-fixed.png, temporary-chat-dark.png and temporary-chat-settings.png. The first two captures preceded only the regular-draft preservation refinement; visual styles are unchanged. No full native/device/accessibility matrix or backend privacy enforcement is claimed. Real backend and repository source code remain untouched.

## Simplified header lock

| Chat state | Left | Right |
| --- | --- | --- |
| Empty regular | Recent chats | Start temporary chat |
| Active regular | Recent chats, New chat | Share, Chat options |
| Empty temporary | Recent chats, New regular chat | Temporary chat settings |
| Active temporary | Recent chats, New regular chat | Temporary chat settings |

Updates and Profile remain on other surfaces. New chat appears after the first regular message and throughout temporary mode; its reserved layout slot keeps Recent chats stationary. It always stays on the left. Header targets are 48 CSS pixels. The temporary icon stays the same dashed bubble whether context is on or off; the text label carries that distinction.

Temporary entry starts directly with context off, without an intervening setup dialog. The landing's Without my context / Using my context control opens its settings. Chat options contains no temporary entry. New chat stays left; the temporary icon stays right and never becomes a New chat icon. Return to regular chat in its settings restores the prior regular conversation/draft; New regular chat starts fresh. Header and landing use a brief 150ms fade, with no icon morphing or pulsing; reduced-motion CSS disables those transitions.

Latest verification: all four header states checked in the browser using keyboard interaction, with Recent chats at the same horizontal position and visible targets measuring 48px. At that historical checkpoint, checked direct entry from the header and an active-chat menu entry; the final lock removes that redundant menu entry. Checked context off/on, context disabled after sending, cancel/confirm exit, and restoration of a regular draft. No console errors. Existing 273 checks and changed JavaScript syntax checks pass; see journey-audit/simplified-header-tests.txt. Reduced-motion rules were inspected in code, not tested through an OS preference change. The four header-*.png screenshots capture this version. This is not a full accessibility or device audit.

The lock covers presentation and local mock behavior. Production retention, provider processing and context access require their own implementation and verification before these promises ship.

## Recents and recovery follow-up

See CHAT-RECOVERY-STUDY.md for the September 28 Recents empty states, quiet search, archive/recovery loop and permanent left-side New chat placement. This supersedes earlier menu-entry and empty-temporary header details.
