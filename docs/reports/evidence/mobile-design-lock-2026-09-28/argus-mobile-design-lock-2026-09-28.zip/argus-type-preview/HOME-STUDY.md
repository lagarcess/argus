# Populated Home — simplified copy study

September 27, 2026. Founder-locked populated Home and list interaction direction.

Removed the eyebrow, promotional heading, account-count explanation and complete
coverage count. Each currency has Recorded net worth with a quiet source note.
Missing balances remain explicit; asset estimates stay identified. Debt displays
as a positive amount under You owe (a net credit uses Credit balance).

Home previews the first three accounts with View all linking to Accounts. Account
rows omit repeated currency subtitles and use readable update dates. Opening a
preview still opens its account detail. The full Accounts screen and cold start
are unchanged. No production runtime or product contract was changed.

Verified populated sample totals, Home preview navigation, full four-account list
and return to Home. Browser error/warning log empty; JavaScript syntax passed.
Screenshot: home-simplified-preview.png.

## Inheritance identified and locked

The repository DESIGN.md “Growing lists across ecosystem surfaces” is the
interaction owner. Recents (`ChatSidebar.tsx` + `chat-recents.ts`) supplies the
Show more / Show less pattern for loaded groups. Omnisearch
(`ChatCommandPalette.tsx` + `CommandPaletteLoadMoreControl.tsx`) supplies cursor
loading, retained results, loading states and retry. This is inspected code
evidence, not a fresh deployed-production check.

Home's three-row preview is implemented. The agreed grouped Accounts and paged
activity/Search/Updates behavior is a handoff direction; no actual backend
pagination is implemented in this sketch. Plan uses compact previews or group
disclosure where appropriate. Net worth stays separate by currency; an optional
combined view still requires conversion rules and source/date disclosure.
