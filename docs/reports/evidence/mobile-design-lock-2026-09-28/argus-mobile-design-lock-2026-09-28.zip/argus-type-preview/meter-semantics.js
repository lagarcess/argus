// Usage palette inherited from web/lib/usage-allowance.ts; one owner in this sketch.
(function(root){
  const tone=(percent,intent='goal')=>intent==='capacity'?(percent>=90?'danger':percent>70?'warning':'teal'):(percent>=100?'success':'teal');
  const status=percent=>percent>100?'Over limit':percent===100?'At limit':percent>=90?'Near limit':percent>70?'Approaching limit':'Within limit';
  root.ArgusMeters={tone,status};if(typeof module!=='undefined')module.exports=root.ArgusMeters;
})(globalThis);
